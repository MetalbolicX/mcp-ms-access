"""WP4 whole-stage fallback live probe. Cell A: passive-only worker run (baseline v1+Tier1).
Cell B: include_app_logic run where the Tier2 disposable copy raises deterministic OSError
at shutil.copy2 AFTER passive extraction. Production worker path; no COM launch expected."""
from __future__ import annotations
import hashlib, io, json, os, sys
from pathlib import Path
from types import SimpleNamespace

VERIFY = Path(os.environ["VERIFY_DIR"]).resolve()
FIXTURES = Path(r"D:/code/python/mcp-ms-access/db/fixtures")
RESULTS: dict[str, object] = {}

import ms_access_mcp
from ms_access_mcp.application import documentation_app_logic as app_logic
from ms_access_mcp.application import documentation_worker as worker
from ms_access_mcp.application.documentation_worker import build_request, decode_response_with_identities

assert Path(ms_access_mcp.__file__).resolve().parents[2] == Path(r"D:/code/python/mcp-ms-access"), "wrong tree"
RESULTS["app_logic_sha"] = hashlib.sha256(Path(app_logic.__file__).read_bytes()).hexdigest()

ORIGINAL = FIXTURES / "documentation" / "startup.accdb"
source_copy = VERIFY / "live_copyfail.accdb"
scratch_root = VERIFY / "live_scratch_copyfail"
scratch_root.mkdir(exist_ok=True)
os.environ[app_logic.SCRATCH_DIR_ENV] = str(scratch_root)

ORDER: list[str] = []
real_inspect = worker.inspect_open_database
def inspect_recorder(*args, **kwargs):
    ORDER.append("passive_extract")
    doc = real_inspect(*args, **kwargs)
    return doc
worker.inspect_open_database = inspect_recorder

def failing_copy(_src: object, _dst: object) -> None:
    ORDER.append("tier2_copy2_raise")
    raise OSError("the disposable copy could not be written: PWD=hunter2secret;")
app_logic.shutil = SimpleNamespace(copy2=failing_copy, rmtree=__import__("shutil").rmtree)

def run_cell(request: dict) -> tuple[int, list, dict]:
    stdin_buf = io.BytesIO(json.dumps(request).encode("utf-8"))
    stdout_rec = io.BytesIO()
    real = (sys.stdin, sys.stdout, sys.__stdout__)
    try:
        sys.stdin = SimpleNamespace(buffer=stdin_buf)
        sys.stdout = SimpleNamespace(buffer=stdout_rec)
        sys.__stdout__ = SimpleNamespace(buffer=stdout_rec)
        code = worker.main([])
    finally:
        sys.stdin, sys.stdout, sys.__stdout__ = real
    sys.stdout.flush()
    ids, resp = decode_response_with_identities(stdout_rec.getvalue())
    return code, ids, resp

RESULTS["original_sha256_before"] = hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
RESULTS["copy_sha256_before"] = hashlib.sha256(source_copy.read_bytes()).hexdigest()

orderA = list(ORDER)
codeA, idsA, respA = run_cell(build_request(db_path=str(source_copy), backend="dao", allowed_dirs=[FIXTURES], tables=None, queries=None))
passive_doc = respA["evidence"]

codeB, idsB, respB = run_cell(build_request(db_path=str(source_copy), backend="dao", allowed_dirs=[FIXTURES], tables=None, queries=None, include_app_logic=True))
evB = respB.get("evidence")

# Prior live success control (observed earlier this verification, NOT repeated here):
# worker run, disposable startup copy, include_app_logic=True, real COM:
#   status=complete, tables=['StartupNotes'], containers all four observed.
PRIOR_CONTROL = {"tables": ["StartupNotes"],
                 "containers": [["form_inventory", "observed"], ["report_inventory", "observed"],
                                ["macro_inventory", "observed"], ["module_inventory", "observed"]]}
RESULTS["prior_control_reference"] = PRIOR_CONTROL

# --- assertions recorded as structured results ---
a = RESULTS["assertions"] = {}
a["cellA_passive_ok_true"] = respA["ok"] is True and passive_doc["status"] == "complete"
a["cellA_v1_shape_has_no_app_logic_key"] = "app_logic" not in passive_doc["data"]
a["stage_order"] = ORDER[len(orderA):]
a["stage_order_is_passive_then_tier2_copy_raise"] = ORDER[len(orderA):] == ["passive_extract", "tier2_copy2_raise"]
a["cellB_ok_true"] = respB["ok"] is True
a["cellB_status_partial"] = evB is not None and evB["status"] == "partial"
a["cellB_v1_tables_retained"] = [t["name"] for t in evB["data"]["tables"]] == [t["name"] for t in passive_doc["data"]["tables"]]
cellB_containers = [(c["category"], c["objects"]["state"]) for c in evB["data"]["app_logic"]["containers"]]
a["cellB_tier1_containers"] = cellB_containers
a["cellB_tier1_matches_prior_control"] = cellB_containers == [tuple(x) for x in PRIOR_CONTROL["containers"]]
a["cellB_v1_matches_prior_control"] = [t["name"] for t in evB["data"]["tables"]] == PRIOR_CONTROL["tables"]
a["cellB_failed_families"] = [(c["category"], c["name"], c["content"]["state"]) for c in evB["data"]["app_logic"]["content"]]
a["cellB_all_four_families_failed"] = [(c["category"], c["name"], c["content"]["state"]) for c in evB["data"]["app_logic"]["content"]] == [
    ("form", "<all objects>", "failed"), ("report", "<all objects>", "failed"),
    ("macro", "<all objects>", "failed"), ("vba_module", "<all objects>", "failed")]
ref = evB["data"]["app_logic"]["references"][0]
a["cellB_reference_props_all_failed"] = ref["name"] == "<all objects>" and all(ref[p]["state"] == "failed" for p in ("path", "guid", "major", "minor", "built_in"))
a["cellB_warning_count_is_one"] = len(evB["warnings"]) == 1
serialized = json.dumps(evB)
a["cellB_secret_absent_sanitized_present"] = "hunter2secret" not in serialized and "PWD=***" in serialized
a["cellB_no_identity_frames"] = idsB == []
a["cellA_no_identity_frames"] = idsA == []
a["exit_codes"] = {"cellA": codeA, "cellB": codeB}
a["original_sha256_after"] = hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
a["original_unchanged"] = a["original_sha256_after"] == RESULTS["original_sha256_before"]
a["copy_unchanged"] = hashlib.sha256(source_copy.read_bytes()).hexdigest() == RESULTS["copy_sha256_before"]
a["scratch_leftover"] = sorted(p.name for p in scratch_root.iterdir()) if scratch_root.exists() else []
a["laccdb_locks_under_fixtures"] = sorted(p.name for p in FIXTURES.rglob("*.laccdb"))

print("COPYFAILPROBE " + json.dumps(RESULTS, sort_keys=True))
Path(VERIFY / "wp4_live_fallback_probe.json").write_text(json.dumps(RESULTS, indent=1, sort_keys=True), encoding="utf-8")
