"""WP2 differential probe: run the same fake-backed scenarios against two trees.

Prints TREE_PROOF first (not compared), then deterministic cell blocks.
"""
from __future__ import annotations

import inspect as _inspect_mod
import io
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import ms_access_mcp

print("TREE_PROOF:", ms_access_mcp.__file__)

from ms_access_mcp.application.documentation import (  # noqa: E402
    AppLogicEvidence,
    ContentObjectEvidence,
    Coverage,
    EvidenceDoc,
    FactProvenance,
    FactStatus,
    RunMetadata,
    SourceEvidence,
)
from ms_access_mcp.application.documentation_render import render_document  # noqa: E402
from ms_access_mcp.application.documentation_runtime import DocumentationRuntime  # noqa: E402
from ms_access_mcp.application.documentation_worker import (  # noqa: E402
    emit_access_identity,
    encode_response,
)
from ms_access_mcp.application.process_identity import (  # noqa: E402
    AccessTermination,
    list_msaccess_pids,
)

try:
    from ms_access_mcp.application.process_identity import read_msaccess_baseline  # noqa: E402
except ImportError:
    read_msaccess_baseline = None
from ms_access_mcp.errors import AccessMcpError  # noqa: E402

ACCESS_PID = 41_000
ACCESS_CREATION = 133_456_789_012_345_678
ACCESS_IMAGE = "MSACCESS.EXE"
PINNED = (
    "Documentation inspection worker cleanup could not be established within "
    "the {grace:g}-second cleanup grace; the owned worker may still be running "
    "and no evidence was produced"
)
SUPPORTS_BASELINE_READER = "access_baseline_reader" in _inspect_mod.signature(
    DocumentationRuntime.__init__.parameters if False else DocumentationRuntime.__init__
).parameters
print("SUPPORTS_BASELINE_READER:", SUPPORTS_BASELINE_READER)


def frame_bytes(pid: int = ACCESS_PID) -> bytes:
    stream = io.BytesIO()
    emit_access_identity(pid, ACCESS_CREATION, ACCESS_IMAGE, stream=stream)
    return stream.getvalue()


def evidence_response_bytes() -> bytes:
    document = EvidenceDoc(
        run=RunMetadata("fixture-stub", "1.0", [], []),
        source=SourceEvidence("fixture.accdb", "ACE", "DAO", "offline", "caller-managed"),
        coverage=Coverage(),
    )
    payload = document.to_dict()
    payload["status"] = document.status
    return encode_response({"ok": True, "evidence": payload})


class FrameProcess:
    returncode: int | None = 0

    def __init__(self, output: bytes) -> None:
        self.stdin = io.BytesIO()
        self.stdout = io.BytesIO(output)
        self.stderr = io.BytesIO(b"")
        self.kills = 0

    def poll(self) -> int:
        return 0

    def kill(self) -> None:
        self.kills += 1

    def wait(self, timeout: float | None = None) -> int:
        return 0


class UnreapableProcess:
    returncode: int | None = None

    def __init__(self, output: bytes = b"") -> None:
        self.stdin = io.BytesIO()
        self.stdout = io.BytesIO(output)
        self.stderr = io.BytesIO(b"")
        self.kills = 0

    def poll(self) -> None:
        return None

    def kill(self) -> None:
        self.kills += 1

    def wait(self, timeout: float | None = None) -> int:
        raise subprocess.TimeoutExpired("worker", timeout)


class KillRaisingProcess(UnreapableProcess):
    def __init__(self, error: Exception) -> None:
        super().__init__()
        self._error = error

    def kill(self) -> None:
        self.kills += 1
        raise self._error


class RecordingTerminator:
    def __init__(self, *, exited: bool, detail: str = "stub") -> None:
        self.calls: list[dict[str, Any]] = []
        self._exited = exited
        self._detail = detail

    def __call__(self, *, pid: int, creation: int, image: str, baseline_pids: frozenset, grace_seconds: float) -> AccessTermination:
        self.calls.append(
            {"pid": pid, "creation": creation, "image": image, "baseline_pids": sorted(baseline_pids), "grace_seconds": grace_seconds}
        )
        return AccessTermination(pid=pid, verified=True, terminated=True, exited=self._exited, detail=self._detail)


class RaisingRunner:
    def __init__(self, error: Exception) -> None:
        self.error = error
        self.calls: list[list[str]] = []

    def __call__(self, args: Any, timeout: float) -> subprocess.CompletedProcess[str]:
        self.calls.append([str(a) for a in args])
        raise self.error


class RawTasklistRunner:
    def __init__(self, stdout: str) -> None:
        self.calls: list[list[str]] = []
        self.stdout = stdout

    def __call__(self, args: Any, timeout: float) -> subprocess.CompletedProcess[str]:
        call = [str(a) for a in args]
        self.calls.append(call)
        return subprocess.CompletedProcess(call, 0, self.stdout, "")


def build_runtime(process: Any, terminator: Any, *, lister=None, reader=None, grace: float = 0.05) -> DocumentationRuntime:
    kwargs: dict[str, Any] = {
        "launcher": lambda: process,
        "deadline_seconds": 30,
        "cleanup_grace_seconds": grace,
        "access_terminator": terminator,
    }
    if SUPPORTS_BASELINE_READER:
        if reader is not None:
            kwargs["access_baseline_reader"] = reader
        if lister is not None:
            kwargs["access_pid_lister"] = lister
    else:
        assert reader is None, "baseline reader seam does not exist on this tree"
        kwargs["access_pid_lister"] = lister or (lambda: set())
    return DocumentationRuntime(**kwargs)


def inspect(runtime: DocumentationRuntime) -> EvidenceDoc:
    return runtime.inspect(
        "fixture.accdb", backend="dao", allowed_dirs=[Path("C:/db")], tables=None, queries=None
    )


def cell_a1() -> None:
    """Working baseline listing (one real baseline PID): byte-identical everywhere."""
    process = FrameProcess(frame_bytes() + evidence_response_bytes())
    terminator = RecordingTerminator(exited=True)
    if SUPPORTS_BASELINE_READER:
        reader = lambda: read_msaccess_baseline(runner=RawTasklistRunner(  # noqa: E731
            f'"MSACCESS.EXE","4242","Console","1","100,000 K"\n'
        ))
        runtime = build_runtime(process, terminator, reader=reader)
    else:
        runtime = build_runtime(process, terminator, lister=lambda: {4242})
    document = inspect(runtime)
    print("A1 warnings:", document.warnings)
    print("A1 status:", document.status)
    print("A1 terminator calls:", terminator.calls)
    print("A1 evidence sha:", __import__("hashlib").sha256(json.dumps(document.to_dict(), sort_keys=True).encode()).hexdigest())
    print("A1 evidence json:", json.dumps(document.to_dict(), sort_keys=True))


def cell_a2() -> None:
    """Failing baseline listing: same kill decisions; warning only on current tree."""
    process = FrameProcess(frame_bytes() + evidence_response_bytes())
    terminator = RecordingTerminator(exited=True)
    runner = RaisingRunner(OSError("tasklist unavailable: C:/Users/secret/tasklist.exe"))
    if SUPPORTS_BASELINE_READER:
        runtime = build_runtime(process, terminator, reader=lambda: read_msaccess_baseline(runner=runner))
    else:
        runtime = build_runtime(process, terminator, lister=lambda: list_msaccess_pids(runner=runner))
    document = inspect(runtime)
    print("A2 warnings:", document.warnings)
    print("A2 status:", document.status)
    print("A2 terminator calls:", terminator.calls)


def _run_cleanup_cell(label: str, process: Any, terminator: Any, grace: float = 0.05) -> None:
    runtime = build_runtime(process, terminator, grace=grace)
    try:
        inspect(runtime)
        print(f"{label} result:", "NO ERROR (unexpected)")
    except AccessMcpError as error:
        print(f"{label} message:", str(error))
    except BaseException as error:  # noqa: BLE001
        print(f"{label} unexpected:", type(error).__name__, str(error))
    print(f"{label} kills:", process.kills)


def cell_b1() -> None:
    """Survivor, no Access announced, no kill error: pinned message byte-identical."""
    _run_cleanup_cell("B1", UnreapableProcess(), RecordingTerminator(exited=True))


def cell_b2() -> None:
    """Survivor with one announced PID whose reap fails: detail appended after pinned prefix."""
    detail = (
        f"identity-verified Access PID {ACCESS_PID} survived the 0.05-second cleanup grace "
        "after taskkill /F /PID"
    )
    _run_cleanup_cell("B2", UnreapableProcess(frame_bytes()), RecordingTerminator(exited=False, detail=detail))


def cell_b3() -> None:
    """Child kill() itself raises: pinned prefix plus swallowed error class; 2 kills."""
    _run_cleanup_cell("B3", KillRaisingProcess(OSError("access denied: C:/Windows/System32/taskkill")), RecordingTerminator(exited=True))


def cell_c() -> None:
    """Successful no-failure evidence JSON and Markdown byte identity."""
    def provenance(kind: str, name: str, prop: str) -> FactProvenance:
        return FactProvenance(kind, name, prop)

    def content(category: str, name: str, value: dict) -> ContentObjectEvidence:
        return ContentObjectEvidence(category, name, "access-application", FactStatus.observed(value, provenance(category, name, "content")))

    sha = "a" * 64
    document = EvidenceDoc(
        run=RunMetadata("probe-run", "1.0", ["t1"], []),
        source=SourceEvidence("fixture.accdb", "ACE", "DAO", "offline", "caller-managed"),
        coverage=Coverage(),
        app_logic=AppLogicEvidence(
            content=[
                content("vba_module", "modMain", {"type": "Standard", "procedures": ["Main"], "sha256": sha, "bytes": 73}),
                content("form", "frmMain", {"sha256": sha, "bytes": 5130}),
                content("report", "rptSales", {"sha256": sha, "bytes": 0}),
                content("macro", "AutoExec", {"sha256": sha, "bytes": 30}),
            ],
        ),
    )
    rendered = render_document(document)
    print("C evidence json:", json.dumps(document.to_dict(), sort_keys=True))
    print("C markdown bytes:", len(rendered.markdown.encode("utf-8")))
    print("C markdown sha:", __import__("hashlib").sha256(rendered.markdown.encode("utf-8")).hexdigest())
    print("---C MARKDOWN BEGIN---")
    print(rendered.markdown)
    print("---C MARKDOWN END---")


def cell_d() -> None:
    """list_msaccess_pids on a raising runner is an empty set in both trees."""
    runner = RaisingRunner(OSError("boom"))
    print("D list_msaccess_pids(raising):", repr(list_msaccess_pids(runner=runner)))
    if SUPPORTS_BASELINE_READER:
        outcome = read_msaccess_baseline(runner=runner)
        print("D read_msaccess_baseline:", repr(outcome.pids), outcome.error_class)
    ok_runner = RawTasklistRunner('"MSACCESS.EXE","77","Console","1","1 K"\n"chrome.EXE","88","Console","1","1 K"\n')
    print("D list_msaccess_pids(ok):", repr(list_msaccess_pids(runner=ok_runner)))


if __name__ == "__main__":
    for name in ("cell_a1", "cell_a2", "cell_b1", "cell_b2", "cell_b3", "cell_c", "cell_d"):
        print(f"=== {name} ===")
        globals()[name]()
    print("=== DONE ===")
