"""H1 validator probe + A4 interrupt/residue probes."""
from __future__ import annotations

import hashlib
import shutil
import tempfile
from pathlib import Path

import ms_access_mcp

print("TREE_PROOF:", ms_access_mcp.__file__)

from ms_access_mcp.application.documentation import (  # noqa: E402
    ContentObjectEvidence,
    FactProvenance,
    FactStatus,
)

def try_validate(label: str, category: str, value: dict) -> None:
    try:
        ContentObjectEvidence(
            category, "f1", "access-application",
            FactStatus.observed(value, FactProvenance(category, "f1", "content")),
        ).validate()
        print(f"{label}: ACCEPTED")
    except ValueError as error:
        print(f"{label}: ValueError: {error}")

sha = "a" * 64
upper = "A" * 64
try_validate("V form-64lower", "form", {"sha256": sha, "bytes": 5})
try_validate("V form-0bytes", "form", {"sha256": sha, "bytes": 0})
try_validate("I form-uppercase", "form", {"sha256": upper, "bytes": 5})
try_validate("I form-63char", "form", {"sha256": "a" * 63, "bytes": 5})
try_validate("I form-65char", "form", {"sha256": "a" * 65, "bytes": 5})
try_validate("I form-negative", "form", {"sha256": sha, "bytes": -1})
try_validate("I form-boolbytes", "form", {"sha256": sha, "bytes": True})
try_validate("V vba-64lower", "vba_module", {"type": "Standard", "sha256": sha, "bytes": 5})
try_validate("I vba-uppercase", "vba_module", {"type": "Standard", "sha256": upper, "bytes": 5})
try_validate("I vba-negative", "vba_module", {"type": "Standard", "sha256": sha, "bytes": -3})
try_validate("I vba-63char", "vba_module", {"type": "Standard", "sha256": "b" * 63, "bytes": 5})

# --- A4: interrupt inside the armed read propagates; teardown still removes the workdir ---
from ms_access_mcp.application import documentation_app_logic as dal  # noqa: E402

source_file = Path(tempfile.mkstemp(prefix="wp2probe-src-", suffix=".accdb")[1])
source_file.write_bytes(b"probe source bytes")
scratch_root = Path(tempfile.mkdtemp(prefix="wp2probe-root-", dir="."))
def minimal_content(self, copy_path, workdir, include_source):  # noqa: ANN001
    return dal.AppLogicContent()

reader = dal.AppLogicReader(scratch_root=scratch_root)

original_armed = dal.AppLogicReader._read_armed
original_mkdtemp = dal.tempfile.mkdtemp
workdir_holder: list[Path] = []

def exploding_armed(self, copy_path, workdir, include_source):  # noqa: ANN001
    raise KeyboardInterrupt("probe interrupt")

def tracking_mkdtemp(*args, **kwargs):  # noqa: ANN002, ANN003
    path = original_mkdtemp(*args, **kwargs)
    workdir_holder.append(Path(path))
    return path

dal.AppLogicReader._read_armed = exploding_armed
dal.tempfile.mkdtemp = tracking_mkdtemp
try:
    try:
        reader.read(str(source_file), include_source=False)
        print("A4-INT: NO RAISE (unexpected)")
    except KeyboardInterrupt:
        print("A4-INT: KeyboardInterrupt propagated")
    except BaseException as error:  # noqa: BLE001
        print(f"A4-INT: other {type(error).__name__} propagated")
finally:
    dal.AppLogicReader._read_armed = original_armed
    dal.tempfile.mkdtemp = original_mkdtemp
    for path in workdir_holder:
        print(f"A4-INT: workdir removed after interrupt = {not path.exists()}")
        shutil.rmtree(path, ignore_errors=True)

def residue_case(label: str, fake_rmtree) -> None:
    """read() with a faked removal; the content object reports the outcome."""
    reader_x = dal.AppLogicReader(scratch_root=scratch_root)
    dal.AppLogicReader._read_armed = minimal_content
    holder: list[Path] = []

    def tracking2(*args, **kwargs):  # noqa: ANN002, ANN003
        path = original_mkdtemp(*args, **kwargs)
        holder.append(Path(path))
        return path

    original_tree = dal.shutil.rmtree
    dal.tempfile.mkdtemp = tracking2
    dal.shutil.rmtree = fake_rmtree
    try:
        content = reader_x.read(str(source_file), include_source=False)
        print(f"{label}: warnings={content.warnings}")
    except BaseException as error:  # noqa: BLE001
        print(f"{label}: RAISED {type(error).__name__}: {error}")
    finally:
        dal.tempfile.mkdtemp = original_mkdtemp
        dal.shutil.rmtree = original_tree
        dal.AppLogicReader._read_armed = original_armed
        for path in holder:
            shutil.rmtree(path, ignore_errors=True)

# Case 1: removal "succeeds" but leaves the directory behind (realistic silent residue).
residue_case("A4-RES1-silent-residue", lambda path, *a, **k: None)
# Case 2: removal itself raises (hostile teardown) — current must never raise.
def raising_rmtree(path, *a, **k):  # noqa: ANN002, ANN003
    raise OSError(13, "Permission denied")

residue_case("A4-RES2-raising-removal", raising_rmtree)

shutil.rmtree(scratch_root, ignore_errors=True)
source_file.unlink(missing_ok=True)
print("=== DONE2 ===")
