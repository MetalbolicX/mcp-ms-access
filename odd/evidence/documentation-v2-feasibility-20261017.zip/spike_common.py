"""Shared constants and safety helpers for the v2 feasibility spike.

This is throwaway spike tooling, not production code. It lives entirely under
``db/fixtures/e2e-v2-spike-<id>/`` and never edits canonical fixtures.

Safety contract enforced here:

* Every Access instance is a fresh ``DispatchEx`` owned by this spike.
* Process kills are PID-scoped and creation-time verified; never image-name kills.
* An existing ``MSACCESS.EXE`` (foreign baseline PID) is never touched.
* Dialog observation reuses ``tests/helpers/dialog_watcher.py`` read-only helpers.
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

SCRATCH_DIR = Path(__file__).resolve().parent
ROOT = SCRATCH_DIR.parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# --- fixture vocabulary -----------------------------------------------------
FIXTURE_DB_NAME = "armed.accdb"
MODULE_NAME = "SpikeMarkers"
FORM_NAME = "SpikeStartupForm"
AUTOEXEC_ARMED = "AutoExec"
AUTOEXEC_CONTROL = "AutoExecControl"
AUTOKEYS_ARMED = "AutoKeys"
AUTOKEYS_CONTROL = "AutoKeysControl"
MANUAL_MACRO_NAME = "ManualMarker"
STARTUP_PROPERTY = "StartupForm"

MARKER_AUTOEXEC = "autoexec_executed.marker"
MARKER_FORM = "form_onload_executed.marker"
MARKER_AUTOKEYS = "autokeys_executed.marker"
MARKER_MANUAL = "manual_executed.marker"
ALL_MARKERS = (MARKER_AUTOEXEC, MARKER_FORM, MARKER_AUTOKEYS, MARKER_MANUAL)

# msoAutomationSecurity values
MSO_LOW = 1
MSO_FORCE_DISABLE = 3

# DAO constants
DB_TEXT = 10
AC_FORM = 2
AC_MACRO = 4
AC_MODULE = 5
AC_SAVE_YES = 1

# --- canonical protection ---------------------------------------------------
CANONICAL_TARGETS = (
    ROOT / "db" / "fixtures" / "documentation",
    ROOT / "db" / "northwind.accdb",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_hashes() -> dict[str, dict[str, Any]]:
    """Return {relative_path: {sha256, bytes}} for every canonical target file."""
    result: dict[str, dict[str, Any]] = {}
    for target in CANONICAL_TARGETS:
        files = [target] if target.is_file() else sorted(p for p in target.rglob("*") if p.is_file())
        for path in files:
            result[str(path.relative_to(ROOT)).replace("\\", "/")] = {
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
    return result


def diff_hashes(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_keys = set(before)
    after_keys = set(after)
    changed = [k for k in before_keys & after_keys if before[k] != after[k]]
    return {
        "unchanged": not changed and before_keys == after_keys,
        "changed": sorted(changed),
        "added": sorted(after_keys - before_keys),
        "removed": sorted(before_keys - after_keys),
    }


# --- process helpers --------------------------------------------------------
def msaccess_pids() -> set[int]:
    """Return running MSACCESS.EXE PIDs via argv (no shell, so no /FI mangling)."""
    completed = subprocess.run(
        ["tasklist", "/FI", "IMAGENAME eq MSACCESS.EXE", "/NH"],
        capture_output=True, text=True, timeout=30, check=False,
    )
    pids: set[int] = set()
    for line in completed.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0].upper() == "MSACCESS.EXE" and parts[1].isdigit():
            pids.add(int(parts[1]))
    return pids


def creation_time(pid: int) -> int | None:
    """Creation time in 100ns ticks using the existing watcher helper."""
    from tests.helpers.dialog_watcher import creation_time as _ct

    return _ct(pid)


def process_image(pid: int) -> str:
    from tests.helpers.dialog_watcher import process_image as _pi

    return _pi(pid)


MSACCESS_IMAGE = "MSACCESS.EXE"


def verify_access_identity(
    pid: int | None,
    expected_creation: int | None,
    baseline_pids: set[int] | None = None,
) -> dict[str, Any]:
    """Fail-closed ownership proof for a captured Access PID.

    Ownership requires ALL of: a pid, a pid absent from the foreign baseline, a
    non-null captured creation time, a live process whose current creation time still
    equals the captured value, and the ``MSACCESS.EXE`` image. Anything short of that
    is unowned and must never be opened for an armed run nor killed.
    """
    record: dict[str, Any] = {
        "pid": pid,
        "expected_creation": expected_creation,
        "owned": False,
        "reasons": [],
    }
    if pid is None:
        record["reasons"].append("no-pid")
        return record
    if baseline_pids and pid in baseline_pids:
        record["reasons"].append("pid-in-baseline")
        return record
    if expected_creation is None:
        record["reasons"].append("no-captured-creation")
        return record
    observed = creation_time(pid)
    record["observed_creation"] = observed
    if observed is None:
        record["reasons"].append("not-running")
        return record
    if observed != expected_creation:
        record["reasons"].append("creation-mismatch")
        return record
    image = process_image(pid)
    record["image"] = image
    if image.upper() != MSACCESS_IMAGE:
        record["reasons"].append(f"image-not-{MSACCESS_IMAGE}")
        return record
    record["owned"] = True
    return record


def kill_pid_scoped(
    pid: int | None,
    expected_creation: int | None,
    baseline_pids: set[int] | None = None,
) -> dict[str, Any]:
    """Force-kill exactly ``pid`` only after a positive ownership proof.

    Fails CLOSED: with no captured creation, no live matching creation, a pid present
    in the foreign baseline, or a non-MSACCESS image, it performs no kill at all.
    Never uses ``/IM``.
    """
    record: dict[str, Any] = {"pid": pid, "expected_creation": expected_creation}
    verification = verify_access_identity(pid, expected_creation, baseline_pids)
    record["verification"] = verification
    if not verification["owned"]:
        record["result"] = "skipped-unverified-no-kill"
        return record
    completed = subprocess.run(
        ["taskkill", "/PID", str(pid), "/F"],
        capture_output=True, text=True, timeout=30, check=False,
    )
    record["result"] = "killed" if completed.returncode == 0 else "taskkill-failed"
    record["taskkill_stdout"] = completed.stdout.strip()
    record["taskkill_stderr"] = completed.stderr.strip()
    return record


def wait_for_pid_exit(pid: int | None, timeout: float = 15.0) -> bool:
    """Poll until ``pid`` is gone; return True when it exited within the grace period."""
    if pid is None:
        return True
    import time

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if pid not in msaccess_pids():
            return True
        time.sleep(0.5)
    return pid not in msaccess_pids()


def write_json_flushed(path: Path, payload: Any) -> None:
    """Write JSON atomically-ish and fsync so the parent can read it mid-run."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n"
    with path.open("w", encoding="utf-8") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())


def list_marker_files(directory: Path) -> list[str]:
    return sorted(p.name for p in directory.glob("*marker*") if p.is_file())


def lock_files(directory: Path) -> list[str]:
    return sorted(p.name for p in directory.glob("*.laccdb"))
