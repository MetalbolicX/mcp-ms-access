"""Outer runner for the v2 feasibility spike.

Owns the safety envelope the child cannot: per-cell hard timeouts, fail-closed
PID-scoped hard kills, parent-side dialog observation on timeout, canonical-file hash
protection, and the evidence bundle.

Usage (launch through the parent's background runner; this takes minutes)::

    .venv\\Scripts\\python.exe db\\fixtures\\e2e-v2-spike-<id>\\run_spike.py --all

Bounded self check (no Access, no COM)::

    .venv\\Scripts\\python.exe db\\fixtures\\e2e-v2-spike-<id>\\run_spike.py --self-check

Exit codes (a STOP is explicitly nonzero, never masked as success)::

    0  PASS
    10 STOP-inconclusive-positive-control
    11 STOP-recipe-not-clean
    12 STOP-execution-timeout
    13 STOP-integrity (canonical hash changed or foreign MSACCESS appeared)
    20 BLOCKED-build
    21 BLOCKED-overall-timeout
    30 INFRA-error (unexpected runner failure)
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

from spike_common import (
    ALL_MARKERS,
    FIXTURE_DB_NAME,
    FORM_NAME,
    MARKER_AUTOEXEC,
    MARKER_AUTOKEYS,
    MARKER_FORM,
    MSO_FORCE_DISABLE,
    MSO_LOW,
    ROOT,
    canonical_hashes,
    diff_hashes,
    kill_pid_scoped,
    lock_files,
    msaccess_pids,
    verify_access_identity,
    wait_for_pid_exit,
    write_json_flushed,
)

SCRATCH = Path(__file__).resolve().parent
FIXTURE_DIR = SCRATCH / "fixture"
EVIDENCE_DIR = SCRATCH / "evidence"
BUILD_TIMEOUT = 240.0
CELL_TIMEOUT = 120.0
POLL_SECONDS = 20.0

EXIT_CODES = {
    "PASS": 0,
    "STOP-inconclusive-positive-control": 10,
    "STOP-recipe-not-clean": 11,
    "STOP-execution-timeout": 12,
    "STOP-integrity": 13,
    "BLOCKED-build": 20,
    "BLOCKED-overall-timeout": 21,
    "INFRA-error": 30,
}

# Authorized 9-cell matrix: 3 cells x N=3, positive control first. No DIAG probe.
CELLS = [
    {"id": "POS", "security": MSO_LOW, "runs": 3, "delete_startup": False,
     "expect": "positive control: AutoExec + form OnLoad markers must BOTH fire"},
    {"id": "FD", "security": MSO_FORCE_DISABLE, "runs": 3, "delete_startup": False,
     "expect": "force-disable on unchanged copy: zero markers of any vector"},
    {"id": "FD_DEL", "security": MSO_FORCE_DISABLE, "runs": 3, "delete_startup": True,
     "expect": "force-disable + StartupForm DAO property deleted: zero markers of any vector"},
]


def _run_bounded(argv, cwd, timeout, stdout_path, stderr_path):
    with stdout_path.open("w", encoding="utf-8") as out, stderr_path.open("w", encoding="utf-8") as err:
        proc = subprocess.Popen(argv, cwd=str(cwd), stdout=out, stderr=err)
    timed_out = False
    try:
        returncode = proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        returncode = None
    return proc, returncode, timed_out


def _parent_dialog_sample(access_pid):
    try:
        from tests.helpers.dialog_watcher import collect_windows

        windows = collect_windows({access_pid})
        return [
            {
                "hwnd": hex(w.hwnd),
                "owner_pid": w.owner_pid,
                "owner_image": w.owner_image,
                "class_name": w.class_name,
                "title": w.title,
                "is_dialog_class": w.class_name == "#32770",
            }
            for w in windows
        ]
    except Exception as exc:  # noqa: BLE001
        return [{"observer_error": str(exc)}]


def _read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _authoritative_markers(run_dir: Path) -> tuple[dict, dict]:
    """Read marker presence AND content from disk after cleanup (never from child JSON)."""
    presence: dict = {}
    contents: dict = {}
    for name in ALL_MARKERS:
        path = run_dir / name
        try:
            presence[name] = path.is_file()
            contents[name] = path.read_text(encoding="utf-8", errors="replace").strip() if path.is_file() else None
        except Exception as exc:  # noqa: BLE001
            presence[name] = False
            contents[name] = f"<unreadable: {exc}>"
    return presence, contents


def build_fixture() -> dict:
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    if FIXTURE_DIR.exists():
        return {"error": f"fixture dir already exists: {FIXTURE_DIR}", "ok": False}
    argv = [sys.executable, str(SCRATCH / "build_fixture.py"), "--out-dir", str(FIXTURE_DIR)]
    proc, rc, timed_out = _run_bounded(
        argv, SCRATCH, BUILD_TIMEOUT,
        EVIDENCE_DIR / "build_stdout.txt", EVIDENCE_DIR / "build_stderr.txt",
    )
    identity = _read_json(FIXTURE_DIR / "build_identity.json") or {}
    if timed_out:
        proc.kill()
        proc.wait(timeout=15)
    cleanup = kill_pid_scoped(identity.get("access_pid"), identity.get("access_creation"))
    report = _read_json(FIXTURE_DIR / "build_report.json") or {}
    ok = rc == 0 and not timed_out and "error" not in report
    result = {
        "returncode": rc,
        "timed_out": timed_out,
        "identity": identity,
        "cleanup": cleanup,
        "report": report,
        "ok": ok,
    }
    write_json_flushed(EVIDENCE_DIR / "build_result.json", result)
    return result


def run_one(cell: dict, run_index: int, baseline: set[int]) -> dict:
    run_dir = EVIDENCE_DIR / "cells" / cell["id"] / f"run_{run_index}"
    run_dir.mkdir(parents=True, exist_ok=True)
    copy = run_dir / FIXTURE_DB_NAME
    shutil.copy2(FIXTURE_DIR / FIXTURE_DB_NAME, copy)

    argv = [
        sys.executable, str(SCRATCH / "cell.py"),
        "--cell", cell["id"],
        "--run", str(run_index),
        "--db", str(copy),
        "--out-dir", str(run_dir),
        "--security", str(cell["security"]),
        "--poll-seconds", str(POLL_SECONDS),
    ]
    if cell["delete_startup"]:
        argv += ["--delete-startup"]

    proc, child_rc, timed_out = _run_bounded(
        argv, SCRATCH, CELL_TIMEOUT,
        run_dir / "stdout.txt", run_dir / "stderr.txt",
    )
    identity = _read_json(run_dir / "identity.json") or {}
    access_pid = identity.get("access_pid")
    access_creation = identity.get("access_creation")

    timeout_dialogs: list = []
    if timed_out:
        # Observe before killing, then hard-kill by verified PID only.
        if access_pid:
            timeout_dialogs = _parent_dialog_sample(access_pid)
        cleanup_first = kill_pid_scoped(access_pid, access_creation, baseline)
        proc.kill()
        child_returncode_after_kill = proc.wait(timeout=15)
        reap_mode = "hard-timeout"
        wait_for_pid_exit(access_pid, timeout=10.0)
    else:
        child_returncode_after_kill = child_rc
        if access_pid is not None:
            if wait_for_pid_exit(access_pid, timeout=15.0):
                cleanup_first = {"pid": access_pid, "result": "exited-gracefully"}
                reap_mode = "graceful"
            else:
                cleanup_first = kill_pid_scoped(access_pid, access_creation, baseline)
                wait_for_pid_exit(access_pid, timeout=10.0)
                reap_mode = "forced-after-grace"
        else:
            cleanup_first = {"pid": None, "result": "no-pid-captured"}
            reap_mode = "no-pid-captured"

    result = _read_json(run_dir / "result.json") or {}
    markers_final, marker_contents = _authoritative_markers(run_dir)
    dialogs = [d for d in result.get("dialogs", []) if d.get("is_dialog_class")]
    residual_owned_pid = bool(access_pid is not None and access_pid in msaccess_pids())

    record = {
        "cell": cell["id"],
        "run": run_index,
        "security_requested": cell["security"],
        "delete_startup": cell["delete_startup"],
        "child_returncode": child_rc,
        "child_returncode_after_kill": child_returncode_after_kill,
        "timed_out": timed_out,
        "identity": identity,
        "identity_verification": identity.get("verification"),
        "access_pid_in_baseline": access_pid in baseline if access_pid else None,
        "cleanup_after": cleanup_first,
        "reap_mode": reap_mode,
        "residual_owned_pid": residual_owned_pid,
        "markers_from_child": result.get("markers"),
        "markers_final": markers_final,
        "marker_contents": marker_contents,
        "markers_present": sorted(name for name, present in markers_final.items() if present),
        "dialogs": dialogs,
        "timeout_dialogs": timeout_dialogs,
        "all_observed_windows": result.get("dialogs", []),
        "observer_started": result.get("observer_started") is True,
        "observer_error": result.get("observer_error"),
        "locks": lock_files(run_dir),
        "security_readback": result.get("security_readback"),
        "open_ok": result.get("open_ok"),
        "open_error": result.get("open_error"),
        "delete_startup_record": result.get("predispatch_delete_startup"),
        "tier1_dao_startup_property": (result.get("tier1_dao_properties") or {}).get("StartupForm"),
        "tier2_references": result.get("tier2_references"),
        "project_objects": result.get("project_objects"),
        "run_dir": str(run_dir.relative_to(ROOT)).replace("\\", "/"),
    }
    write_json_flushed(run_dir / "run_record.json", record)
    return record


def run_is_valid(record: dict) -> bool:
    """A run only counts as evidence when the harness itself worked and stayed honest."""
    return (
        not record.get("timed_out")
        and record.get("child_returncode") == 0
        and record.get("open_ok") is True
        and record.get("security_readback") == record.get("security_requested")
        and record.get("observer_started") is True
        and not record.get("observer_error")
        and record.get("residual_owned_pid") is False
        and record.get("access_pid_in_baseline") is not True
    )


def run_is_clean(record: dict) -> bool:
    """A clean recipe run additionally shows zero markers, zero dialogs, zero locks."""
    return (
        run_is_valid(record)
        and not any(record.get("markers_final", {}).values())
        and not record.get("dialogs")
        and not record.get("timeout_dialogs")
        and not record.get("locks")
    )


def _recipe(cell_id: str, runs: list[dict]) -> dict:
    subset = [r for r in runs if r["cell"] == cell_id]
    failures = []
    if len(subset) != 3:
        failures.append(f"expected 3 runs, have {len(subset)}")
    for r in subset:
        if not run_is_clean(r):
            failures.append(f"run {r['run']} not clean/valid")
    if cell_id == "FD_DEL":
        for r in subset:
            rec = r.get("delete_startup_record") or {}
            if rec.get("delete_ok") is not True:
                failures.append(f"run {r['run']} StartupForm delete not confirmed")
    return {
        "cell": cell_id,
        "runs": len(subset),
        "all_three_valid": len(subset) == 3 and all(run_is_valid(r) for r in subset),
        "fully_clean": not failures,
        "failures": failures,
        "forced_after_grace": [
            r["run"] for r in subset if r.get("reap_mode") == "forced-after-grace"
        ],
        "delete_records": [r.get("delete_startup_record") for r in subset],
    }


def compute_verdicts(
    runs: list[dict],
    *,
    build_ok: bool,
    overall_timeout_hit: bool,
    any_cell_timed_out: bool,
    hash_diff: dict,
    new_pids: list[int],
    infra_error: str | None,
) -> dict:
    pos = [r for r in runs if r["cell"] == "POS"]
    positive_exact = len(pos) == 3
    positive_valid = positive_exact and all(run_is_valid(r) for r in pos)
    positive_autoexec = positive_exact and all(r["markers_final"].get(MARKER_AUTOEXEC) for r in pos)
    positive_form = positive_exact and all(r["markers_final"].get(MARKER_FORM) for r in pos)
    positive_ok = positive_valid and positive_autoexec and positive_form

    fd = _recipe("FD", runs)
    fd_del = _recipe("FD_DEL", runs)
    any_recipe_clean = fd["fully_clean"] or fd_del["fully_clean"]

    hash_ok = bool(hash_diff.get("unchanged")) and not new_pids

    if infra_error:
        status = "INFRA-error"
    elif not build_ok:
        status = "BLOCKED-build"
    elif overall_timeout_hit:
        status = "BLOCKED-overall-timeout"
    elif any_cell_timed_out:
        status = "STOP-execution-timeout"
    elif not positive_ok:
        status = "STOP-inconclusive-positive-control"
    elif not hash_ok:
        status = "STOP-integrity"
    elif not any_recipe_clean:
        status = "STOP-recipe-not-clean"
    else:
        status = "PASS"

    per_vector = {
        "autoexec": {
            "positive_control_fired": positive_autoexec,
            "under_force_disable_zero": all(
                not r["markers_final"].get(MARKER_AUTOEXEC) for r in runs if r["cell"].startswith("FD")
            ),
        },
        "startup_form_onload": {
            "positive_control_fired": positive_form,
            "under_force_disable_zero": all(
                not r["markers_final"].get(MARKER_FORM) for r in runs if r["cell"].startswith("FD")
            ),
        },
        "autokeys": {
            "fired_anywhere": any(r["markers_final"].get(MARKER_AUTOKEYS) for r in runs),
            "verdict": "not reachable: AutoKeys is keyboard-triggered; no synthetic input was sent",
        },
    }

    return {
        "status": status,
        "exit_code": EXIT_CODES[status],
        "positive_control": {
            "exact_three_runs": positive_exact,
            "all_valid": positive_valid,
            "autoexec_marker_all_runs": positive_autoexec,
            "form_marker_all_runs": positive_form,
            "verified": positive_ok,
        },
        "recipes": {"FD": fd, "FD_DEL": fd_del, "any_clean": any_recipe_clean},
        "hash_ok": hash_ok,
        "new_pids": new_pids,
        "per_vector": per_vector,
        "notes": [
            "PASS requires the positive control verified (BOTH independent markers, exact N=3), "
            "at least one fully clean force-disable recipe, unchanged canonical hashes, and zero new MSACCESS PIDs.",
            "A missing positive-control marker makes every 'did not fire' result vacuous (STOP).",
            "forced-after-grace records Access instances that needed a PID kill after the grace period.",
        ],
    }


def self_check() -> int:
    import os

    from tests.helpers.dialog_watcher import WindowInfo, collect_windows, creation_time as dw_ct, process_image as dw_pi

    # Consume the watcher surface non-live so a field-name drift is caught pre-flight.
    sample = WindowInfo(hwnd=1, owner_pid=2, owner_image="x", class_name="#32770", title="t")
    assert sample.class_name == "#32770" and sample.title == "t"
    assert callable(collect_windows)
    self_pid = os.getpid()
    own_creation = dw_ct(self_pid)
    own_image = dw_pi(self_pid)
    assert own_creation is not None and own_image.lower().endswith(".exe")

    # Fail-closed identity/kill semantics (never kills without positive ownership).
    assert verify_access_identity(None, None)["owned"] is False
    assert verify_access_identity(self_pid, None)["owned"] is False
    assert verify_access_identity(self_pid, own_creation, {self_pid})["owned"] is False
    assert verify_access_identity(999_999_999, 123)["owned"] is False
    kill = kill_pid_scoped(self_pid, None)
    assert kill["result"] == "skipped-unverified-no-kill", kill
    kill_baseline = kill_pid_scoped(self_pid, own_creation, {self_pid})
    assert kill_baseline["result"] == "skipped-unverified-no-kill", kill_baseline

    before = canonical_hashes()
    import build_fixture  # noqa: F401  (import check only)
    import cell  # noqa: F401

    assert FIXTURE_DB_NAME == "armed.accdb"
    assert FORM_NAME == "SpikeStartupForm"
    assert [c["id"] for c in CELLS] == ["POS", "FD", "FD_DEL"]
    print(json.dumps({
        "canonical_files_hashed": len(before),
        "scratch": str(SCRATCH),
        "fixture_dir_exists": FIXTURE_DIR.exists(),
        "watcher_helpers_ok": True,
        "fail_closed_kill_ok": True,
        "matrix_cells": [c["id"] for c in CELLS],
        "exit_codes": EXIT_CODES,
    }, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--all", action="store_true", help="run the full build + 9-cell matrix")
    parser.add_argument("--self-check", action="store_true", help="bounded structural check; no COM")
    parser.add_argument("--overall-timeout", type=float, default=2400.0)
    args = parser.parse_args()

    if args.self_check:
        return self_check()
    if not args.all:
        parser.print_help()
        return 1

    started = time.monotonic()
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    baseline_pids = sorted(msaccess_pids())
    baseline_set = set(baseline_pids)
    hashes_before = canonical_hashes()
    write_json_flushed(EVIDENCE_DIR / "hashes_before.json", hashes_before)
    write_json_flushed(EVIDENCE_DIR / "baseline_msaccess_pids.json", baseline_pids)

    runs: list[dict] = []
    build: dict = {"ok": False, "error": "not-attempted"}
    overall_timeout_hit = False
    any_cell_timed_out = False
    infra_error: str | None = None
    hashes_after = hashes_before
    new_pids: list[int] = []

    try:
        build = build_fixture()
        if build.get("ok"):
            for cell in CELLS:
                stop_matrix = False
                for run_index in range(1, cell["runs"] + 1):
                    if time.monotonic() - started > args.overall_timeout:
                        overall_timeout_hit = True
                        stop_matrix = True
                        break
                    record = run_one(cell, run_index, baseline_set)
                    runs.append(record)
                    if record["timed_out"]:
                        # Never run further cells after a timeout.
                        any_cell_timed_out = True
                        stop_matrix = True
                        break
                if stop_matrix:
                    break
                if cell["id"] == "POS":
                    pos_runs = [r for r in runs if r["cell"] == "POS"]
                    positive_ok = len(pos_runs) == 3 and all(
                        run_is_valid(r) and r["markers_final"].get(MARKER_AUTOEXEC)
                        and r["markers_final"].get(MARKER_FORM)
                        for r in pos_runs
                    )
                    if not positive_ok:
                        # Positive control did not fire: stop, do not probe further.
                        break
    except Exception as exc:  # noqa: BLE001 - still attempt scoped cleanup + summary
        infra_error = repr(exc)

    # Aggregation is individually guarded so a failure still leaves the scoped cleanup
    # attempt, the hash diff and a failure summary on disk.
    survivors: list[dict] = []
    try:
        for record in runs:
            identity = record.get("identity") or {}
            pid = identity.get("access_pid")
            if pid and pid in msaccess_pids():
                survivors.append({"pid": pid, "cell": record.get("cell"),
                                  "run": record.get("run"), "identity": identity})
        for survivor in survivors:
            survivor["cleanup"] = kill_pid_scoped(
                survivor["pid"], survivor.get("identity", {}).get("access_creation"), baseline_set
            )
            wait_for_pid_exit(survivor["pid"], timeout=10.0)
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"orphan sweep failed: {exc!r}"

    try:
        hashes_after = canonical_hashes()
        hash_diff = diff_hashes(hashes_before, hashes_after)
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"post-hash failed: {exc!r}"
        hash_diff = {"unchanged": False, "changed": [], "added": [], "removed": []}

    try:
        final_pids = sorted(msaccess_pids())
        new_pids = sorted(set(final_pids) - baseline_set)
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"final pid scan failed: {exc!r}"
        final_pids, new_pids = [], []

    try:
        verdicts = compute_verdicts(
            [r for r in runs if r.get("cell")],
            build_ok=bool(build.get("ok")),
            overall_timeout_hit=overall_timeout_hit,
            any_cell_timed_out=any_cell_timed_out,
            hash_diff=hash_diff,
            new_pids=new_pids,
            infra_error=infra_error,
        )
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"verdict computation failed: {exc!r}"
        verdicts = {
            "status": "INFRA-error",
            "exit_code": EXIT_CODES["INFRA-error"],
            "recipes": {"FD": {"fully_clean": False}, "FD_DEL": {"fully_clean": False}},
            "positive_control": {"verified": False},
            "hash_ok": False,
        }

    summary = {
        "schema": "v2-spike.summary/1",
        "build": build,
        "baseline_msaccess_pids": baseline_pids,
        "runs": runs,
        "verdicts": verdicts,
        "status": verdicts["status"],
        "orphan_sweep": {"survivors": survivors, "final_msaccess_pids": final_pids,
                         "new_msaccess_pids": new_pids},
        "hash_protection": {"before": hashes_before, "after": hashes_after, "diff": hash_diff},
        "overall_timeout_hit": overall_timeout_hit,
        "any_cell_timed_out": any_cell_timed_out,
        "infra_error": infra_error,
        "elapsed_seconds": round(time.monotonic() - started, 1),
    }
    try:
        write_json_flushed(EVIDENCE_DIR / "summary.json", summary)
    except Exception:  # noqa: BLE001 - never let summary write hide the exit code
        pass

    print(json.dumps({
        "status": verdicts["status"],
        "exit_code": verdicts["exit_code"],
        "recipes": {"FD_clean": verdicts["recipes"]["FD"]["fully_clean"],
                    "FD_DEL_clean": verdicts["recipes"]["FD_DEL"]["fully_clean"]},
        "positive_verified": verdicts["positive_control"]["verified"],
        "hash_ok": verdicts["hash_ok"],
        "new_msaccess_pids": new_pids,
    }, indent=2, default=str))
    return verdicts["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
