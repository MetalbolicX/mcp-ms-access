"""Run one spike cell (one Access instance, one copy) in an isolated child process.

The parent runner owns the hard timeout and the PID-scoped hard kill; this child
writes its identity and observations incrementally so a blocked COM call still
leaves readable evidence. This child never kills anything except, best-effort, its
own captured Access PID during graceful shutdown.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
from pathlib import Path

from spike_common import (
    ALL_MARKERS,
    STARTUP_PROPERTY,
    list_marker_files,
    lock_files,
    msaccess_pids,
    process_image,
    creation_time,
    verify_access_identity,
    write_json_flushed,
)

# Child exit codes (documented): 0 ok; 3 security readback mismatch; 4 open failed;
# 6 Access identity could not be positively verified (aborted before armed open);
# 5 unexpected fatal error.
EXIT_OK = 0
EXIT_SECURITY_MISMATCH = 3
EXIT_OPEN_FAILED = 4
EXIT_UNVERIFIED_IDENTITY = 6
EXIT_FATAL = 5


class State:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.lock = threading.Lock()
        self.payload: dict = {
            "schema": "v2-spike.cell/1",
            "markers": {name: False for name in ALL_MARKERS},
            "dialogs": [],
            "open_errors": [],
        }

    def record(self, **kwargs) -> None:
        with self.lock:
            self.payload.update(kwargs)
            write_json_flushed(self.path, self.payload)

    def append_dialog(self, dialog: dict) -> None:
        with self.lock:
            if dialog not in self.payload["dialogs"]:
                self.payload["dialogs"].append(dialog)
                write_json_flushed(self.path, self.payload)

    def snapshot(self) -> dict:
        with self.lock:
            return json.loads(json.dumps(self.payload, default=str))


def _observe_dialogs(stop: threading.Event, access_pid: int, state: State) -> None:
    from tests.helpers.dialog_watcher import collect_windows

    while not stop.is_set():
        try:
            for window in collect_windows({access_pid}):
                state.append_dialog({
                    "hwnd": hex(window.hwnd),
                    "owner_pid": window.owner_pid,
                    "owner_image": window.owner_image,
                    "class": window.class_name,
                    "title": window.title,
                    "is_dialog_class": window.class_name == "#32770",
                })
        except Exception as exc:  # noqa: BLE001 - observation must never crash the cell
            state.record(observer_error=str(exc))
        stop.wait(0.5)


def _read_dao_properties(database) -> dict:
    props: dict = {}
    try:
        for i in range(database.Properties.Count):
            prop = database.Properties(i)
            try:
                props[prop.Name] = str(prop.Value)
            except Exception as exc:  # noqa: BLE001
                props[prop.Name] = f"<unreadable: {exc}>"
    except Exception as exc:  # noqa: BLE001
        props["<error>"] = str(exc)
    return props


def _read_references(app) -> dict:
    try:
        count = int(app.References.Count)
        refs = []
        for i in range(count):
            ref = app.References(i)
            refs.append({"name": str(ref.Name), "full_path": str(ref.FullPath)})
        return {"count": count, "references": refs}
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)}


def _read_project(app) -> dict:
    result: dict = {}
    for attr in ("AllForms", "AllMacros", "AllModules", "AllReports"):
        try:
            collection = getattr(app.CurrentProject, attr)
            result[attr] = sorted(str(collection(i).Name) for i in range(collection.Count))
        except Exception as exc:  # noqa: BLE001
            result[attr] = f"<unreadable: {exc}>"
    try:
        result["path"] = str(app.CurrentProject.Path)
    except Exception as exc:  # noqa: BLE001
        result["path"] = f"<unreadable: {exc}>"
    return result


def _delete_startup_property(db_path: Path) -> dict:
    """DAO-only: remove the StartupForm property from a disposable copy."""
    import pythoncom
    import win32com.client

    record: dict = {"path": str(db_path), "property": STARTUP_PROPERTY}
    pythoncom.CoInitialize()
    engine = None
    database = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        database = engine.OpenDatabase(str(db_path), False, False)
        try:
            record["before"] = str(database.Properties(STARTUP_PROPERTY).Value)
        except Exception as exc:  # noqa: BLE001
            record["before"] = f"<absent: {exc}>"
        try:
            database.Properties.Delete(STARTUP_PROPERTY)
            record["delete_ok"] = True
        except Exception as exc:  # noqa: BLE001
            record["delete_ok"] = False
            record["delete_error"] = repr(exc)
        try:
            record["after"] = str(database.Properties(STARTUP_PROPERTY).Value)
        except Exception as exc:  # noqa: BLE001
            record["after"] = f"<absent: {exc}>"
    finally:
        if database is not None:
            try:
                database.Close()
            except Exception:
                pass
        database = None
        engine = None
        import gc

        gc.collect()
        pythoncom.CoUninitialize()
    return record


def run_cell(args: argparse.Namespace) -> int:
    import pythoncom
    import win32com.client

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    state = State(out_dir / "result.json")
    baseline = sorted(msaccess_pids())
    state.record(
        cell=args.cell,
        run=args.run,
        security_requested=args.security,
        db=args.db,
        baseline_msaccess_pids=baseline,
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
        markers=dict.fromkeys(ALL_MARKERS, False),
        child_pid=os.getpid(),
    )

    observer_stop = threading.Event()
    observer: threading.Thread | None = None
    access_pid: int | None = None

    if args.delete_startup:
        state.record(predispatch_delete_startup=_delete_startup_property(Path(args.db)))

    pythoncom.CoInitialize()
    app = None
    try:
        app = win32com.client.DispatchEx("Access.Application")
        # Capture identity BEFORE opening the armed file, and verify it fail-closed.
        # The flushed identity file must exist before the armed open.
        try:
            hwnd = int(app.hWndAccessApp())
            import win32process

            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            access_pid = int(pid)
            state.record(access_identity={
                "method": "hWndAccessApp",
                "hwnd": hex(hwnd),
                "access_pid": access_pid,
                "access_image": process_image(access_pid),
                "access_creation": creation_time(access_pid),
                "captured_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            })
        except Exception as exc:  # noqa: BLE001
            owned = sorted(msaccess_pids() - set(baseline))
            if len(owned) == 1:
                access_pid = owned[0]
            state.record(access_identity={
                "method": "baseline-diff",
                "hwnd_error": str(exc),
                "access_pid": access_pid,
                "owned_new_pids": owned,
                "access_image": process_image(access_pid) if access_pid else None,
                "access_creation": creation_time(access_pid) if access_pid else None,
                "captured_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            })

        identity = state.snapshot().get("access_identity", {})
        verification = verify_access_identity(
            identity.get("access_pid"), identity.get("access_creation"), set(baseline)
        )
        state.record(identity_verification=verification)
        # Flush the parent-readable identity file before any armed open.
        write_json_flushed(out_dir / "identity.json", {**identity, "verification": verification})
        if not verification["owned"]:
            state.record(aborted="Access identity not positively verified; armed open refused")
            return EXIT_UNVERIFIED_IDENTITY

        observer = threading.Thread(
            target=_observe_dialogs, args=(observer_stop, access_pid, state), daemon=True
        )
        observer.start()
        state.record(observer_started=True)

        try:
            app.Visible = False
        except Exception as exc:  # noqa: BLE001
            state.record(visible_error=str(exc))
        try:
            app.UserControl = False
        except Exception as exc:  # noqa: BLE001
            state.record(usercontrol_error=str(exc))

        app.AutomationSecurity = args.security
        readback = int(app.AutomationSecurity)
        state.record(
            security_readback=readback,
            security_readback_matches=(readback == args.security),
        )
        if readback != args.security:
            state.record(aborted="AutomationSecurity readback mismatch; not opening armed file")
            return EXIT_SECURITY_MISMATCH

        state.record(markers_before_open=list_marker_files(out_dir))

        open_started = time.monotonic()
        try:
            app.OpenCurrentDatabase(str(args.db))
            state.record(
                open_ok=True,
                open_seconds=round(time.monotonic() - open_started, 3),
            )
        except Exception as exc:  # noqa: BLE001
            state.record(
                open_ok=False,
                open_seconds=round(time.monotonic() - open_started, 3),
                open_error=repr(exc),
            )
            return EXIT_OPEN_FAILED

        # Poll for per-vector markers.
        poll_deadline = time.monotonic() + args.poll_seconds
        while time.monotonic() < poll_deadline:
            if all((out_dir / name).exists() for name in ALL_MARKERS):
                break
            time.sleep(0.5)
        state.record(
            markers={name: (out_dir / name).exists() for name in ALL_MARKERS},
            markers_polled=list_marker_files(out_dir),
        )

        # Tier 1 (DAO startup properties) and Tier 2 (references) read points.
        try:
            database = app.CurrentDb()
            state.record(tier1_dao_properties=_read_dao_properties(database))
        except Exception as exc:  # noqa: BLE001
            state.record(tier1_dao_properties={"<error>": str(exc)})
        state.record(tier2_references=_read_references(app))
        state.record(project_objects=_read_project(app))

        # Graceful shutdown (the parent still owns the hard kill).
        try:
            app.CloseCurrentDatabase()
            state.record(close_current_ok=True)
        except Exception as exc:  # noqa: BLE001
            state.record(close_current_ok=False, close_error=str(exc))
        try:
            app.Quit()
            state.record(quit_ok=True)
        except Exception as exc:  # noqa: BLE001
            state.record(quit_ok=False, quit_error=str(exc))
        app = None
    finally:
        observer_stop.set()
        if observer is not None:
            observer.join(timeout=2.0)
        try:
            state.record(
                markers_after=list_marker_files(out_dir),
                locks_after=lock_files(out_dir),
                finished_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
            )
        except Exception:
            pass
        app = None
        pythoncom.CoUninitialize()
    return EXIT_OK


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cell", required=True)
    parser.add_argument("--run", type=int, required=True)
    parser.add_argument("--db", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--security", type=int, required=True)
    parser.add_argument("--poll-seconds", type=float, default=20.0)
    parser.add_argument("--delete-startup", action="store_true")
    args = parser.parse_args()
    try:
        return run_cell(args)
    except Exception as exc:  # noqa: BLE001 - a crash is evidence, not silence
        try:
            write_json_flushed(Path(args.out_dir) / "result.json", {"fatal": repr(exc)})
        except Exception:
            pass
        print(f"CELL_FATAL: {exc!r}", file=sys.stderr)
        return EXIT_FATAL


if __name__ == "__main__":
    raise SystemExit(main())
