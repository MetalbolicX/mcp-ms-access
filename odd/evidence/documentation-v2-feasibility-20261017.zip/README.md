# v2 feasibility spike — scratch harness (throwaway; parent removes after validation)

Scope: **experiment only**. No production code, no canonical-fixture edits, no commits.
Spec: `odd/tasks/documentation-workflows-v2.md` → "Agreed execution order" + "Spike protocol".

## What it decides

Tier 2 (instantiation-level reader) premise: can `Access.Application` be used to open a
database that carries auto-run objects (`AutoExec`, a `StartupForm`) **without executing
any of them**, under `AutomationSecurity = 3` (force-disable)?

Exit condition (verbatim from the protocol): PASS = the positive control fires AND a
recipe with zero markers, zero dialogs, clean PID reap across all runs. Otherwise STOP
with evidence. AutoKeys is keyboard-triggered and is recorded as not reachable (no
synthetic keystrokes).

## Exact command (launch via the parent's background runner — takes minutes, do not run foreground)

```powershell
.venv\Scripts\python.exe db\fixtures\e2e-v2-spike-20261017-db3efa7e\run_spike.py --all
```

Bounded preflight already run by the spike agent (no Access/COM):

```powershell
.venv\Scripts\python.exe db\fixtures\e2e-v2-spike-20261017-db3efa7e\run_spike.py --self-check
.venv\Scripts\python.exe db\fixtures\e2e-v2-spike-20261017-db3efa7e\probe_dao.py
```

## Safety envelope

- Fresh **`DispatchEx`** Access instances only; never reuses an existing session.
- Identity (`access_pid` + creation time) is captured **before** opening the armed file,
  and the flushed `identity.json` / `build_identity.json` must exist before the open.
- Ownership is **fail-closed**: an armed open (and every kill) requires a pid absent from
  the baseline, a non-null captured creation time, a live matching creation time, and the
  `MSACCESS.EXE` image. `kill_pid_scoped` performs **no kill** when `expected_creation` is
  null or any proof fails; it never uses `/IM`.
- Foreign `MSACCESS.EXE` PIDs present at baseline are recorded, protected, and never
  killed. `AutomationSecurity` readback is verified in the child **and** the builder
  before an armed/armed-build open proceeds.
- Canonical files (`db/fixtures/documentation/**`, `db/northwind.accdb`) are sha256-hashed
  before and after; PASS additionally requires unchanged hashes and zero new MSACCESS PIDs.
- Dialog observation reuses `tests/helpers/dialog_watcher.py` (`collect_windows`) — read
  only. No dialog/trust-center/machine setting is changed.
- Per-cell child timeout (`CELL_TIMEOUT = 120 s`); the parent owns the hard kill and the
  scoped orphan sweep, so a blocked COM call is never left to the child's `finally`.
- A subprocess timeout or an overall-timeout stops the matrix (no retries, no silent
  skip/resume). A failed positive control stops after the POS rows (no follow-on probe).
- All writes stay under this scratch root; the runner never deletes evidence.

## Fixture build discipline

`build_fixture.py` builds `fixture/armed.accdb`: DAO-only table, then `Access.Application`
opens a database with **no auto-run object**; the module loads first, the startup form is
created and its `OnLoad = "=FormLoadMarker()"` is set, the `StartupForm` database property
is set, macros load under neutral names, and only then `AutoKeys` and `AutoExec` are armed —
last, immediately before close. The armed file is never reopened by the builder.

Per-vector markers (distinct files, so one vector cannot credit the other):

| vector | marker |
| --- | --- |
| AutoExec | `autoexec_executed.marker` |
| startup form `OnLoad` | `form_onload_executed.marker` |
| AutoKeys | `autokeys_executed.marker` |
| ManualMarker (never invoked) | `manual_executed.marker` |

## Matrix (authorized 9-cell matrix; `N=3` each)

| cell | security | copy | expectation |
| --- | --- | --- | --- |
| `POS` | 1 (low) | unchanged | positive control: AutoExec **and** form markers must both fire |
| `FD` | 3 | unchanged | zero markers of any vector |
| `FD_DEL` | 3 | `StartupForm` DAO property deleted | zero markers of any vector |

PASS = positive control verified (both independent markers, exact N=3) **and** ≥1 force-disable
recipe fully clean (rc=0, opened, readback requested, observer working, zero markers of any
vector, zero dialogs, zero locks, no residual owned PID, and delete confirmed for `FD_DEL`) **and**
canonical hashes unchanged **and** zero new MSACCESS PIDs. Marker state is read from disk
after cleanup (never trusted from the child's JSON).

Exit codes: `0` PASS, `10` STOP-inconclusive-positive-control, `11` STOP-recipe-not-clean,
`12` STOP-execution-timeout, `13` STOP-integrity, `20` BLOCKED-build, `21` BLOCKED-overall-timeout,
`30` INFRA-error. A STOP is a nonzero exit.

## Evidence

```
evidence/
  hashes_before.json, baseline_msaccess_pids.json
  build_result.json, build_stdout.txt, build_stderr.txt, dao_probe/probe.json
  cells/<cell>/run_<n>/{identity.json,result.json,run_record.json,stdout.txt,stderr.txt,*.marker}
  summary.json          <- verdicts, orphan sweep, hash diff
```
