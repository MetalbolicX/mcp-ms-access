"""Build the armed startup-form spike fixture without ever running startup code.

Build-order discipline (mirrors scripts/generate_documentation_fixtures.py):

1. DAO-only creation of ``armed.accdb`` with a neutral table.
2. ``Access.Application`` opens the database while it has *no* auto-run object:
   no ``AutoExec`` macro, no ``AutoKeys`` group, and no ``StartupForm`` database
   property yet.
3. The VBA module is loaded first (so the form's expression resolves), then the
   startup form is created and saved, then the ``StartupForm`` database property
   is set, then the macros are loaded under neutral names.
4. Only at the very end are the auto-run-adjacent names armed: ``AutoKeys`` then
   ``AutoExec``, immediately before the database closes.
5. The armed database is never reopened by the builder.

If any step fails the builder raises; the outer runner then reports a concrete
blocker instead of improvising.
"""
from __future__ import annotations

import argparse
import gc
import json
import sys
from pathlib import Path

from spike_common import (
    AC_FORM,
    AC_MACRO,
    AC_MODULE,
    AC_SAVE_YES,
    AUTOEXEC_ARMED,
    AUTOEXEC_CONTROL,
    AUTOKEYS_ARMED,
    AUTOKEYS_CONTROL,
    DB_TEXT,
    FIXTURE_DB_NAME,
    FORM_NAME,
    MANUAL_MACRO_NAME,
    MARKER_AUTOEXEC,
    MARKER_AUTOKEYS,
    MARKER_FORM,
    MARKER_MANUAL,
    MODULE_NAME,
    MSO_FORCE_DISABLE,
    STARTUP_PROPERTY,
    creation_time,
    kill_pid_scoped,
    list_marker_files,
    lock_files,
    msaccess_pids,
    process_image,
    verify_access_identity,
    write_json_flushed,
)

LOCALE = ";LANGID=0x0409;CP=1252;COUNTRY=0"

VBA_MODULE_SOURCE = r'''Option Compare Database
Option Explicit

Private Sub WriteSpikeMarker(ByVal markerFileName As String)
    Dim markerPath As String
    markerPath = Application.CurrentProject.Path & "\" & markerFileName
    Open markerPath For Output As #1
    Print #1, "spike fixture executed"
    Close #1
End Sub

Public Function AutoExecMarker() As Boolean
    WriteSpikeMarker "autoexec_executed.marker"
    AutoExecMarker = True
End Function

Public Function FormLoadMarker() As Boolean
    WriteSpikeMarker "form_onload_executed.marker"
    FormLoadMarker = True
End Function

Public Function AutoKeysMarker() As Boolean
    WriteSpikeMarker "autokeys_executed.marker"
    AutoKeysMarker = True
End Function

Public Function ManualVectorMarker() As Boolean
    WriteSpikeMarker "manual_executed.marker"
    ManualVectorMarker = True
End Function
'''

AUTOEXEC_MACRO_SOURCE = '''Version =196611
ColumnsShown =0
Begin
    Action ="RunCode"
    Argument ="AutoExecMarker()"
End
'''

AUTOKEYS_MACRO_SOURCE = '''Version =196611
ColumnsShown =0
Begin
    MacroName ="^+{F12}"
    Action ="RunCode"
    Argument ="AutoKeysMarker()"
End
'''

MANUAL_MACRO_SOURCE = '''Version =196611
ColumnsShown =0
Begin
    Action ="RunCode"
    Argument ="ManualVectorMarker()"
End
'''


def _write_text_sources(scratch: Path) -> dict[str, Path]:
    paths = {
        "module": scratch / "spike_module.bas",
        "autoexec": scratch / "spike_autoexec.txt",
        "autokeys": scratch / "spike_autokeys.txt",
        "manual": scratch / "spike_manual.txt",
    }
    paths["module"].write_text(VBA_MODULE_SOURCE, encoding="utf-8", newline="\r\n")
    paths["autoexec"].write_text(AUTOEXEC_MACRO_SOURCE, encoding="utf-8", newline="\r\n")
    paths["autokeys"].write_text(AUTOKEYS_MACRO_SOURCE, encoding="utf-8", newline="\r\n")
    paths["manual"].write_text(MANUAL_MACRO_SOURCE, encoding="utf-8", newline="\r\n")
    return paths


def _create_dao_database(db_path: Path) -> None:
    import pythoncom
    import win32com.client

    pythoncom.CoInitialize()
    engine = None
    db = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        db = engine.CreateDatabase(str(db_path), LOCALE, 128)
        db.Execute(
            "CREATE TABLE SpikeNotes (NoteID LONG NOT NULL, [Note] TEXT(50), "
            "CONSTRAINT PK_SpikeNotes PRIMARY KEY (NoteID))",
            128,
        )
        db.TableDefs.Refresh()
        db.Execute("INSERT INTO SpikeNotes (NoteID, [Note]) VALUES (1, 'spike note')", 128)
    finally:
        if db is not None:
            try:
                db.Close()
            except Exception:
                pass
        db = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()


def _read_back(path: Path) -> dict:
    import pythoncom
    import win32com.client

    pythoncom.CoInitialize()
    engine = None
    db = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        db = engine.OpenDatabase(str(path), False, True)
        props: dict[str, str] = {}
        try:
            for i in range(db.Properties.Count):
                prop = db.Properties(i)
                try:
                    props[prop.Name] = str(prop.Value)
                except Exception as exc:  # noqa: BLE001 - record, never guess
                    props[prop.Name] = f"<unreadable: {exc}>"
        except Exception as exc:  # noqa: BLE001
            props["<properties>"] = f"<unreadable: {exc}>"
        containers: dict[str, list[str]] = {}
        for container_name in ("Forms", "Reports", "Scripts", "Modules", "Tables"):
            try:
                container = db.Containers(container_name)
                names = []
                for i in range(container.Documents.Count):
                    names.append(str(container.Documents(i).Name))
                containers[container_name] = sorted(names)
            except Exception as exc:  # noqa: BLE001
                containers[container_name] = [f"<unreadable: {exc}>"]
        return {"properties": props, "containers": containers}
    finally:
        if db is not None:
            try:
                db.Close()
            except Exception:
                pass
        db = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()


def _set_startup_property(app) -> dict:
    """Set the StartupForm database property, creating it when absent."""
    record: dict = {"property": STARTUP_PROPERTY, "value": FORM_NAME}
    database = app.CurrentDb()
    try:
        database.Properties(STARTUP_PROPERTY).Value = FORM_NAME
        record["mode"] = "existing"
    except Exception as exc:  # noqa: BLE001 - create when the property is absent
        record["existing_error"] = str(exc)
        prop = database.CreateProperty(STARTUP_PROPERTY, DB_TEXT, FORM_NAME)
        database.Properties.Append(prop)
        record["mode"] = "created"
    record["readback"] = str(database.Properties(STARTUP_PROPERTY).Value)
    return record


def _build_access_phase(db_path: Path, sources: dict[str, Path]) -> dict:
    import win32com.client

    report: dict = {}
    app = None
    access_pid: int | None = None
    access_creation: int | None = None
    baseline = set(msaccess_pids())
    report["baseline_msaccess_pids"] = sorted(baseline)
    try:
        app = win32com.client.DispatchEx("Access.Application")
        try:
            import win32process

            hwnd = int(app.hWndAccessApp())
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            access_pid = int(pid)
            access_creation = creation_time(access_pid)
        except Exception as exc:  # noqa: BLE001
            report["identity_error"] = str(exc)
        report["access_identity"] = {
            "access_pid": access_pid,
            "access_creation": access_creation,
            "access_image": process_image(access_pid) if access_pid else None,
        }
        verification = verify_access_identity(access_pid, access_creation, baseline)
        report["identity_verification"] = verification
        write_json_flushed(
            db_path.parent / "build_identity.json",
            {**report["access_identity"], "verification": verification},
        )
        if not verification["owned"]:
            raise RuntimeError(
                f"Access identity not positively verified; build refused: {verification}"
            )
        app.Visible = False
        app.UserControl = False
        app.AutomationSecurity = MSO_FORCE_DISABLE
        security_readback = int(app.AutomationSecurity)
        report["security_readback"] = security_readback
        if security_readback != MSO_FORCE_DISABLE:
            raise RuntimeError(
                f"AutomationSecurity readback {security_readback} != force-disable "
                f"{MSO_FORCE_DISABLE}; build refused"
            )
        app.OpenCurrentDatabase(str(db_path))
        report["opened"] = True

        app.LoadFromText(AC_MODULE, MODULE_NAME, str(sources["module"]))
        report["module_loaded"] = MODULE_NAME

        form = app.CreateForm()
        created_name = str(form.Name)
        report["form_default_name"] = created_name
        try:
            form.OnLoad = "=FormLoadMarker()"
            report["onload_set_via"] = "attribute"
        except Exception as exc:  # noqa: BLE001
            report["onload_attribute_error"] = str(exc)
            form.Properties("OnLoad").Value = "=FormLoadMarker()"
            report["onload_set_via"] = "properties"
        try:
            report["onload_readback"] = str(form.OnLoad)
        except Exception as exc:  # noqa: BLE001
            report["onload_readback"] = f"<unreadable: {exc}>"
        app.DoCmd.Close(AC_FORM, created_name, AC_SAVE_YES)
        app.DoCmd.Rename(FORM_NAME, AC_FORM, created_name)
        report["form_renamed_to"] = FORM_NAME

        report["startup_property"] = _set_startup_property(app)

        app.LoadFromText(AC_MACRO, AUTOEXEC_CONTROL, str(sources["autoexec"]))
        app.LoadFromText(AC_MACRO, MANUAL_MACRO_NAME, str(sources["manual"]))
        app.LoadFromText(AC_MACRO, AUTOKEYS_CONTROL, str(sources["autokeys"]))
        report["macros_loaded"] = [AUTOEXEC_CONTROL, MANUAL_MACRO_NAME, AUTOKEYS_CONTROL]

        # Arm the auto-run-adjacent names last, then close without reopening.
        app.DoCmd.Rename(AUTOKEYS_ARMED, AC_MACRO, AUTOKEYS_CONTROL)
        app.DoCmd.Rename(AUTOEXEC_ARMED, AC_MACRO, AUTOEXEC_CONTROL)
        report["armed"] = [AUTOKEYS_ARMED, AUTOEXEC_ARMED]

        app.CloseCurrentDatabase()
        report["closed"] = True
    finally:
        if app is not None:
            try:
                app.Quit()
            except Exception:
                pass
        app = None
        if access_pid is not None:
            import time as _time

            deadline = _time.monotonic() + 20.0
            while access_pid in msaccess_pids() and _time.monotonic() < deadline:
                _time.sleep(0.5)
            report["reap"] = kill_pid_scoped(access_pid, access_creation, baseline)
    return report


def build(out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    db_path = out_dir / FIXTURE_DB_NAME
    if db_path.exists():
        raise RuntimeError(f"refusing to overwrite existing fixture: {db_path}")

    sources = _write_text_sources(out_dir)
    _create_dao_database(db_path)
    # DAO's phase balances its own COM apartment; Access needs a new one.
    import pythoncom

    pythoncom.CoInitialize()
    try:
        access_report = _build_access_phase(db_path, sources)
    finally:
        pythoncom.CoUninitialize()
    readback = _read_back(db_path)

    markers = list_marker_files(out_dir)
    locks = lock_files(out_dir)
    if markers:
        raise RuntimeError(f"build executed startup code: markers present {markers}")
    if locks:
        raise RuntimeError(f"build left lock files: {locks}")

    startup_value = readback["properties"].get(STARTUP_PROPERTY)
    if startup_value != FORM_NAME:
        raise RuntimeError(
            f"StartupForm property not armed after build: {startup_value!r}"
        )
    scripts = set(readback["containers"].get("Scripts", []))
    missing = {AUTOEXEC_ARMED, AUTOKEYS_ARMED, MANUAL_MACRO_NAME} - scripts
    if missing:
        raise RuntimeError(f"armed macros missing from DAO Scripts container: {sorted(missing)}")
    forms = set(readback["containers"].get("Forms", []))
    modules = set(readback["containers"].get("Modules", []))

    report = {
        "schema": "v2-spike.build/1",
        "fixture": str(db_path),
        "access_phase": access_report,
        "dao_readback": readback,
        "markers_after_build": markers,
        "locks_after_build": locks,
        "forms_container_has_startup_form": FORM_NAME in forms,
        "modules_container_has_module": MODULE_NAME in modules,
        "expected_markers": [MARKER_AUTOEXEC, MARKER_FORM, MARKER_AUTOKEYS, MARKER_MANUAL],
    }
    write_json_flushed(out_dir / "build_report.json", report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = build(args.out_dir)
    except Exception as exc:  # noqa: BLE001 - report the blocker, exit nonzero
        print(f"BUILD_BLOCKER: {exc}", file=sys.stderr)
        write_json_flushed(args.out_dir / "build_report.json", {"error": str(exc)})
        return 2
    print(json.dumps({
        "fixture": report["fixture"],
        "forms_container_has_startup_form": report["forms_container_has_startup_form"],
        "modules_container_has_module": report["modules_container_has_module"],
    }, ensure_ascii=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
