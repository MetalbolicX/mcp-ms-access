"""Shared constants and safety helpers for the non-VBA AutoExec canary spike.

This is throwaway spike tooling, not production code. It lives entirely under
``db/fixtures/e2e-v2-spike-nonvba-<id>/`` and never edits canonical fixtures.

Safety contract enforced here:

* Every Access instance is a fresh ``DispatchEx`` owned by this spike.
* Process kills are PID-scoped and creation-time verified; never image-name kills.
* An existing ``MSACCESS.EXE`` (foreign baseline PID) is never touched.
* Validators refuse to open an armed copy unless the captured Access PID is proven
  owned (pid absent from the baseline, non-null captured creation, live matching
  creation, and image == MSACCESS.EXE) and no lock residue remains.
* Dialog observation reuses ``tests/helpers/dialog_watcher.py`` read-only helpers.
* No registry / Trust Center / trusted-location / Access-options mutation anywhere.
"""
from __future__ import annotations

import gc
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

SCRATCH_DIR = Path(__file__).resolve().parent
ROOT = SCRATCH_DIR.parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# --- fixture vocabulary -----------------------------------------------------
FIXTURE_DB_NAME = "armed.accdb"
CANARY_TABLE = "CanaryRows"
CANARY_QUERY = "qryAppendCanary"
CANARY_PROBE_ID = 1
CANARY_LABEL = "NON_VBA_AUTOEXEC"
# Exact saved append query: one known row, no other effect. Bracketed identifiers
# follow the L6 lesson (a previously reserved DDL identifier broke the build).
CANARY_INSERT_SQL = (
    "INSERT INTO CanaryRows ([ProbeID], [Label]) VALUES (1, 'NON_VBA_AUTOEXEC')"
)
CANARY_EXPECTED_ROW = {"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}
# Neutral macro name; renamed to AutoExec LAST, immediately before the build closes.
MACRO_NEUTRAL_NAME = "NonVBAProbe"
AUTOEXEC_ARMED = "AutoExec"

# msoAutomationSecurity values
MSO_LOW = 1
MSO_FORCE_DISABLE = 3

# DAO constants
DB_TEXT = 10
AC_FORM = 2
AC_MACRO = 4
AC_MODULE = 5
AC_SAVE_YES = 1
DB_OPEN_SNAPSHOT = 4
DB_VERSION = 128
LOCALE = ";LANGID=0x0409;CP=1252;COUNTRY=0"

# Tokens that must never appear in the captured non-VBA macro text.
FORBIDDEN_MACRO_TOKENS = ("runcode", "function", "onload", "startupform", "vbe")

# --- canonical protection ---------------------------------------------------
CANONICAL_TARGETS = (
    ROOT / "db" / "fixtures" / "documentation",
    ROOT / "db" / "northwind.accdb",
)


def expected_row() -> dict[str, Any]:
    return dict(CANARY_EXPECTED_ROW)


def rows_match_expected(rows: Any) -> bool:
    """Exactly one row, exactly the known tuple (ordered field comparison)."""
    return isinstance(rows, list) and rows == [CANARY_EXPECTED_ROW]


def rows_empty(rows: Any) -> bool:
    return isinstance(rows, list) and rows == []


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_hashes() -> dict[str, dict[str, Any]]:
    """Return {relative_path: {sha256, bytes}} for every canonical target file."""
    result: dict[str, dict[str, Any]] = {}
    for target in CANONICAL_TARGETS:
        files = [target] if target.is_file() else sorted(p for p in target.rglob("*") if p.is_file())
        for path in files:
            result[str(path.relative_to(ROOT)).replace("\\", "/")] = {
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
    return result


def diff_hashes(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_keys = set(before)
    after_keys = set(after)
    changed = [k for k in before_keys & after_keys if before[k] != after[k]]
    return {
        "unchanged": not changed and before_keys == after_keys,
        "changed": sorted(changed),
        "added": sorted(after_keys - before_keys),
        "removed": sorted(before_keys - after_keys),
    }


# --- process helpers --------------------------------------------------------
def msaccess_pids() -> set[int]:
    """Return running MSACCESS.EXE PIDs via argv (no shell, so no /FI mangling)."""
    completed = subprocess.run(
        ["tasklist", "/FI", "IMAGENAME eq MSACCESS.EXE", "/NH"],
        capture_output=True, text=True, timeout=30, check=False,
    )
    pids: set[int] = set()
    for line in completed.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0].upper() == "MSACCESS.EXE" and parts[1].isdigit():
            pids.add(int(parts[1]))
    return pids


def creation_time(pid: int) -> int | None:
    """Creation time in 100ns ticks using the existing watcher helper."""
    from tests.helpers.dialog_watcher import creation_time as _ct

    return _ct(pid)


def process_image(pid: int) -> str:
    from tests.helpers.dialog_watcher import process_image as _pi

    return _pi(pid)


MSACCESS_IMAGE = "MSACCESS.EXE"


def verify_access_identity(
    pid: int | None,
    expected_creation: int | None,
    baseline_pids: set[int] | None = None,
) -> dict[str, Any]:
    """Fail-closed ownership proof for a captured Access PID.

    Ownership requires ALL of: a pid, a pid absent from the foreign baseline, a
    non-null captured creation time, a live process whose current creation time still
    equals the captured value, and the ``MSACCESS.EXE`` image. Anything short of that
    is unowned and must never be opened for an armed run nor killed.
    """
    record: dict[str, Any] = {
        "pid": pid,
        "expected_creation": expected_creation,
        "owned": False,
        "reasons": [],
    }
    if pid is None:
        record["reasons"].append("no-pid")
        return record
    if baseline_pids and pid in baseline_pids:
        record["reasons"].append("pid-in-baseline")
        return record
    if expected_creation is None:
        record["reasons"].append("no-captured-creation")
        return record
    observed = creation_time(pid)
    record["observed_creation"] = observed
    if observed is None:
        record["reasons"].append("not-running")
        return record
    if observed != expected_creation:
        record["reasons"].append("creation-mismatch")
        return record
    image = process_image(pid)
    record["image"] = image
    if image.upper() != MSACCESS_IMAGE:
        record["reasons"].append(f"image-not-{MSACCESS_IMAGE}")
        return record
    record["owned"] = True
    return record


def kill_pid_scoped(
    pid: int | None,
    expected_creation: int | None,
    baseline_pids: set[int] | None = None,
) -> dict[str, Any]:
    """Force-kill exactly ``pid`` only after a positive ownership proof.

    Fails CLOSED: with no captured creation, no live matching creation, a pid present
    in the foreign baseline, or a non-MSACCESS image, it performs no kill at all.
    Never uses ``/IM``.
    """
    record: dict[str, Any] = {"pid": pid, "expected_creation": expected_creation}
    verification = verify_access_identity(pid, expected_creation, baseline_pids)
    record["verification"] = verification
    if not verification["owned"]:
        record["result"] = "skipped-unverified-no-kill"
        return record
    completed = subprocess.run(
        ["taskkill", "/PID", str(pid), "/F"],
        capture_output=True, text=True, timeout=30, check=False,
    )
    record["result"] = "killed" if completed.returncode == 0 else "taskkill-failed"
    record["taskkill_stdout"] = completed.stdout.strip()
    record["taskkill_stderr"] = completed.stderr.strip()
    return record


def wait_for_pid_exit(pid: int | None, timeout: float = 15.0) -> bool:
    """Poll until ``pid`` is gone; return True when it exited within the grace period."""
    if pid is None:
        return True
    import time

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if pid not in msaccess_pids():
            return True
        time.sleep(0.5)
    return pid not in msaccess_pids()


def lock_file_for(db_path: Path) -> Path:
    return db_path.with_suffix(".laccdb")


def lock_files(directory: Path) -> list[str]:
    return sorted(p.name for p in directory.glob("*.laccdb"))


def wait_for_no_lock(db_path: Path, timeout: float = 10.0) -> bool:
    """Poll for the disappearance of the copy's own lock file (no deletion performed)."""
    import time

    lock = lock_file_for(db_path)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not lock.exists():
            return True
        time.sleep(0.5)
    return not lock.exists()


def write_json_flushed(path: Path, payload: Any) -> None:
    """Write JSON atomically-ish and fsync so the parent can read it mid-run."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n"
    with path.open("w", encoding="utf-8") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())


def decode_save_as_text(raw: bytes) -> str:
    """Decode a SaveAsText export (UTF-16-LE-with-BOM or 8-bit ANSI)."""
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16")
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def read_canary_snapshot(db_path: Path) -> dict[str, Any]:
    """Independent DAO-only observation of a disposable copy.

    Opens the copy through ``DAO.DBEngine.120``, records the full canary row set, the
    object inventory (Modules/Forms/Reports/Scripts containers, tables, QueryDefs) and
    the StartupForm property, then closes. It executes nothing and writes nothing.
    """
    import pythoncom
    import win32com.client

    record: dict[str, Any] = {
        "schema": "v2-spike-nonvba.dao-read/1",
        "db": str(db_path),
        "ok": False,
        "rows": [],
        "row_count": 0,
        "dao_error": None,
        "inventory_error": None,
        "canary_table_present": False,
        "querydefs": {},
        "tables": [],
        "containers": {},
        "startup_form_property": None,
    }
    pythoncom.CoInitialize()
    engine = None
    db = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        db = engine.OpenDatabase(str(db_path), False, True)
        try:
            tables = [str(db.TableDefs(i).Name) for i in range(db.TableDefs.Count)]
            record["tables"] = sorted(tables)
            record["canary_table_present"] = CANARY_TABLE in tables
            querydefs: dict[str, str] = {}
            for i in range(db.QueryDefs.Count):
                query = db.QueryDefs(i)
                try:
                    querydefs[str(query.Name)] = str(query.SQL)
                except Exception as exc:  # noqa: BLE001
                    querydefs[str(query.Name)] = f"<unreadable: {exc}>"
            record["querydefs"] = querydefs
            for container_name in ("Modules", "Forms", "Reports", "Scripts"):
                try:
                    container = db.Containers(container_name)
                    names = []
                    for i in range(container.Documents.Count):
                        names.append(str(container.Documents(i).Name))
                    record["containers"][container_name] = sorted(names)
                except Exception as exc:  # noqa: BLE001
                    record["containers"][container_name] = f"<unreadable: {exc}>"
            try:
                record["startup_form_property"] = str(db.Properties("StartupForm").Value)
            except Exception:
                record["startup_form_property"] = None
        except Exception as exc:  # noqa: BLE001
            record["inventory_error"] = repr(exc)

        rows: list[dict[str, Any]] = []
        recordset = db.OpenRecordset(
            f"SELECT [ProbeID], [Label] FROM {CANARY_TABLE} ORDER BY [ProbeID]",
            DB_OPEN_SNAPSHOT,
        )
        try:
            while not recordset.EOF:
                rows.append({
                    "ProbeID": int(recordset.Fields("ProbeID").Value),
                    "Label": str(recordset.Fields("Label").Value),
                })
                recordset.MoveNext()
        finally:
            recordset.Close()
        record["rows"] = rows
        record["row_count"] = len(rows)
        record["ok"] = True
    except Exception as exc:  # noqa: BLE001 - a read failure is evidence, not silence
        record["dao_error"] = repr(exc)
    finally:
        if db is not None:
            try:
                db.Close()
            except Exception:
                pass
        db = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()
    return record
