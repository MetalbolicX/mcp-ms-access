"""Outer runner for the non-VBA AutoExec canary spike.

Owns the safety envelope the child cannot: the per-cell hard timeout, fail-closed
PID-scoped hard kills, parent-side dialog sampling on timeout, the two independent
DAO canary-row observations per run (before the armed open / after Access is reaped),
canonical-file hash protection, orphan sweep, and the evidence bundle.

Usage (launch through the parent's background runner; this takes minutes)::

    .venv\\Scripts\\python.exe db\\fixtures\\e2e-v2-spike-nonvba-<id>\\run_spike.py --all

Bounded self check (no Access, no COM, no DAO)::

    .venv\\Scripts\\python.exe db\\fixtures\\e2e-v2-spike-nonvba-<id>\\run_spike.py --self-check

Exit codes (a STOP is explicitly nonzero, never masked as success)::

    0  PASS
    10 STOP-inconclusive-positive-control (positive control did not insert the row, or
       a modal dialog blocked it; no synthetic input was sent)
    11 STOP-recipe-not-clean (ForceDisable did not suppress the non-VBA action, or a
       recipe run was invalid/left residue) -> security recipe rejected, Tier 2 gate
    12 STOP-execution-timeout (a cell timed out with no dialog evidence)
    13 STOP-integrity (canonical hash changed, foreign MSACCESS appeared, lock residue,
       pre-existing canary rows, unreadable DAO readback)
    20 BLOCKED-build
    21 BLOCKED-overall-timeout
    30 INFRA-error (unexpected runner failure)
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

from spike_common import (
    AUTOEXEC_ARMED,
    CANARY_LABEL,
    CANARY_PROBE_ID,
    CANARY_QUERY,
    FIXTURE_DB_NAME,
    MSO_FORCE_DISABLE,
    MSO_LOW,
    ROOT,
    canonical_hashes,
    diff_hashes,
    kill_pid_scoped,
    lock_files,
    msaccess_pids,
    rows_empty,
    rows_match_expected,
    verify_access_identity,
    wait_for_no_lock,
    wait_for_pid_exit,
    write_json_flushed,
)

SCRATCH = Path(__file__).resolve().parent
FIXTURE_DIR = SCRATCH / "fixture"
EVIDENCE_DIR = SCRATCH / "evidence"
BUILD_TIMEOUT = 240.0
CELL_TIMEOUT = 120.0
DAO_TIMEOUT = 90.0
SETTLE_SECONDS = 12.0

EXIT_CODES = {
    "PASS": 0,
    "STOP-inconclusive-positive-control": 10,
    "STOP-recipe-not-clean": 11,
    "STOP-execution-timeout": 12,
    "STOP-integrity": 13,
    "BLOCKED-build": 20,
    "BLOCKED-overall-timeout": 21,
    "INFRA-error": 30,
}

# Fresh-copy matrix, positive control first. No delete/neutralization cell: the
# question is exactly whether ForceDisable alone suppresses the non-VBA action.
CELLS = [
    {"id": "POS", "security": MSO_LOW, "runs": 3,
     "expect": "positive control: OpenQuery on the saved append query inserts exactly one canary row"},
    {"id": "FD", "security": MSO_FORCE_DISABLE, "runs": 3,
     "expect": "force-disable on unchanged copy: canary row set stays []"},
]


def _run_bounded(argv, cwd, timeout, stdout_path, stderr_path):
    with stdout_path.open("w", encoding="utf-8") as out, stderr_path.open("w", encoding="utf-8") as err:
        proc = subprocess.Popen(argv, cwd=str(cwd), stdout=out, stderr=err)
    timed_out = False
    try:
        returncode = proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        returncode = None
    return proc, returncode, timed_out


def _read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _parent_dialog_sample(access_pid):
    try:
        from tests.helpers.dialog_watcher import collect_windows

        windows = collect_windows({access_pid})
        return [
            {
                "hwnd": hex(w.hwnd),
                "owner_pid": w.owner_pid,
                "owner_image": w.owner_image,
                "class_name": w.class_name,
                "title": w.title,
                "is_dialog_class": w.class_name == "#32770",
            }
            for w in windows
        ]
    except Exception as exc:  # noqa: BLE001
        return [{"observer_error": str(exc)}]


def _dao_read(db_path: Path, phase: str, out_path: Path) -> dict:
    """Run the independent DAO row observer as its own bounded subprocess."""
    argv = [
        sys.executable, str(SCRATCH / "dao_read.py"),
        "--db", str(db_path),
        "--phase", phase,
        "--out", str(out_path),
    ]
    proc, rc, timed_out = _run_bounded(
        argv, SCRATCH, DAO_TIMEOUT,
        out_path.parent / f"dao_{phase}_stdout.txt",
        out_path.parent / f"dao_{phase}_stderr.txt",
    )
    if timed_out:
        proc.kill()
        proc.wait(timeout=15)
    snapshot = _read_json(out_path) or {"schema": "v2-spike-nonvba.dao-read/1", "ok": False,
                                        "rows": [], "dao_error": "no snapshot written"}
    snapshot = dict(snapshot)
    snapshot["returncode"] = rc
    snapshot["timed_out"] = timed_out
    snapshot["phase"] = phase
    return snapshot


def build_fixture() -> dict:
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    if FIXTURE_DIR.exists():
        return {"error": f"fixture dir already exists: {FIXTURE_DIR}", "ok": False}
    argv = [sys.executable, str(SCRATCH / "build_fixture.py"), "--out-dir", str(FIXTURE_DIR)]
    proc, rc, timed_out = _run_bounded(
        argv, SCRATCH, BUILD_TIMEOUT,
        EVIDENCE_DIR / "build_stdout.txt", EVIDENCE_DIR / "build_stderr.txt",
    )
    identity = _read_json(FIXTURE_DIR / "build_identity.json") or {}
    if timed_out:
        proc.kill()
        proc.wait(timeout=15)
    cleanup = kill_pid_scoped(identity.get("access_pid"), identity.get("access_creation"))
    report = _read_json(FIXTURE_DIR / "build_report.json") or {}
    ok = rc == 0 and not timed_out and "error" not in report
    result = {
        "returncode": rc,
        "timed_out": timed_out,
        "identity": identity,
        "cleanup": cleanup,
        "report": report,
        "ok": ok,
    }
    write_json_flushed(EVIDENCE_DIR / "build_result.json", result)
    return result


def run_one(cell: dict, run_index: int, baseline: set[int]) -> dict:
    run_dir = EVIDENCE_DIR / "cells" / cell["id"] / f"run_{run_index}"
    run_dir.mkdir(parents=True, exist_ok=True)
    copy = run_dir / FIXTURE_DB_NAME
    shutil.copy2(FIXTURE_DIR / FIXTURE_DB_NAME, copy)

    # Independent DAO observation #1: the fresh copy must show zero canary rows before
    # anything opens it through Access, and must leave no lock residue.
    before = _dao_read(copy, "before", run_dir / "rows_before.json")
    pre_locks_clear = wait_for_no_lock(copy, timeout=10.0)
    pre_locks = lock_files(run_dir)
    rows_before = before.get("rows") if isinstance(before.get("rows"), list) else []

    # Fail-closed: without an empty, readable pre-open observation and without a clear
    # lock state, the armed copy is never opened through Access.
    if before.get("ok") is not True or not pre_locks_clear:
        reason = (
            "pre-open DAO read failed" if before.get("ok") is not True
            else "pre-open lock residue"
        )
        record = {
            "cell": cell["id"],
            "run": run_index,
            "security_requested": cell["security"],
            "child_returncode": None,
            "child_returncode_after_kill": None,
            "timed_out": False,
            "aborted_before_open": reason,
            "identity": {},
            "identity_verification": None,
            "access_pid_in_baseline": None,
            "cleanup_after": {"result": "not-dispatched"},
            "reap_mode": "not-dispatched",
            "residual_owned_pid": False,
            "pre_locks_clear": pre_locks_clear,
            "pre_locks": pre_locks,
            "locks": lock_files(run_dir),
            "rows_before_read_ok": before.get("ok") is True,
            "rows_before_read_returncode": before.get("returncode"),
            "rows_before_read_timed_out": before.get("timed_out"),
            "rows_before_error": before.get("dao_error"),
            "rows_before": rows_before,
            "rows_before_count": len(rows_before),
            "rows_after_read_ok": False,
            "rows_after_read_returncode": None,
            "rows_after_read_timed_out": False,
            "rows_after_error": "not-read: aborted before armed open",
            "rows_after": [],
            "rows_after_count": 0,
            "rows_inserted_observed": [],
            "rows_unexpected": [],
            "before_snapshot": {
                "modules_container": before.get("containers", {}).get("Modules"),
                "forms_container": before.get("containers", {}).get("Forms"),
                "scripts_container": before.get("containers", {}).get("Scripts"),
                "startup_form_property": before.get("startup_form_property"),
                "canary_table_present": before.get("canary_table_present"),
                "querydef_present": CANARY_QUERY in (before.get("querydefs") or {}),
            },
            "after_snapshot": None,
            "dialogs": [],
            "timeout_dialogs": [],
            "all_observed_windows": [],
            "observer_started": False,
            "observer_error": None,
            "security_readback": None,
            "open_ok": None,
            "open_error": "not-open: aborted before armed open",
            "access_version": None,
            "armed_macro_present": None,
            "run_dir": str(run_dir.relative_to(ROOT)).replace("\\", "/"),
        }
        write_json_flushed(run_dir / "run_record.json", record)
        return record

    argv = [
        sys.executable, str(SCRATCH / "cell.py"),
        "--cell", cell["id"],
        "--run", str(run_index),
        "--db", str(copy),
        "--out-dir", str(run_dir),
        "--security", str(cell["security"]),
        "--settle-seconds", str(SETTLE_SECONDS),
    ]
    proc, child_rc, timed_out = _run_bounded(
        argv, SCRATCH, CELL_TIMEOUT,
        run_dir / "stdout.txt", run_dir / "stderr.txt",
    )
    identity = _read_json(run_dir / "identity.json") or {}
    access_pid = identity.get("access_pid")
    access_creation = identity.get("access_creation")

    timeout_dialogs: list = []
    if timed_out:
        # Observe before killing, then hard-kill by verified PID only.
        if access_pid:
            timeout_dialogs = _parent_dialog_sample(access_pid)
        cleanup_first = kill_pid_scoped(access_pid, access_creation, baseline)
        proc.kill()
        child_returncode_after_kill = proc.wait(timeout=15)
        reap_mode = "hard-timeout"
        wait_for_pid_exit(access_pid, timeout=10.0)
    else:
        child_returncode_after_kill = child_rc
        if access_pid is not None:
            if wait_for_pid_exit(access_pid, timeout=15.0):
                cleanup_first = {"pid": access_pid, "result": "exited-gracefully"}
                reap_mode = "graceful"
            else:
                cleanup_first = kill_pid_scoped(access_pid, access_creation, baseline)
                wait_for_pid_exit(access_pid, timeout=10.0)
                reap_mode = "forced-after-grace"
        else:
            cleanup_first = {"pid": None, "result": "no-pid-captured"}
            reap_mode = "no-pid-captured"

    # Independent DAO observation #2: only after Access is closed and reaped.
    wait_for_no_lock(copy, timeout=10.0)
    after = _dao_read(copy, "after", run_dir / "rows_after.json")

    result = _read_json(run_dir / "result.json") or {}
    dialogs = [d for d in result.get("dialogs", []) if d.get("is_dialog_class")]
    residual_owned_pid = bool(access_pid is not None and access_pid in msaccess_pids())
    locks = lock_files(run_dir)
    rows_after = after.get("rows") if isinstance(after.get("rows"), list) else []
    expected = {"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}
    rows_inserted_observed = [row for row in rows_after if row not in rows_before]
    rows_unexpected = [row for row in rows_after if row != expected]

    record = {
        "cell": cell["id"],
        "run": run_index,
        "security_requested": cell["security"],
        "child_returncode": child_rc,
        "child_returncode_after_kill": child_returncode_after_kill,
        "timed_out": timed_out,
        "identity": identity,
        "identity_verification": identity.get("verification"),
        "access_pid_in_baseline": access_pid in baseline if access_pid else None,
        "cleanup_after": cleanup_first,
        "reap_mode": reap_mode,
        "residual_owned_pid": residual_owned_pid,
        "pre_locks_clear": pre_locks_clear,
        "pre_locks": pre_locks,
        "locks": locks,
        "rows_before_read_ok": before.get("ok") is True,
        "rows_before_read_returncode": before.get("returncode"),
        "rows_before_read_timed_out": before.get("timed_out"),
        "rows_before_error": before.get("dao_error"),
        "rows_before": rows_before,
        "rows_before_count": len(rows_before),
        "rows_after_read_ok": after.get("ok") is True,
        "rows_after_read_returncode": after.get("returncode"),
        "rows_after_read_timed_out": after.get("timed_out"),
        "rows_after_error": after.get("dao_error"),
        "rows_after": rows_after,
        "rows_after_count": len(rows_after),
        "rows_inserted_observed": rows_inserted_observed,
        "rows_unexpected": rows_unexpected,
        "before_snapshot": {
            "modules_container": before.get("containers", {}).get("Modules"),
            "forms_container": before.get("containers", {}).get("Forms"),
            "scripts_container": before.get("containers", {}).get("Scripts"),
            "startup_form_property": before.get("startup_form_property"),
            "canary_table_present": before.get("canary_table_present"),
            "querydef_present": CANARY_QUERY in (before.get("querydefs") or {}),
        },
        "after_snapshot": {
            "modules_container": after.get("containers", {}).get("Modules"),
            "forms_container": after.get("containers", {}).get("Forms"),
            "scripts_container": after.get("containers", {}).get("Scripts"),
            "startup_form_property": after.get("startup_form_property"),
            "canary_table_present": after.get("canary_table_present"),
            "querydef_present": CANARY_QUERY in (after.get("querydefs") or {}),
        },
        "dialogs": dialogs,
        "timeout_dialogs": timeout_dialogs,
        "all_observed_windows": result.get("dialogs", []),
        "observer_started": result.get("observer_started") is True,
        "observer_error": result.get("observer_error"),
        "security_readback": result.get("security_readback"),
        "open_ok": result.get("open_ok"),
        "open_error": result.get("open_error"),
        "access_version": result.get("access_version"),
        "armed_macro_present": AUTOEXEC_ARMED in (after.get("containers", {}).get("Scripts") or []),
        "run_dir": str(run_dir.relative_to(ROOT)).replace("\\", "/"),
    }
    write_json_flushed(run_dir / "run_record.json", record)
    return record


def run_is_valid(record: dict) -> bool:
    """A run only counts as evidence when the harness itself worked and stayed honest."""
    return (
        not record.get("timed_out")
        and record.get("child_returncode") == 0
        and record.get("open_ok") is True
        and record.get("security_readback") == record.get("security_requested")
        and record.get("observer_started") is True
        and not record.get("observer_error")
        and record.get("residual_owned_pid") is False
        and record.get("access_pid_in_baseline") is not True
        and record.get("pre_locks_clear") is True
        and not record.get("locks")
        and record.get("rows_before_read_ok") is True
        and record.get("rows_before") == []
        and record.get("rows_after_read_ok") is True
    )


def compute_verdicts(
    runs: list[dict],
    *,
    build_ok: bool,
    overall_timeout_hit: bool,
    any_cell_timed_out: bool,
    timeout_dialog_blocked: bool,
    positive_dialog_observed: bool,
    integrity_errors: list[str],
    hash_diff: dict,
    new_pids: list[int],
    infra_error: str | None,
) -> dict:
    pos = [r for r in runs if r["cell"] == "POS"]
    fd = [r for r in runs if r["cell"] == "FD"]

    positive_exact = len(pos) == 3
    positive_valid = positive_exact and all(run_is_valid(r) for r in pos)
    positive_inserted = positive_valid and all(
        rows_match_expected(r.get("rows_after")) for r in pos
    )
    positive_ok = positive_valid and positive_inserted

    fd_insertions = [
        r["run"] for r in fd
        if isinstance(r.get("rows_after"), list) and not rows_empty(r.get("rows_after"))
    ]
    fd_failures = [f"run {r['run']} not valid/clean" for r in fd if not run_is_valid(r)]
    if len(fd) != 3:
        fd_failures.append(f"expected 3 runs, have {len(fd)}")
    fd_valid = len(fd) == 3 and all(run_is_valid(r) for r in fd)
    fd_clean = fd_valid and not fd_insertions

    hash_ok = bool(hash_diff.get("unchanged")) and not new_pids

    status = "PASS"
    reason = "ForceDisable suppressed the non-VBA AutoExec action on all three fresh copies"
    if infra_error:
        status, reason = "INFRA-error", f"infra error: {infra_error}"
    elif not build_ok:
        status, reason = "BLOCKED-build", "fixture build did not succeed"
    elif overall_timeout_hit:
        status, reason = "BLOCKED-overall-timeout", "overall matrix timeout hit; stopped without retry"
    elif any_cell_timed_out:
        if timeout_dialog_blocked:
            status = "STOP-inconclusive-positive-control"
            reason = (
                "a positive-control cell timed out while a dialog-class window was observed "
                "(likely the action-query confirmation); no synthetic input was sent and no UI "
                "setting was changed, so the positive control is inconclusive"
            )
        else:
            status = "STOP-execution-timeout"
            reason = "a cell timed out with no dialog evidence; stopped without retry"
    elif integrity_errors:
        status = "STOP-integrity"
        reason = "; ".join(integrity_errors)
    elif not positive_ok:
        status = "STOP-inconclusive-positive-control"
        if not positive_exact:
            reason = f"positive control did not complete exactly three runs (have {len(pos)})"
        elif not positive_valid:
            reason = "a positive-control run was not valid (harness/observer/open/readback)"
        elif positive_dialog_observed:
            reason = (
                "positive control produced no canary row while a dialog-class window was "
                "observed (likely the action-query confirmation); no synthetic input was sent "
                "and no UI setting was changed, so the positive control is inconclusive"
            )
        else:
            reason = (
                "positive control never produced the exact canary row "
                "[(1,'NON_VBA_AUTOEXEC')] on every run; absence of insertion under "
                "ForceDisable would be vacuous"
            )
    elif not hash_ok:
        changed = hash_diff.get("changed", []) if isinstance(hash_diff, dict) else []
        status = "STOP-integrity"
        reason = f"canonical hash/new-PID integrity failed (changed={changed}, new_pids={new_pids})"
    elif fd_insertions:
        status = "STOP-recipe-not-clean"
        reason = (
            f"ForceDisable did not suppress the non-VBA action: canary row inserted in FD run(s) "
            f"{fd_insertions}; the recipe cannot back a passive Tier 2 reader"
        )
    elif not fd_clean:
        status = "STOP-recipe-not-clean"
        reason = f"ForceDisable recipe runs were not clean: {fd_failures}"

    return {
        "status": status,
        "exit_code": EXIT_CODES[status],
        "stop_reason": reason,
        "positive_control": {
            "exact_three_runs": positive_exact,
            "all_valid": positive_valid,
            "inserted_exact_row_all_runs": positive_inserted,
            "verified": positive_ok,
        },
        "recipe": {
            "cell": "FD",
            "runs": len(fd),
            "all_valid": fd_valid,
            "insertions": fd_insertions,
            "clean": fd_clean,
            "failures": fd_failures,
        },
        "canary": {
            "expected_row": {"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL},
            "positive_rows_after": [r.get("rows_after") for r in pos],
            "force_disable_rows_after": [r.get("rows_after") for r in fd],
        },
        "hash_ok": hash_ok,
        "new_pids": new_pids,
        "integrity_errors": integrity_errors,
        "notes": [
            "PASS requires the positive control verified (exact row on all 3 runs), the "
            "ForceDisable recipe clean on all 3 fresh copies, unchanged canonical hashes, and "
            "zero new MSACCESS PIDs.",
            "A missing/failed positive control makes every 'no insertion' result vacuous (STOP).",
            "Even one FD insertion rejects the recipe (STOP-recipe-not-clean); Tier 2 stops at the "
            "planning gate rather than weakening the contract.",
        ],
    }


def verdict_selftest() -> int:
    """Synthetic verdict matrix; the runner's testable logic, no COM involved."""
    def syn(cell: str, run: int, rows_after, **overrides) -> dict:
        record = {
            "cell": cell,
            "run": run,
            "security_requested": MSO_LOW if cell == "POS" else MSO_FORCE_DISABLE,
            "security_readback": MSO_LOW if cell == "POS" else MSO_FORCE_DISABLE,
            "child_returncode": 0,
            "timed_out": False,
            "open_ok": True,
            "observer_started": True,
            "observer_error": None,
            "residual_owned_pid": False,
            "access_pid_in_baseline": False,
            "pre_locks_clear": True,
            "locks": [],
            "rows_before_read_ok": True,
            "rows_before": [],
            "rows_after_read_ok": True,
            "rows_after": rows_after,
            "dialogs": [],
            "timeout_dialogs": [],
        }
        record.update(overrides)
        return record

    def pos(n: int, rows_after=None, **overrides):
        rows = [{"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}] if rows_after is None else rows_after
        return [syn("POS", i + 1, rows, **overrides) for i in range(n)]

    def fd(n: int, rows_after=None, **overrides):
        rows = [] if rows_after is None else rows_after
        return [syn("FD", i + 1, rows, **overrides) for i in range(n)]

    good_kwargs = dict(
        build_ok=True, overall_timeout_hit=False, any_cell_timed_out=False,
        timeout_dialog_blocked=False, positive_dialog_observed=False,
        integrity_errors=[], hash_diff={"unchanged": True},
        new_pids=[], infra_error=None,
    )

    cases = [
        ("three-positives-insert-three-fd-unchanged", pos(3) + fd(3), {}, "PASS"),
        ("one-positive-missing-row", pos(2) + [
            syn("POS", 3, [])] + fd(3), {}, "STOP-inconclusive-positive-control"),
        ("positive-extra-row-is-not-exact", pos(3, rows_after=[
            {"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL},
            {"ProbeID": 2, "Label": "UNEXPECTED"}]) + fd(3), {},
         "STOP-inconclusive-positive-control"),
        ("only-two-positive-runs", pos(2) + fd(3), {}, "STOP-inconclusive-positive-control"),
        ("one-fd-insertion-is-recipe-rejection",
         pos(3) + fd(2) + fd(1, rows_after=[{"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}]),
         {}, "STOP-recipe-not-clean"),
        ("fd-clean-but-hash-changed", pos(3) + fd(3),
         {"hash_diff": {"unchanged": False, "changed": ["db/northwind.accdb"]}}, "STOP-integrity"),
        ("foreign-new-msaccess-pid", pos(3) + fd(3), {"new_pids": [4242]}, "STOP-integrity"),
        ("positive-observer-error", pos(2) + [syn("POS", 3, [], observer_error="boom")] + fd(3),
         {}, "STOP-inconclusive-positive-control"),
        ("positive-open-failure", pos(2) + [
            syn("POS", 3, [], open_ok=False, child_returncode=4)] + fd(3),
         {}, "STOP-inconclusive-positive-control"),
        ("positive-security-readback-mismatch", pos(2) + [
            syn("POS", 3, [], security_readback=MSO_FORCE_DISABLE)] + fd(3),
         {}, "STOP-inconclusive-positive-control"),
        ("fd-residual-process-after-run", pos(3) + fd(2) + [
            syn("FD", 3, [], residual_owned_pid=True)],
         {}, "STOP-recipe-not-clean"),
        ("positive-lock-residue", pos(2) + [
            syn("POS", 3, [{"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}],
                locks=["armed.laccdb"])] + fd(3), {},
         "STOP-inconclusive-positive-control"),
        ("pre-existing-canary-row", pos(3) + fd(3),
         {"integrity_errors": ["run 1 pre-open DAO read was not empty"]}, "STOP-integrity"),
        ("pos-timeout-with-dialog",
         pos(2) + [syn("POS", 3, [], timed_out=True, child_returncode=None,
                       timeout_dialogs=[{"class_name": "#32770", "title": "Append"}])] + fd(3),
         {"any_cell_timed_out": True, "timeout_dialog_blocked": True},
         "STOP-inconclusive-positive-control"),
        ("pos-timeout-no-dialog",
         pos(2) + [syn("POS", 3, [], timed_out=True, child_returncode=None)] + fd(3),
         {"any_cell_timed_out": True}, "STOP-execution-timeout"),
        ("pos-dialog-observed-no-insertion",
         pos(2) + [syn("POS", 3, [], dialogs=[{"class_name": "#32770", "title": "Append"}])]
         + fd(3),
         {"positive_dialog_observed": True}, "STOP-inconclusive-positive-control"),
        ("build-not-ok", pos(3) + fd(3), {"build_ok": False}, "BLOCKED-build"),
        ("infra-error-wins", pos(3) + fd(3), {"infra_error": "boom"}, "INFRA-error"),
    ]

    results = []
    for label, runs, overrides, expected in cases:
        kwargs = dict(good_kwargs)
        kwargs.update(overrides)
        verdict = compute_verdicts(runs, **kwargs)
        status = verdict["status"]
        ok = status == expected
        results.append({
            "case": label,
            "expected": expected,
            "observed": status,
            "exit_code": verdict["exit_code"],
            "ok": ok,
        })
        if not ok:
            raise AssertionError(f"verdict selftest case {label!r}: expected {expected}, observed {status}")
    return len(results)


def self_check() -> int:
    import os

    from tests.helpers.dialog_watcher import WindowInfo, collect_windows, creation_time as dw_ct, process_image as dw_pi

    # Consume the watcher surface non-live so a field-name drift is caught pre-flight.
    sample = WindowInfo(hwnd=1, owner_pid=2, owner_image="x", class_name="#32770", title="t")
    assert sample.class_name == "#32770" and sample.title == "t"
    assert callable(collect_windows)
    self_pid = os.getpid()
    own_creation = dw_ct(self_pid)
    own_image = dw_pi(self_pid)
    assert own_creation is not None and own_image.lower().endswith(".exe")

    # Fail-closed identity/kill semantics (never kills without positive ownership).
    assert verify_access_identity(None, None)["owned"] is False
    assert verify_access_identity(self_pid, None)["owned"] is False
    assert verify_access_identity(self_pid, own_creation, {self_pid})["owned"] is False
    assert verify_access_identity(999_999_999, 123)["owned"] is False
    kill = kill_pid_scoped(self_pid, None)
    assert kill["result"] == "skipped-unverified-no-kill", kill
    kill_baseline = kill_pid_scoped(self_pid, own_creation, {self_pid})
    assert kill_baseline["result"] == "skipped-unverified-no-kill", kill_baseline

    before = canonical_hashes()
    import build_fixture  # noqa: F401  (import check only)
    import cell  # noqa: F401
    import dao_read  # noqa: F401

    assert FIXTURE_DB_NAME == "armed.accdb"
    assert [c["id"] for c in CELLS] == ["POS", "FD"]
    assert rows_match_expected([{"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}])
    assert not rows_match_expected([])
    assert not rows_match_expected([{"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL},
                                    {"ProbeID": 2, "Label": "x"}])
    assert rows_empty([]) and not rows_empty([{"ProbeID": 1}])
    case_count = verdict_selftest()

    print(json.dumps({
        "canonical_files_hashed": len(before),
        "scratch": str(SCRATCH),
        "fixture_dir_exists": FIXTURE_DIR.exists(),
        "watcher_helpers_ok": True,
        "fail_closed_kill_ok": True,
        "matrix_cells": [c["id"] for c in CELLS],
        "verdict_selftest_cases": case_count,
        "exit_codes": EXIT_CODES,
    }, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--all", action="store_true", help="run the build + 6-cell matrix")
    parser.add_argument("--self-check", action="store_true", help="bounded structural check; no COM")
    parser.add_argument("--overall-timeout", type=float, default=1800.0)
    args = parser.parse_args()

    if args.self_check:
        return self_check()
    if not args.all:
        parser.print_help()
        return 1

    started = time.monotonic()
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    baseline_pids = sorted(msaccess_pids())
    baseline_set = set(baseline_pids)
    hashes_before = canonical_hashes()
    write_json_flushed(EVIDENCE_DIR / "hashes_before.json", hashes_before)
    write_json_flushed(EVIDENCE_DIR / "baseline_msaccess_pids.json", baseline_pids)

    runs: list[dict] = []
    build: dict = {"ok": False, "error": "not-attempted"}
    overall_timeout_hit = False
    any_cell_timed_out = False
    infra_error: str | None = None
    hashes_after = hashes_before
    new_pids: list[int] = []

    try:
        build = build_fixture()
        if build.get("ok"):
            for cell in CELLS:
                stop_matrix = False
                for run_index in range(1, cell["runs"] + 1):
                    if time.monotonic() - started > args.overall_timeout:
                        overall_timeout_hit = True
                        stop_matrix = True
                        break
                    record = run_one(cell, run_index, baseline_set)
                    runs.append(record)
                    if record["timed_out"]:
                        # Never run further cells after a timeout.
                        any_cell_timed_out = True
                        stop_matrix = True
                        break
                if stop_matrix:
                    break
                if cell["id"] == "POS":
                    pos_runs = [r for r in runs if r["cell"] == "POS"]
                    positive_ok = (
                        len(pos_runs) == 3
                        and all(run_is_valid(r) and rows_match_expected(r.get("rows_after"))
                                for r in pos_runs)
                    )
                    if not positive_ok:
                        # Positive control did not insert: stop, do not probe further.
                        break
    except Exception as exc:  # noqa: BLE001 - still attempt scoped cleanup + summary
        infra_error = repr(exc)

    # Aggregation is individually guarded so a failure still leaves the scoped cleanup
    # attempt, the hash diff and a failure summary on disk.
    survivors: list[dict] = []
    try:
        for record in runs:
            identity = record.get("identity") or {}
            pid = identity.get("access_pid")
            if pid and pid in msaccess_pids():
                survivors.append({"pid": pid, "cell": record.get("cell"),
                                  "run": record.get("run"), "identity": identity})
        for survivor in survivors:
            survivor["cleanup"] = kill_pid_scoped(
                survivor["pid"], survivor.get("identity", {}).get("access_creation"), baseline_set
            )
            wait_for_pid_exit(survivor["pid"], timeout=10.0)
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"orphan sweep failed: {exc!r}"

    try:
        hashes_after = canonical_hashes()
        hash_diff = diff_hashes(hashes_before, hashes_after)
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"post-hash failed: {exc!r}"
        hash_diff = {"unchanged": False, "changed": [], "added": [], "removed": []}

    try:
        final_pids = sorted(msaccess_pids())
        new_pids = sorted(set(final_pids) - baseline_set)
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"final pid scan failed: {exc!r}"
        final_pids, new_pids = [], []

    integrity_errors: list[str] = []
    for record in runs:
        if record.get("rows_before_read_ok") and record.get("rows_before"):
            integrity_errors.append(
                f"{record['cell']} run {record['run']}: fresh copy had pre-existing canary rows "
                f"{record.get('rows_before')}"
            )
        if record.get("rows_before_read_ok") is not True and not record.get("timed_out"):
            integrity_errors.append(
                f"{record['cell']} run {record['run']}: pre-open DAO read failed "
                f"({record.get('rows_before_error')})"
            )
        if record.get("pre_locks_clear") is False:
            integrity_errors.append(
                f"{record['cell']} run {record['run']}: pre-open lock residue "
                f"{record.get('pre_locks')}"
            )

    timeout_dialog_blocked = any(
        r.get("timed_out") and (r.get("timeout_dialogs") or r.get("dialogs"))
        for r in runs if r.get("cell") == "POS"
    )
    positive_dialog_observed = any(
        r.get("dialogs") or r.get("timeout_dialogs") for r in runs if r.get("cell") == "POS"
    )

    try:
        verdicts = compute_verdicts(
            [r for r in runs if r.get("cell")],
            build_ok=bool(build.get("ok")),
            overall_timeout_hit=overall_timeout_hit,
            any_cell_timed_out=any_cell_timed_out,
            timeout_dialog_blocked=timeout_dialog_blocked,
            positive_dialog_observed=positive_dialog_observed,
            integrity_errors=integrity_errors,
            hash_diff=hash_diff,
            new_pids=new_pids,
            infra_error=infra_error,
        )
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"verdict computation failed: {exc!r}"
        verdicts = {
            "status": "INFRA-error",
            "exit_code": EXIT_CODES["INFRA-error"],
            "stop_reason": f"verdict computation failed: {exc!r}",
            "recipe": {"runs": 0, "all_valid": False, "insertions": [], "clean": False},
            "positive_control": {"verified": False},
            "hash_ok": False,
        }

    summary = {
        "schema": "v2-spike-nonvba.summary/1",
        "build": build,
        "baseline_msaccess_pids": baseline_pids,
        "runs": runs,
        "verdicts": verdicts,
        "status": verdicts["status"],
        "integrity_errors": integrity_errors,
        "timeout_dialog_blocked": timeout_dialog_blocked,
        "positive_dialog_observed": positive_dialog_observed,
        "orphan_sweep": {"survivors": survivors, "final_msaccess_pids": final_pids,
                         "new_msaccess_pids": new_pids},
        "hash_protection": {"before": hashes_before, "after": hashes_after, "diff": hash_diff},
        "overall_timeout_hit": overall_timeout_hit,
        "any_cell_timed_out": any_cell_timed_out,
        "infra_error": infra_error,
        "elapsed_seconds": round(time.monotonic() - started, 1),
    }
    try:
        write_json_flushed(EVIDENCE_DIR / "summary.json", summary)
    except Exception:  # noqa: BLE001 - never let summary write hide the exit code
        pass

    print(json.dumps({
        "status": verdicts["status"],
        "exit_code": verdicts["exit_code"],
        "stop_reason": verdicts.get("stop_reason"),
        "positive_verified": verdicts["positive_control"]["verified"],
        "fd_clean": verdicts["recipe"]["clean"],
        "fd_insertions": verdicts["recipe"]["insertions"],
        "hash_ok": verdicts["hash_ok"],
        "new_msaccess_pids": new_pids,
    }, indent=2, default=str))
    return verdicts["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
