"""Bounded DAO-only probe (no Access.Application) for Tier 1 startup properties.

Runs in seconds. Copies the canonical startup fixture into scratch, opens the copy
through ``DAO.DBEngine.120``, records the ``Database.Properties`` collection and the
DAO containers, then exercises create/read/delete of a ``StartupForm`` property on the
throwaway copy. This validates the exact DAO APIs the runner depends on without
instantiating Access.
"""
from __future__ import annotations

import gc
import json
from pathlib import Path

from spike_common import (
    ROOT,
    canonical_hashes,
    diff_hashes,
    lock_files,
    sha256_file,
    write_json_flushed,
)

SCRATCH = Path(__file__).resolve().parent
PROBE_DIR = SCRATCH / "evidence" / "dao_probe"
SOURCE = ROOT / "db" / "fixtures" / "documentation" / "startup.accdb"


def main() -> int:
    import pythoncom
    import win32com.client

    PROBE_DIR.mkdir(parents=True, exist_ok=True)
    copy = PROBE_DIR / "startup_probe.accdb"
    copy.write_bytes(SOURCE.read_bytes())
    source_hash = sha256_file(SOURCE)

    record: dict = {"schema": "v2-spike.dao-probe/1", "copy": str(copy)}
    pythoncom.CoInitialize()
    engine = None
    database = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        database = engine.OpenDatabase(str(copy), False, False)
        props: dict = {}
        for i in range(database.Properties.Count):
            prop = database.Properties(i)
            try:
                props[prop.Name] = str(prop.Value)
            except Exception as exc:  # noqa: BLE001
                props[prop.Name] = f"<unreadable: {exc}>"
        record["properties"] = props
        record["startup_form_present_before"] = "StartupForm" in props

        containers: dict = {}
        for name in ("Forms", "Reports", "Scripts", "Modules", "Tables"):
            try:
                collection = database.Containers(name).Documents
                containers[name] = sorted(str(collection(i).Name) for i in range(collection.Count))
            except Exception as exc:  # noqa: BLE001
                containers[name] = f"<unreadable: {exc}>"
        record["containers"] = containers

        # Exercise create/read/delete of a StartupForm property on the copy.
        try:
            database.Properties("StartupForm").Value = "ProbeForm"
            record["set_mode"] = "existing"
        except Exception as exc:  # noqa: BLE001
            record["set_existing_error"] = repr(exc)
            prop = database.CreateProperty("StartupForm", 10, "ProbeForm")
            database.Properties.Append(prop)
            record["set_mode"] = "created"
        record["readback_after_set"] = str(database.Properties("StartupForm").Value)
        try:
            database.Properties.Delete("StartupForm")
            record["delete_ok"] = True
        except Exception as exc:  # noqa: BLE001
            record["delete_ok"] = False
            record["delete_error"] = repr(exc)
        try:
            record["readback_after_delete"] = str(database.Properties("StartupForm").Value)
        except Exception as exc:  # noqa: BLE001
            record["readback_after_delete"] = f"<absent: {exc}>"
    finally:
        if database is not None:
            try:
                database.Close()
            except Exception:
                pass
        database = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()

    record["locks_after"] = lock_files(PROBE_DIR)
    record["canonical_startup_hash_unchanged"] = sha256_file(SOURCE) == source_hash
    write_json_flushed(PROBE_DIR / "probe.json", record)
    print(json.dumps({
        "properties_count": len(record.get("properties", {})),
        "startup_form_present_before": record.get("startup_form_present_before"),
        "set_mode": record.get("set_mode"),
        "delete_ok": record.get("delete_ok"),
        "scripts_container": record.get("containers", {}).get("Scripts"),
        "modules_container": record.get("containers", {}).get("Modules"),
        "forms_container": record.get("containers", {}).get("Forms"),
        "locks_after": record["locks_after"],
        "canonical_hash_unchanged": record["canonical_startup_hash_unchanged"],
    }, indent=2, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
