"""Build the non-VBA AutoExec canary fixture without ever running startup code.

What the fixture is
-------------------
One disposable ``armed.accdb`` that carries:

* a dedicated local canary table ``CanaryRows`` with ``[ProbeID] LONG`` and
  ``[Label] TEXT(64)``, primary key on ``[ProbeID]``, and **zero rows**;
* a saved append ``QueryDef`` named ``qryAppendCanary`` whose SQL inserts exactly
  ``(1, 'NON_VBA_AUTOEXEC')``;
* one pure macro-action ``AutoExec`` that runs ``OpenQuery`` on that saved query.
  There is no VBA module, no function, no ``RunCode``, no ``OnLoad`` expression,
  no startup form, and no ``SetWarnings`` action (an AutoExec ``SetWarnings``
  would mask the action-query warning this experiment must observe).

Build-order discipline (mirrors ``scripts/generate_documentation_fixtures.py`` and
the prior spike's hardened order):

1. DAO-only creation of ``armed.accdb`` + canary table + saved append query.
2. ``Access.Application`` opens the database while it has **no** auto-run object:
   ``CurrentProject.AllMacros`` is empty, the Scripts container is empty, and the
   ``StartupForm`` property does not exist.
3. The macro loads under a neutral name (``NonVBAProbe``), then its real stored text
   is captured with ``SaveAsText`` and inspected (must contain ``OpenQuery`` and the
   query name; must not contain any VBA token).
4. Only then, as the very last mutation, the macro is renamed to ``AutoExec`` and the
   database is closed. The armed fixture is never reopened with Access.

If any step fails the builder raises; the outer runner reports a concrete build
blocker instead of improvising or silently falling back to VBA.
"""
from __future__ import annotations

import argparse
import gc
import json
import sys
from pathlib import Path

from spike_common import (
    AC_MACRO,
    AUTOEXEC_ARMED,
    CANARY_INSERT_SQL,
    CANARY_LABEL,
    CANARY_PROBE_ID,
    CANARY_QUERY,
    CANARY_TABLE,
    DB_VERSION,
    FORBIDDEN_MACRO_TOKENS,
    FIXTURE_DB_NAME,
    LOCALE,
    MACRO_NEUTRAL_NAME,
    MSO_FORCE_DISABLE,
    creation_time,
    decode_save_as_text,
    kill_pid_scoped,
    lock_files,
    msaccess_pids,
    process_image,
    read_canary_snapshot,
    sha256_bytes,
    sha256_file,
    verify_access_identity,
    write_json_flushed,
)

# Ground truth dialect (see src/ms_access_mcp/backends/access/macros.py and
# scripts/generate_documentation_fixtures.py): LoadFromText(4, ...) accepts the
# SaveAsText AXL framing, CRLF only. ``Action`` carries the English macro action
# name; ``OpenQuery`` is a pure macro action, not VBA.
NON_VBA_MACRO_SOURCE = '''Version =196611
ColumnsShown =0
Begin
    Action ="OpenQuery"
    Argument ="qryAppendCanary"
End
'''


def _write_macro_source(scratch: Path) -> tuple[Path, str]:
    text = NON_VBA_MACRO_SOURCE
    path = scratch / "nonvba_autoexec.txt"
    path.write_text(text, encoding="utf-8", newline="\r\n")
    return path, text


def _create_dao_database(db_path: Path) -> dict:
    """DAO-only: canary table (empty) + saved append query. No row is inserted."""
    import pythoncom
    import win32com.client

    record: dict = {"path": str(db_path)}
    pythoncom.CoInitialize()
    engine = None
    db = None
    query = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        db = engine.CreateDatabase(str(db_path), LOCALE, DB_VERSION)
        db.Execute(
            f"CREATE TABLE {CANARY_TABLE} ([ProbeID] LONG NOT NULL, [Label] TEXT(64), "
            f"CONSTRAINT PK_{CANARY_TABLE} PRIMARY KEY ([ProbeID]))",
            128,
        )
        db.TableDefs.Refresh()
        query = db.CreateQueryDef(CANARY_QUERY, CANARY_INSERT_SQL)
        db.QueryDefs.Refresh()
        record["query_created"] = CANARY_QUERY
        record["query_sql_readback"] = str(db.QueryDefs(CANARY_QUERY).SQL)
        record["table_created"] = CANARY_TABLE
    finally:
        query = None
        if db is not None:
            try:
                db.Close()
            except Exception:
                pass
        db = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()
    return record


def _sql_matches(sql: str) -> bool:
    normalized = " ".join(str(sql).split()).lower()
    return (
        normalized.startswith("insert into canaryrows")
        and f"({CANARY_PROBE_ID}," in normalized.replace(" ", "")
        and CANARY_LABEL.lower() in normalized
    )


def _build_access_phase(db_path: Path, macro_source: Path) -> dict:
    import win32com.client

    report: dict = {}
    app = None
    access_pid: int | None = None
    access_creation: int | None = None
    baseline = set(msaccess_pids())
    report["baseline_msaccess_pids"] = sorted(baseline)
    try:
        app = win32com.client.DispatchEx("Access.Application")
        try:
            import win32process

            hwnd = int(app.hWndAccessApp())
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            access_pid = int(pid)
            access_creation = creation_time(access_pid)
        except Exception as exc:  # noqa: BLE001
            report["identity_error"] = str(exc)
        report["access_identity"] = {
            "access_pid": access_pid,
            "access_creation": access_creation,
            "access_image": process_image(access_pid) if access_pid else None,
        }
        verification = verify_access_identity(access_pid, access_creation, baseline)
        report["identity_verification"] = verification
        write_json_flushed(
            db_path.parent / "build_identity.json",
            {**report["access_identity"], "verification": verification},
        )
        if not verification["owned"]:
            raise RuntimeError(
                f"Access identity not positively verified; build refused: {verification}"
            )

        app.Visible = False
        app.UserControl = False
        app.AutomationSecurity = MSO_FORCE_DISABLE
        security_readback = int(app.AutomationSecurity)
        report["security_readback"] = security_readback
        if security_readback != MSO_FORCE_DISABLE:
            raise RuntimeError(
                f"AutomationSecurity readback {security_readback} != force-disable "
                f"{MSO_FORCE_DISABLE}; build refused"
            )
        app.OpenCurrentDatabase(str(db_path))
        report["opened"] = True

        # Prove there is no auto-run object before anything is loaded.
        macro_names = [
            str(app.CurrentProject.AllMacros(i).Name)
            for i in range(app.CurrentProject.AllMacros.Count)
        ]
        report["macros_before_arm"] = sorted(macro_names)
        if macro_names:
            raise RuntimeError(f"auto-run objects exist before load: {macro_names}")
        modules_before = int(app.CurrentProject.AllModules.Count)
        forms_before = int(app.CurrentProject.AllForms.Count)
        report["modules_before_arm"] = modules_before
        report["forms_before_arm"] = forms_before
        if modules_before or forms_before:
            raise RuntimeError(
                f"module/form objects exist before load: modules={modules_before} "
                f"forms={forms_before}"
            )

        app.LoadFromText(AC_MACRO, MACRO_NEUTRAL_NAME, str(macro_source))
        report["macro_loaded_neutral"] = MACRO_NEUTRAL_NAME

        # Capture the ACTUAL stored macro text before the rename-to-AutoExec.
        captured_path = db_path.parent / "captured_macro_neutral.txt"
        app.SaveAsText(AC_MACRO, MACRO_NEUTRAL_NAME, str(captured_path))
        raw = captured_path.read_bytes()
        captured = decode_save_as_text(raw)
        report["captured_macro"] = {
            "path": captured_path.name,
            "bytes": len(raw),
            "sha256": sha256_bytes(raw),
            "text": captured,
        }
        lowered = captured.lower()
        missing = [token for token in ("openquery", CANARY_QUERY.lower()) if token not in lowered]
        forbidden = [token for token in FORBIDDEN_MACRO_TOKENS if token in lowered]
        report["captured_macro"]["has_openquery"] = "openquery" in lowered
        report["captured_macro"]["has_query_name"] = CANARY_QUERY.lower() in lowered
        report["captured_macro"]["forbidden_tokens_found"] = forbidden
        if missing:
            raise RuntimeError(
                f"captured macro text is not the expected pure macro action (missing {missing}); "
                f"captured={captured!r}"
            )
        if forbidden:
            raise RuntimeError(
                f"captured macro text contains VBA tokens {forbidden}: {captured!r}"
            )
        report["macro_inspected_ok"] = True

        # DAO inventory while the (still unarmed) database is open.
        database = app.CurrentDb()
        containers: dict = {}
        for container_name in ("Modules", "Forms", "Reports", "Scripts"):
            try:
                collection = database.Containers(container_name).Documents
                containers[container_name] = sorted(
                    str(collection(i).Name) for i in range(collection.Count)
                )
            except Exception as exc:  # noqa: BLE001
                containers[container_name] = f"<unreadable: {exc}>"
        report["dao_containers_before_arm"] = containers
        try:
            report["startup_form_property_before_arm"] = str(
                database.Properties("StartupForm").Value
            )
        except Exception:
            report["startup_form_property_before_arm"] = None
        if containers.get("Modules"):
            raise RuntimeError(f"Modules container not empty: {containers['Modules']}")
        if containers.get("Forms"):
            raise RuntimeError(f"Forms container not empty: {containers['Forms']}")
        if report["startup_form_property_before_arm"] is not None:
            raise RuntimeError(
                f"StartupForm property present: {report['startup_form_property_before_arm']}"
            )

        # LAST mutation: arm the real name, then close. Never reopen the armed file
        # with Access afterwards.
        app.DoCmd.Rename(AUTOEXEC_ARMED, AC_MACRO, MACRO_NEUTRAL_NAME)
        report["armed"] = [AUTOEXEC_ARMED]
        report["armed_macros_after_rename"] = sorted(
            str(app.CurrentProject.AllMacros(i).Name)
            for i in range(app.CurrentProject.AllMacros.Count)
        )

        app.CloseCurrentDatabase()
        report["closed"] = True
    finally:
        if app is not None:
            try:
                app.Quit()
            except Exception:
                pass
        app = None
        if access_pid is not None:
            import time as _time

            deadline = _time.monotonic() + 20.0
            while access_pid in msaccess_pids() and _time.monotonic() < deadline:
                _time.sleep(0.5)
            report["reap"] = kill_pid_scoped(access_pid, access_creation, baseline)
    return report


def build(out_dir: Path) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    db_path = out_dir / FIXTURE_DB_NAME
    if db_path.exists():
        raise RuntimeError(f"refusing to overwrite existing fixture: {db_path}")

    macro_source, macro_text = _write_macro_source(out_dir)
    macro_source_sha256 = sha256_file(macro_source)
    dao_create = _create_dao_database(db_path)

    # DAO's phase balances its own COM apartment; Access needs a new one.
    import pythoncom

    pythoncom.CoInitialize()
    try:
        access_report = _build_access_phase(db_path, macro_source)
    finally:
        pythoncom.CoUninitialize()

    # Post-close DAO readback: the armed fixture must still carry zero canary rows.
    snapshot = read_canary_snapshot(db_path)
    locks = lock_files(out_dir)
    if locks:
        raise RuntimeError(f"build left lock files: {locks}")

    if not snapshot["ok"]:
        raise RuntimeError(f"post-build DAO readback failed: {snapshot['dao_error']}")
    scripts = set(snapshot["containers"].get("Scripts", []))
    if AUTOEXEC_ARMED not in scripts:
        raise RuntimeError(f"armed macro missing from DAO Scripts container: {sorted(scripts)}")
    if MACRO_NEUTRAL_NAME in scripts:
        raise RuntimeError("neutral macro name still present after rename")
    if snapshot["containers"].get("Modules"):
        raise RuntimeError(f"Modules container not empty: {snapshot['containers']['Modules']}")
    if snapshot["containers"].get("Forms"):
        raise RuntimeError(f"Forms container not empty: {snapshot['containers']['Forms']}")
    if snapshot["startup_form_property"] is not None:
        raise RuntimeError(f"StartupForm property present: {snapshot['startup_form_property']}")
    if CANARY_TABLE not in snapshot["tables"]:
        raise RuntimeError(f"canary table missing after build: {snapshot['tables']}")
    if CANARY_QUERY not in snapshot["querydefs"]:
        raise RuntimeError(f"saved query missing after build: {sorted(snapshot['querydefs'])}")
    if not _sql_matches(snapshot["querydefs"][CANARY_QUERY]):
        raise RuntimeError(
            f"saved query SQL not the exact append: {snapshot['querydefs'][CANARY_QUERY]!r}"
        )
    if not snapshot["rows"] == []:
        raise RuntimeError(f"build executed the canary action: rows={snapshot['rows']}")

    report = {
        "schema": "v2-spike-nonvba.build/1",
        "fixture": str(db_path),
        "macro_source_text": macro_text,
        "macro_source_sha256": macro_source_sha256,
        "dao_create": dao_create,
        "access_phase": access_report,
        "post_build_dao_snapshot": snapshot,
        "locks_after_build": locks,
        "canary_rows_after_build": snapshot["rows"],
        "startup_form_property_after_build": snapshot["startup_form_property"],
        "modules_container_after_build": snapshot["containers"].get("Modules"),
        "forms_container_after_build": snapshot["containers"].get("Forms"),
        "scripts_container_after_build": snapshot["containers"].get("Scripts"),
        "expected_row": {"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL},
    }
    write_json_flushed(out_dir / "build_report.json", report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = build(args.out_dir)
    except Exception as exc:  # noqa: BLE001 - report the blocker, exit nonzero
        print(f"BUILD_BLOCKER: {exc}", file=sys.stderr)
        write_json_flushed(args.out_dir / "build_report.json", {"error": str(exc)})
        return 2
    print(json.dumps({
        "fixture": report["fixture"],
        "canary_rows_after_build": report["canary_rows_after_build"],
        "scripts_container_after_build": report["scripts_container_after_build"],
        "modules_container_after_build": report["modules_container_after_build"],
        "startup_form_property_after_build": report["startup_form_property_after_build"],
        "macro_source_sha256": report["macro_source_sha256"],
        "macro_captured_sha256": report["access_phase"]["captured_macro"]["sha256"],
    }, ensure_ascii=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
