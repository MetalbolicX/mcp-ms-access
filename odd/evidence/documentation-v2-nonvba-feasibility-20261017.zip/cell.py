"""Run one spike cell (one Access instance, one disposable copy) in a child process.

The parent runner owns the hard timeout, the PID-scoped hard kill, and the DAO canary
row observations. This child only drives one Access instance and records what it sees
(identity, security readback, version, observed windows, open result, exit); it never
reads the canary rows itself, never sends keyboard/UI input, and never kills anything
except - best effort - its own captured Access PID during graceful shutdown.

The child writes its evidence incrementally so a blocked COM call still leaves readable
data for the parent.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
from pathlib import Path

from spike_common import (
    creation_time,
    lock_files,
    msaccess_pids,
    process_image,
    verify_access_identity,
    write_json_flushed,
)

# Child exit codes (documented): 0 ok; 3 security readback mismatch; 4 open failed;
# 6 Access identity could not be positively verified (aborted before armed open);
# 5 unexpected fatal error.
EXIT_OK = 0
EXIT_SECURITY_MISMATCH = 3
EXIT_OPEN_FAILED = 4
EXIT_UNVERIFIED_IDENTITY = 6
EXIT_FATAL = 5


class State:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.lock = threading.Lock()
        self.payload: dict = {
            "schema": "v2-spike-nonvba.cell/1",
            "dialogs": [],
            "open_errors": [],
        }

    def record(self, **kwargs) -> None:
        with self.lock:
            self.payload.update(kwargs)
            write_json_flushed(self.path, self.payload)

    def append_dialog(self, dialog: dict) -> None:
        with self.lock:
            if dialog not in self.payload["dialogs"]:
                self.payload["dialogs"].append(dialog)
                write_json_flushed(self.path, self.payload)

    def snapshot(self) -> dict:
        with self.lock:
            return json.loads(json.dumps(self.payload, default=str))


def _observe_dialogs(stop: threading.Event, access_pid: int, state: State) -> None:
    """Read-only window observation; records every owned window, never dismisses one."""
    from tests.helpers.dialog_watcher import collect_windows

    while not stop.is_set():
        try:
            for window in collect_windows({access_pid}):
                state.append_dialog({
                    "hwnd": hex(window.hwnd),
                    "owner_pid": window.owner_pid,
                    "owner_image": window.owner_image,
                    "class": window.class_name,
                    "title": window.title,
                    "is_dialog_class": window.class_name == "#32770",
                })
        except Exception as exc:  # noqa: BLE001 - observation must never crash the cell
            state.record(observer_error=str(exc))
        stop.wait(0.5)


def run_cell(args: argparse.Namespace) -> int:
    import pythoncom
    import win32com.client

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    state = State(out_dir / "result.json")
    baseline = sorted(msaccess_pids())
    state.record(
        cell=args.cell,
        run=args.run,
        security_requested=args.security,
        db=args.db,
        baseline_msaccess_pids=baseline,
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
        child_pid=os.getpid(),
    )

    observer_stop = threading.Event()
    observer: threading.Thread | None = None
    access_pid: int | None = None

    pythoncom.CoInitialize()
    app = None
    try:
        app = win32com.client.DispatchEx("Access.Application")
        # Capture identity BEFORE opening the armed file; verify fail-closed. The
        # flushed identity.json must exist before the armed open.
        try:
            hwnd = int(app.hWndAccessApp())
            import win32process

            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            access_pid = int(pid)
            state.record(access_identity={
                "method": "hWndAccessApp",
                "hwnd": hex(hwnd),
                "access_pid": access_pid,
                "access_image": process_image(access_pid),
                "access_creation": creation_time(access_pid),
                "captured_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            })
        except Exception as exc:  # noqa: BLE001
            owned = sorted(msaccess_pids() - set(baseline))
            if len(owned) == 1:
                access_pid = owned[0]
            state.record(access_identity={
                "method": "baseline-diff",
                "hwnd_error": str(exc),
                "access_pid": access_pid,
                "owned_new_pids": owned,
                "access_image": process_image(access_pid) if access_pid else None,
                "access_creation": creation_time(access_pid) if access_pid else None,
                "captured_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            })

        identity = state.snapshot().get("access_identity", {})
        verification = verify_access_identity(
            identity.get("access_pid"), identity.get("access_creation"), set(baseline)
        )
        state.record(identity_verification=verification)
        # Flush the parent-readable identity file before any armed open.
        write_json_flushed(out_dir / "identity.json", {**identity, "verification": verification})
        if not verification["owned"]:
            state.record(aborted="Access identity not positively verified; armed open refused")
            return EXIT_UNVERIFIED_IDENTITY

        observer = threading.Thread(
            target=_observe_dialogs, args=(observer_stop, access_pid, state), daemon=True
        )
        observer.start()
        state.record(observer_started=True)

        try:
            app.Visible = False
        except Exception as exc:  # noqa: BLE001
            state.record(visible_error=str(exc))
        try:
            app.UserControl = False
        except Exception as exc:  # noqa: BLE001
            state.record(usercontrol_error=str(exc))

        app.AutomationSecurity = args.security
        readback = int(app.AutomationSecurity)
        state.record(
            security_readback=readback,
            security_readback_matches=(readback == args.security),
        )
        if readback != args.security:
            state.record(aborted="AutomationSecurity readback mismatch; not opening armed file")
            return EXIT_SECURITY_MISMATCH

        open_started = time.monotonic()
        try:
            app.OpenCurrentDatabase(str(args.db))
            state.record(
                open_ok=True,
                open_seconds=round(time.monotonic() - open_started, 3),
            )
        except Exception as exc:  # noqa: BLE001
            state.record(
                open_ok=False,
                open_seconds=round(time.monotonic() - open_started, 3),
                open_error=repr(exc),
            )
            return EXIT_OPEN_FAILED

        # Access version string only; never claim an unmeasured bitness or provider.
        try:
            state.record(access_version=str(app.Version))
        except Exception as exc:  # noqa: BLE001
            state.record(access_version=f"<unreadable: {exc}>")

        # Bounded settle: give a queued AutoExec action (and any warning dialog it
        # raises) time to appear. No keyboard input or dialog dismissal is ever sent.
        settle_deadline = time.monotonic() + args.settle_seconds
        while time.monotonic() < settle_deadline:
            time.sleep(0.25)
        state.record(settled_seconds=round(time.monotonic() - open_started, 3))

        # Graceful shutdown (the parent still owns the hard kill).
        try:
            app.CloseCurrentDatabase()
            state.record(close_current_ok=True)
        except Exception as exc:  # noqa: BLE001
            state.record(close_current_ok=False, close_error=str(exc))
        try:
            app.Quit()
            state.record(quit_ok=True)
        except Exception as exc:  # noqa: BLE001
            state.record(quit_ok=False, quit_error=str(exc))
        app = None
    finally:
        observer_stop.set()
        if observer is not None:
            observer.join(timeout=2.0)
        if app is not None:
            # Best-effort graceful quit of our OWN instance on every abort path; this is
            # not a kill and is never applied to a foreign process.
            try:
                app.Quit()
            except Exception:
                pass
        try:
            state.record(
                locks_after=lock_files(out_dir),
                finished_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
            )
        except Exception:
            pass
        app = None
        pythoncom.CoUninitialize()
    return EXIT_OK


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cell", required=True)
    parser.add_argument("--run", type=int, required=True)
    parser.add_argument("--db", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--security", type=int, required=True)
    parser.add_argument("--settle-seconds", type=float, default=12.0)
    args = parser.parse_args()
    try:
        return run_cell(args)
    except Exception as exc:  # noqa: BLE001 - a crash is evidence, not silence
        try:
            write_json_flushed(Path(args.out_dir) / "result.json", {"fatal": repr(exc)})
        except Exception:
            pass
        print(f"CELL_FATAL: {exc!r}", file=sys.stderr)
        return EXIT_FATAL


if __name__ == "__main__":
    raise SystemExit(main())
