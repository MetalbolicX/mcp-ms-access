# Non-VBA AutoExec canary spike — scratch harness (throwaway; parent removes after validation)

Scope: **experiment only**, authorized as the L8 follow-up to
`odd/tasks/documentation-workflows-v2.md`. No production code, no canonical-fixture
edits, no commits, no push, no Trust Center / registry / trusted-location / Access-option
changes.

## What this decides

The prior feasibility spike proved that a `RunCode` (VBA) AutoExec and a startup-form
`OnLoad` VBA expression stay silent when a copy is opened under
`AutomationSecurity = 3` (force-disable). It explicitly left open whether the **macro
engine** executes a **pure macro action** while VBA is blocked ("a macro engine could
execute actions while blocking VBA and leave these markers absent").

This spike answers exactly that: a fresh DAO-built copy carries an `AutoExec` macro whose
only action is

```
OpenQuery("qryAppendCanary")
```

where `qryAppendCanary` is a saved append query inserting exactly
`(ProbeID = 1, Label = 'NON_VBA_AUTOEXEC')` into the local canary table `CanaryRows`.
There is **no VBA module, function, `RunCode`, form, `OnLoad`, startup form, linked
table, or external database**. The row is observed with an **independent DAO read**
before the armed open and again after Access is closed and reaped - never by a VBA
callback and never by the child that hosted Access.

- **Suppressed** under force-disable on all three fresh copies (canary row set stays
  `[]`) -> this non-VBA action does not execute at fixture scope; the Tier 2 planning
  gate may continue.
- **Inserted in any force-disable copy** -> the recipe is rejected; stop the Tier 2
  planning gate rather than weakening the contract.
- **Positive control not firing** -> every "no insertion" result is vacuous; the result
  is inconclusive, never a pass.

## Exact command (launch via the parent's background runner — takes minutes, do not run foreground)

```powershell
.venv\Scripts\python.exe db\fixtures\e2e-v2-spike-nonvba-20261017-90be035e\run_spike.py --all
```

Bounded preflight already run by the spike author (no Access, no COM, no DAO, ~1 s):

```powershell
.venv\Scripts\python.exe db\fixtures\e2e-v2-spike-nonvba-20261017-90be035e\run_spike.py --self-check
```

`--all` refuses to run if `fixture/` already exists (it never overwrites a fixture),
and it never deletes evidence.

## Fixture recipe (what "non-VBA" means here, precisely)

| Element | Value | Notes |
| --- | --- | --- |
| Canary table | `CanaryRows([ProbeID] LONG PK NOT NULL, [Label] TEXT(64))` | DAO DDL; bracketed identifiers (L6 reserved-word lesson) |
| Saved query | `qryAppendCanary` = `INSERT INTO CanaryRows ([ProbeID], [Label]) VALUES (1, 'NON_VBA_AUTOEXEC')` | DAO `CreateQueryDef`; single known row |
| Macro | `AutoExec` with one `OpenQuery` action on `qryAppendCanary` | pure macro action; no `RunCode`, no module |
| Deliberately absent | VBA module, function, form, `OnLoad`, `StartupForm` property, `AutoKeys`, `SetWarnings` | `SetWarnings` is omitted on purpose: it would mask the very action-query warning this experiment must observe |

### How the pure-macro dialect is justified (versus assumed)

- **Framing dialect** (`Version =196611`, `ColumnsShown =0`, `Begin`,
  `Action ="..."`, `Argument ="..."`, `End`, CRLF only) is the SaveAsText/LoadFromText
  AXL dialect captured live on 2026-10-10 and recorded in
  `src/ms_access_mcp/backends/access/macros.py`; it is the same dialect
  `scripts/generate_documentation_fixtures.py` and the prior spike archive use for
  `RunCode`/`AutoKeys` macros. `Action` carries the English macro action name.
- **`OpenQuery`** is that dialect's name for the OpenQuery macro action; the builder does
  **not** assume it parsed. After `LoadFromText(4, "NonVBAProbe", ...)` it calls
  `SaveAsText(4, "NonVBAProbe", captured_macro_neutral.txt)` **before the rename-to-
  AutoExec**, then asserts the captured text contains `OpenQuery` and `qryAppendCanary`
  and contains none of `runcode`, `function`, `onload`, `startupform`, `vbe`.
- If the load/capture/inspection fails, the builder exits `20 BLOCKED-build` with the
  reason. There is **no automatic fallback to VBA** and no improvisation.

## Build-order discipline (never execute startup code)

1. DAO-only creation of `armed.accdb`, the empty canary table, and the saved append
   query.
2. `Access.Application` (fresh `DispatchEx`, `AutomationSecurity = 3` read back and
   asserted) opens the database while it has **no** auto-run object:
   `CurrentProject.AllMacros` is empty, modules/forms are empty, and no `StartupForm`
   property exists.
3. Import the macro under the neutral name `NonVBAProbe`, then `SaveAsText`-capture and
   inspect its real stored text.
4. **Last mutation**: rename `NonVBAProbe` -> `AutoExec`, then close. The builder never
   reopens the armed fixture with Access; its post-build check is DAO-only.

## Matrix (N = 3 each, positive control first)

| cell | `AutomationSecurity` | copy | expected observation |
| --- | --- | --- | --- |
| `POS` | 1 (low) | fresh copy | after the run the DAO canary read must be exactly `[{ProbeID:1, Label:'NON_VBA_AUTOEXEC'}]`, on every run |
| `FD` | 3 (force-disable) | fresh copy | after the run the DAO canary read must stay `[]`, on every run |

Per run the runner performs, in order: (1) copy `armed.accdb` into the run directory;
(2) **independent DAO read #1**, which must be `[]`; (3) fail-closed check of the copy's
lock state; (4) run the cell child (fresh `DispatchEx`, identity proven and flushed
before the armed open, version recorded); (5) parent-side grace-then-PID-scoped kill if
needed; (6) **independent DAO read #2** after Access is reaped. The row set is never read
by the child that hosted Access.

Verdict (`compute_verdicts`, exercised synthetically by `--self-check`):

- PASS (exit 0) = build ok + POS inserts the exact row on all 3 runs + FD leaves `[]`
  on all 3 runs + canonical hashes unchanged + zero new MSACCESS PIDs.
- Missing/failed/vacuous positive control -> `10` (never a pass).
- Any FD insertion, or an invalid FD run -> `11` (security recipe rejected).
- A cell timeout -> `12`, except a POS timeout with an observed dialog-class window,
  which is reported as the inconclusive `10` "blocked by modal dialog" case.
- Hash diff, foreign MSACCESS pid, pre-existing canary rows, unreadable DAO readback,
  lock residue -> `13`.
- Exit codes preserved from the prior spike; a STOP is explicitly nonzero.

## Safety envelope (unchanged boundaries, hardened for this recipe)

- Fresh **`DispatchEx`** Access instances only; existing `MSACCESS.EXE` PIDs are
  baselined, recorded, protected, and never killed.
- Ownership is **fail-closed**: an armed open requires a pid absent from the baseline, a
  non-null captured creation time, a live matching creation time, and the
  `MSACCESS.EXE` image. `kill_pid_scoped` performs **no kill** unless every proof passes
  (no `/IM`, no baseline-diff kill). Any failure to prove ownership aborts before the
  armed open.
- If the pre-open DAO read fails or a lock file remains on the copy, the armed copy is
  **not opened** (fail-closed).
- The child starts a read-only window observer (`tests/helpers/dialog_watcher.py`
  `collect_windows`) before the armed open; the parent samples owned windows before any
  hard kill. **No synthetic keyboard/UI input, no automatic dialog acceptance, no mode
  setting change.** If the positive control can only fire after a UI setting change or a
  manual confirmation, the result is the inconclusive `10`, never a silent
  `warnings=False`.
- Per-cell child hard timeout 120 s; the parent owns the kill and the orphan sweep.
  A timeout stops the matrix (no retry, no background migration).
- Canonical files (`db/fixtures/documentation/**`, `db/northwind.accdb`) are
  sha256-hashed before and after; PASS additionally requires unchanged hashes and zero
  new MSACCESS PIDs.
- All copies, macro text, captured macro text, and evidence live under this scratch root
  on `D:`; nothing is written to a `C:` temp directory.
- `Application.Version` is recorded as a string; no bitness or provider version is
  claimed that was not read back.

## Evidence

```
evidence/
  hashes_before.json, baseline_msaccess_pids.json
  build_result.json, build_stdout.txt, build_stderr.txt
  cells/<POS|FD>/run_<n>/
      rows_before.json, rows_after.json          <- independent DAO observations
      dao_before_stdout.txt, dao_before_stderr.txt, dao_after_stdout.txt, dao_after_stderr.txt
      identity.json, result.json, run_record.json, stdout.txt, stderr.txt
  summary.json          <- verdicts, per-cell row sets, orphan sweep, hash diff
fixture/
  armed.accdb, nonvba_autoexec.txt, captured_macro_neutral.txt,
  build_identity.json, build_report.json
```

Every `run_record.json` preserves the candidate set at every stage: identity capture and
verification, security readback, `Access.Version`, open result, all observed windows,
pre/post lock state, the full DAO row set and row count before/after, rows inserted by
the candidate, rows that are not the expected tuple, and the exact child return code.

## Known limitation before the live run

`run_spike.py --self-check` is deliberately COM-free: the DAO reader
(`read_canary_snapshot` / `dao_read.py`) and both Access phases are unexercised until the
parent launches `--all`. The verdict arithmetic, fail-closed kill semantics, watcher
surface, and dialect/row vocabulary are all covered by the bounded self-check and its 18
synthetic verdict cases. `probe_dao.py` is retained from the prior spike as a reference
only; this experiment uses `dao_read.py` and never runs it.
