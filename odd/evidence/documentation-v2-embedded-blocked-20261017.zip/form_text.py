"""Pure form-text dialect ladder for the T5 embedded event-macro build (no COM here).

The T5 research question needs a form whose event carries an **embedded macro** whose
sole action is ``OpenQuery("qryAppendCanary")``. Access exposes no documented
object-model call that creates an embedded event macro, so the builder attempts the
sanctioned route instead: build the form with ``CreateForm``/``CreateControl`` (proven
in T4), let Access itself emit the form text with ``SaveAsText``, modify that text to
attach the embedded macro, and ``LoadFromText`` it back. Every candidate framing below
is therefore *mixed into Access' own text*, never into a hand-written form dialect.

This module is deliberately COM-free and side-effect-free so ``run_spike.py
--self-check`` can prove, bounded and offline, that

* each candidate inserts the placeholder property exactly once,
* each body candidate inserts the OpenQuery/query-name markers,
* the insertion lands in the form-property region (before the first nested ``Begin``),
* the candidate list is bounded and ordered (no unbounded search).

Observations from the archive that shaped the framings:

* the real named-macro text dialect is ``Version =196611`` / ``ColumnsShown =0`` /
  ``Begin`` / ``Action ="..."`` / ``Argument ="..."`` / ``End`` with CRLF only
  (``src/ms_access_mcp/backends/access/macros.py``, captured live 2026-10-10);
* a real macro object stores its AXL body in a ``Comment ="_AXL:<?xml ..."`` property,
  so an embedded macro body is *not* the same block shape as a named macro body;
* the T4 ``SaveAsText`` form export shows the form-property region followed by a bare
  ``Begin`` block that holds controls and sections, so a form-level macro block must be
  inserted before that bare ``Begin``.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

EVENT_PROPERTY = "OnLoad"
PLACEHOLDER_VALUE = "[Embedded Macro]"
PLACEHOLDER_LINE = f'    {EVENT_PROPERTY} ="{PLACEHOLDER_VALUE}"'

# The macro framing of the named-macro dialect, re-indented one level for a form-level
# block (8 spaces for its own lines, 12 for the action lines).
_MACRO_FRAMING = (
    '        Version =196611',
    '        ColumnsShown =0',
    '        Begin',
    '            Action ="OpenQuery"',
    '            Argument ="qryAppendCanary"',
    '        End',
)

# Markers the builder searches for in Access' own round-tripped form text.
ROUNDTRIP_BODY_MARKERS = ("openquery", "qryappendcanary")

# Synthetic form text used ONLY by ``--self-check`` to exercise the pure helpers. It
# mirrors the shape of the archived T4 ``export_form.txt`` (form properties, then a bare
# Begin block holding a section with one control) and is never used for a live build.
SYNTHETIC_BASE_FORM_TEXT = "\r\n".join(
    [
        "Version =21",
        "VersionRequired =20",
        "Checksum =272465623",
        "Begin Form",
        '    Width =6000',
        '    DatasheetFontName ="Aptos"',
        "    Begin",
        "        Begin Section",
        '            Name ="Detail"',
        "            Begin",
        "                Begin TextBox",
        '                    Name ="txtProbe"',
        "                End",
        "            End",
        "        End",
        "    End",
        "End",
        "",
    ]
)


def strip_checksum_lines(base_text: str) -> tuple[str, int]:
    """Drop the stale ``Checksum`` line from Access' own exported form text.

    Access writes a content checksum into the form text; modifying the text without
    removing it would leave a checksum that no longer describes the object, which is a
    plausible reason for ``LoadFromText`` to reject the import. The count of removed
    lines is recorded as evidence either way.
    """
    newline = "\r\n" if "\r\n" in base_text else "\n"
    lines = base_text.split(newline)
    kept = [line for line in lines if not line.strip().startswith("Checksum =")]
    return newline.join(kept), len(lines) - len(kept)


def form_property_insert_index(lines: list[str]) -> int:
    """Index of the first nested ``Begin`` inside ``Begin Form`` (the insertion point).

    Falls back to the final ``End`` line so an unusual (but still parsed) form text is
    handled deterministically rather than by guessing.
    """
    start = None
    for index, line in enumerate(lines):
        if line.strip() == "Begin Form":
            start = index + 1
            break
    if start is None:
        return 0
    for index in range(start, len(lines)):
        stripped = lines[index].strip()
        if not stripped:
            continue
        if len(lines[index]) - len(lines[index].lstrip(" ")) == 4 and stripped.startswith("Begin"):
            return index
    for index in range(len(lines) - 1, start - 1, -1):
        if lines[index].strip() == "End":
            return index
    return len(lines)


def insert_block(base_text: str, block_lines: tuple[str, ...]) -> tuple[str, int]:
    """Insert ``block_lines`` into the form-property region; return text and index."""
    newline = "\r\n" if "\r\n" in base_text else "\n"
    lines = base_text.split(newline)
    index = form_property_insert_index(lines)
    merged = lines[:index] + list(block_lines) + lines[index:]
    return newline.join(merged), index


def _placeholder_block() -> tuple[str, ...]:
    return (PLACEHOLDER_LINE,)


def _candidate_e0(base_text: str) -> tuple[str, int]:
    """Insert the placeholder property only (no macro body block)."""
    return insert_block(base_text, _placeholder_block())


def _candidate_e1(base_text: str) -> tuple[str, int]:
    """Access-style nested block: ``Begin Embedded Macro`` ... ``End``."""
    return insert_block(
        base_text,
        (PLACEHOLDER_LINE, "", "    Begin Embedded Macro") + _MACRO_FRAMING + ("    End",),
    )


def _candidate_e2(base_text: str) -> tuple[str, int]:
    """Property-shaped block: ``EmbeddedMacro = Begin`` ... ``End``."""
    return insert_block(
        base_text,
        (PLACEHOLDER_LINE, "", "    EmbeddedMacro = Begin") + _MACRO_FRAMING + ("    End",),
    )


def _candidate_e3(base_text: str) -> tuple[str, int]:
    """Named-macro-shaped block: ``Begin Macro`` ... ``End``."""
    return insert_block(
        base_text,
        (PLACEHOLDER_LINE, "", "    Begin Macro") + _MACRO_FRAMING + ("    End",),
    )


def _candidate_e4(base_text: str) -> tuple[str, int]:
    """Bare form-level block: ``Begin`` ... ``End`` (same shape as the controls block)."""
    return insert_block(
        base_text,
        (PLACEHOLDER_LINE, "", "    Begin") + _MACRO_FRAMING + ("    End",),
    )


EMBEDDING_CANDIDATES: tuple[dict[str, Any], ...] = (
    {
        "id": "E0",
        "description": "placeholder property only (no macro body block)",
        "body": False,
        "build": _candidate_e0,
    },
    {
        "id": "E1",
        "description": "placeholder + `Begin Embedded Macro` block carrying the OpenQuery framing",
        "body": True,
        "build": _candidate_e1,
    },
    {
        "id": "E2",
        "description": "placeholder + `EmbeddedMacro = Begin` property-shaped block",
        "body": True,
        "build": _candidate_e2,
    },
    {
        "id": "E3",
        "description": "placeholder + `Begin Macro` block",
        "body": True,
        "build": _candidate_e3,
    },
    {
        "id": "E4",
        "description": "placeholder + bare `Begin`/`End` form-level block",
        "body": True,
        "build": _candidate_e4,
    },
)

CANDIDATE_IDS: tuple[str, ...] = tuple(str(candidate["id"]) for candidate in EMBEDDING_CANDIDATES)


def candidate_by_id(candidate_id: str) -> dict[str, Any]:
    """Return the candidate descriptor for ``candidate_id``."""
    for candidate in EMBEDDING_CANDIDATES:
        if candidate["id"] == candidate_id:
            return candidate
    raise KeyError(f"unknown embedding candidate: {candidate_id}")


def build_candidate_text(candidate_id: str, base_text: str) -> tuple[str, int]:
    """Strip the stale checksum, then insert the candidate block; return text + index."""
    candidate = candidate_by_id(candidate_id)
    stripped, _removed = strip_checksum_lines(base_text)
    build: Callable[[str], tuple[str, int]] = candidate["build"]
    return build(stripped)


def candidate_markers(candidate_id: str, base_text: str) -> dict[str, bool]:
    """Structural expectations for one candidate against ``base_text``."""
    candidate = candidate_by_id(candidate_id)
    _stripped, removed = strip_checksum_lines(base_text)
    text, _index = build_candidate_text(candidate_id, base_text)
    placeholder_count = sum(1 for line in text.splitlines() if line == PLACEHOLDER_LINE)
    lowered = text.lower()
    return {
        "checksum_reflected": removed == (
            1 if "Checksum =" in base_text else 0
        ),
        "stale_checksum_removed": "Checksum =" not in text,
        "placeholder_present_once": placeholder_count == 1,
        "macro_framing_present": candidate["body"] is False or 'Action ="OpenQuery"' in text,
        "body_markers_present": candidate["body"] is False
        or all(marker in lowered for marker in ROUNDTRIP_BODY_MARKERS),
        "base_text_prefix_preserved": text.splitlines()[0] == base_text.splitlines()[0]
        if base_text.splitlines()
        else True,
        "no_form_removal": "Begin Form" in text and newline_end_present(text),
        "insert_index_in_property_region": _index > 0,
    }


def newline_end_present(text: str) -> bool:
    """Report whether the modified text still ends with an ``End`` line (form intact)."""
    lines = [line for line in text.splitlines() if line.strip()]
    return bool(lines) and lines[-1].strip() == "End"


def rank_attempt(attempt: dict[str, Any]) -> tuple[int, int, int, int]:
    """Rank one ladder attempt: (roundtrip body, roundtrip placeholder, readback, loaded)."""
    return (
        1 if attempt.get("roundtrip_body_markers_found") else 0,
        1 if attempt.get("roundtrip_placeholder_found") else 0,
        1 if attempt.get("readback_matches_placeholder") else 0,
        1 if attempt.get("load_ok") else 0,
    )


ATTEMPT_BAR_KEYS = ("load_ok", "readback_matches_placeholder", "roundtrip_placeholder_found")


def attempt_meets_bar(attempt: dict[str, Any]) -> bool:
    """Minimum bar for an attempt to carry the embedded macro at all.

    The text must import, the placeholder must still be the stored event value in design
    view, and Access' own re-export must still show the placeholder. Whether the macro
    *body* survived is reported separately (it may legitimately be invisible in the text
    export), and the matrix' low-security positive control is the behavioural gate.
    """
    return all(attempt.get(key) for key in ATTEMPT_BAR_KEYS)


def select_body_attempt(attempts: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Best *body-bearing* candidate that meets the bar, or ``None`` (-> BUILD_BLOCKER).

    ``E0`` (placeholder only) is diagnostic evidence, never a result: an event property
    naming an embedded macro with no accepted body block cannot carry the canary action,
    so installing it would make the whole experiment vacuous. A body-visible round-trip
    outranks a body-invisible one; ties keep the earlier (lower-id) candidate.
    """
    usable = [
        attempt
        for attempt in attempts
        if attempt.get("expects_body") and attempt_meets_bar(attempt)
    ]
    if not usable:
        return None
    return max(
        usable,
        key=lambda attempt: (rank_attempt(attempt), -CANDIDATE_IDS.index(attempt["candidate"])),
    )


__all__ = [
    "ATTEMPT_BAR_KEYS",
    "CANDIDATE_IDS",
    "EMBEDDING_CANDIDATES",
    "EVENT_PROPERTY",
    "PLACEHOLDER_LINE",
    "PLACEHOLDER_VALUE",
    "ROUNDTRIP_BODY_MARKERS",
    "SYNTHETIC_BASE_FORM_TEXT",
    "attempt_meets_bar",
    "build_candidate_text",
    "candidate_by_id",
    "candidate_markers",
    "form_property_insert_index",
    "insert_block",
    "newline_end_present",
    "rank_attempt",
    "select_body_attempt",
    "strip_checksum_lines",
]
