r"""Outer runner for the T5 embedded form-event-macro spike.

Owns the safety envelope the child cannot: the per-cell hard timeout, fail-closed
PID-scoped hard kills, parent-side window sampling on timeout, the two independent DAO
observations per run (before the armed open / after Access is reaped), canonical-file hash
protection, the orphan sweep, and the evidence bundle.

Usage (launch through the parent's background runner; the matrix takes minutes):::

    .venv\\Scripts\\python.exe db\\fixtures\\e2e-v2-embedded-<id>\\run_spike.py --all

Bounded preflight (no Access, no COM, no DAO; a few seconds):::

    .venv\\Scripts\\python.exe db\\fixtures\\e2e-v2-embedded-<id>\\run_spike.py --self-check

Build only (bounded; useful to see a BUILD_BLOCKER without spending the matrix):::

    .venv\\Scripts\\python.exe db\\fixtures\\e2e-v2-embedded-<id>\\run_spike.py --build-only

``--all`` refuses to run if ``fixture/`` already exists (it never overwrites a fixture) and
never deletes evidence.

Exit codes (a STOP is explicitly nonzero, never masked as success)::

    0  PASS
    10 STOP-inconclusive-positive-control (the low-security control did not insert the
       canary row, or a modal dialog blocked it; no synthetic input was sent)
    11 STOP-recipe-not-clean (ForceDisable did not suppress the embedded event macro, or a
       recipe run was invalid/left residue) -> security recipe rejected, Tier 2 gate
    12 STOP-execution-timeout (a cell timed out with no dialog evidence)
    13 STOP-integrity (canonical hash changed, foreign MSACCESS appeared, lock residue after
       a graceful close, an unverified kill, missing/absent trigger object, unreadable DAO
       readback, pre-existing canary rows)
    20 BLOCKED-build (fixture or embedded-macro build did not succeed)
    21 BLOCKED-overall-timeout
    30 INFRA-error (unexpected runner failure)
"""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

import form_text  # noqa: E402
from harness_common import (  # noqa: E402
    CANARY_LABEL,
    CANARY_PROBE_ID,
    FIXTURE_DB_NAME,
    FORM_NAME,
    MSO_FORCE_DISABLE,
    MSO_LOW,
    ROOT,
    WindowObserver,
    baseline_pids,
    canonical_hashes,
    diff_hashes,
    process_is_alive,
    read_json,
    read_process_identity,
    reap_access,
    rows_empty,
    rows_match_expected,
    sample_windows,
    sha256_text,
    snapshot_trigger_evidence,
    verified_kill_python,
    wait_until,
    write_json_flushed,
)

SCRATCH = Path(__file__).resolve().parent
FIXTURE_DIR = SCRATCH / "fixture"
EVIDENCE_DIR = SCRATCH / "evidence"
COPY_ROOT = SCRATCH / "scratch"
BUILD_TIMEOUT = 300.0
CELL_TIMEOUT = 120.0
DAO_TIMEOUT = 90.0
SETTLE_SECONDS = 12.0

HARNESS_MODULES = (
    "harness_common.py",
    "form_text.py",
    "dao_read.py",
    "build_fixture.py",
    "cell.py",
    "run_spike.py",
)
# ``run_spike.py`` itself carries the forbidden-token list below, so the static scan runs
# over the modules that actually issue process/UI calls.
SAFETY_SCAN_MODULES = ("harness_common.py", "form_text.py", "dao_read.py", "build_fixture.py", "cell.py")
FORBIDDEN_TOKENS = ("/IM", "/IMAGENAME")

EXIT_CODES = {
    "PASS": 0,
    "STOP-inconclusive-positive-control": 10,
    "STOP-recipe-not-clean": 11,
    "STOP-execution-timeout": 12,
    "STOP-integrity": 13,
    "BLOCKED-build": 20,
    "BLOCKED-overall-timeout": 21,
    "INFRA-error": 30,
}

# Fresh-copy matrix, positive control first. No neutralization cell: the question is
# exactly whether ForceDisable alone suppresses the embedded event macro.
CELLS = [
    {
        "id": "POS",
        "security": MSO_LOW,
        "runs": 3,
        "expect": "positive control: the startup form's embedded OnLoad macro runs "
        "OpenQuery on the saved append query and inserts exactly one canary row",
    },
    {
        "id": "FD",
        "security": MSO_FORCE_DISABLE,
        "runs": 3,
        "expect": "force-disable on an unchanged copy: canary row set stays [] while the "
        "startup form and its embedded event macro are still present",
    },
]


# ---------------------------------------------------------------------------------------
# bounded subprocess helpers
# ---------------------------------------------------------------------------------------
def _run_bounded(argv, cwd, timeout, stdout_path, stderr_path):
    """Start one bounded child, return (proc, child_creation, returncode, timed_out)."""
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    with stdout_path.open("w", encoding="utf-8") as out, stderr_path.open("w", encoding="utf-8") as err:
        proc = subprocess.Popen(  # noqa: S603 - fixed argv built in this harness, never a shell
            [str(item) for item in argv], cwd=str(cwd), stdout=out, stderr=err
        )
    live = read_process_identity(proc.pid)
    child_creation = live.creation if live else None
    timed_out = False
    try:
        returncode = proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        returncode = None
    return proc, child_creation, returncode, timed_out


def _dao_read(db_path: Path, phase: str, run_dir: Path) -> dict[str, Any]:
    """Run the independent DAO observer as its own bounded subprocess."""
    out_path = run_dir / f"rows_{phase}.json"
    argv = [
        sys.executable,
        str(SCRATCH / "dao_read.py"),
        "--db",
        str(db_path),
        "--phase",
        phase,
        "--out",
        str(out_path),
    ]
    proc, _creation, returncode, timed_out = _run_bounded(
        argv,
        SCRATCH,
        DAO_TIMEOUT,
        run_dir / f"dao_{phase}_stdout.txt",
        run_dir / f"dao_{phase}_stderr.txt",
    )
    if timed_out:
        proc.kill()
        proc.wait(timeout=15)
    snapshot = read_json(out_path)
    if not isinstance(snapshot, dict):
        snapshot = {
            "schema": "v2-spike-embedded.dao-read/1",
            "ok": False,
            "rows": [],
            "containers": {},
            "dao_error": "no snapshot written",
        }
    snapshot = dict(snapshot)
    snapshot["returncode"] = returncode
    snapshot["timed_out"] = timed_out
    snapshot["phase"] = phase
    return snapshot


# ---------------------------------------------------------------------------------------
# build
# ---------------------------------------------------------------------------------------
def build_fixture() -> dict[str, Any]:
    """Run the bounded fixture build child and record its identity and cleanup."""
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    if FIXTURE_DIR.exists():
        return {"ok": False, "error": f"fixture dir already exists: {FIXTURE_DIR}"}
    argv = [sys.executable, str(SCRATCH / "build_fixture.py"), "--out-dir", str(FIXTURE_DIR)]
    proc, creation, returncode, timed_out = _run_bounded(
        argv,
        SCRATCH,
        BUILD_TIMEOUT,
        EVIDENCE_DIR / "build_stdout.txt",
        EVIDENCE_DIR / "build_stderr.txt",
    )
    if timed_out:
        proc.kill()
        proc.wait(timeout=15)
    identity = read_json(FIXTURE_DIR / "build_identity.json") or {}
    cleanup = reap_access(
        identity.get("access_pid"), identity.get("access_creation"), identity.get("access_image")
    )
    report = read_json(FIXTURE_DIR / "build_report.json") or {}
    ok = returncode == 0 and not timed_out and "error" not in report
    result = {
        "returncode": returncode,
        "timed_out": timed_out,
        "child_creation": creation,
        "identity": identity,
        "access_cleanup": cleanup,
        "python_child_after_timeout": (
            verified_kill_python(proc.pid, creation) if timed_out else {"result": "not-needed"}
        ),
        "report": report,
        "ok": ok,
    }
    write_json_flushed(EVIDENCE_DIR / "build_result.json", result)
    _archive_fixture_evidence()
    return result


def _archive_fixture_evidence() -> None:
    """Copy the fixture's form-text dialect evidence into the evidence bundle."""
    target = EVIDENCE_DIR / "form_dialect"
    try:
        target.mkdir(parents=True, exist_ok=True)
        for name in ("form_base_access.txt", "form_final_installed.txt", "build_report.json"):
            source = FIXTURE_DIR / name
            if source.exists():
                shutil.copy2(source, target / name)
        embed_source = FIXTURE_DIR / "embedding_attempts"
        if embed_source.is_dir():
            embed_target = target / "embedding_attempts"
            embed_target.mkdir(parents=True, exist_ok=True)
            for path in sorted(embed_source.glob("*.txt")):
                shutil.copy2(path, embed_target / path.name)
    except Exception as exc:  # noqa: BLE001 - archiving is evidence bookkeeping
        write_json_flushed(EVIDENCE_DIR / "form_dialect" / "archive_error.json", {"error": repr(exc)})


# ---------------------------------------------------------------------------------------
# one matrix run
# ---------------------------------------------------------------------------------------
def _aborted_record(cell: dict, run_index: int, reason: str, before: dict, run_dir: Path) -> dict:
    rows_before = before.get("rows") if isinstance(before.get("rows"), list) else []
    return {
        "cell": cell["id"],
        "run": run_index,
        "security_requested": cell["security"],
        "child_returncode": None,
        "child_returncode_after_kill": None,
        "timed_out": False,
        "aborted_before_open": reason,
        "identity": {},
        "identity_verification": None,
        "access_pid_in_baseline": None,
        "cleanup_after": {"result": "not-dispatched"},
        "reap_mode": "not-dispatched",
        "residual_owned_pid": False,
        "graceful_lock_residue": False,
        "unverified_kill": False,
        "pre_locks_clear": None,
        "pre_locks": [],
        "locks": [],
        "rows_before_read_ok": before.get("ok") is True,
        "rows_before": rows_before,
        "rows_before_count": len(rows_before),
        "rows_before_error": before.get("dao_error"),
        "rows_after_read_ok": False,
        "rows_after": [],
        "rows_after_count": 0,
        "rows_after_error": "not-read: aborted before the armed open",
        "rows_inserted_observed": [],
        "rows_unexpected": [],
        "before_snapshot": snapshot_trigger_evidence(before),
        "after_snapshot": None,
        "dialogs": [],
        "timeout_dialogs": [],
        "all_observed_windows": [],
        "observer_started": False,
        "observer_error": None,
        "security_readback": None,
        "open_ok": None,
        "open_error": "not-open: aborted before the armed open",
        "access_version": None,
        "run_dir": str(run_dir.relative_to(ROOT)).replace("\\", "/"),
    }


def run_one(cell: dict, run_index: int, baseline: set[int]) -> dict[str, Any]:
    """Run one matrix cell on one fresh copy and return its full run record."""
    run_dir = COPY_ROOT / f"{cell['id']}-run{run_index}"
    run_dir.mkdir(parents=True, exist_ok=True)
    copy = run_dir / FIXTURE_DB_NAME
    shutil.copy2(FIXTURE_DIR / FIXTURE_DB_NAME, copy)

    # Independent DAO observation #1: a fresh copy must show zero canary rows, the startup
    # form trigger, no VBA modules and no named macros before anything opens it.
    before = _dao_read(copy, "before", run_dir)
    pre_locks_clear = wait_until(lambda: not (copy.with_suffix(".laccdb")).exists(), 10.0)
    pre_locks = sorted(path.name for path in run_dir.glob("*.laccdb"))
    before_evidence = snapshot_trigger_evidence(before)
    if isinstance(before.get("trigger_evidence"), dict):
        before_evidence = before["trigger_evidence"]

    # Fail-closed: without a clean, readable pre-open observation of the trigger object the
    # armed copy is never opened through Access.
    abort_reason = None
    if before.get("ok") is not True:
        abort_reason = "pre-open DAO read failed"
    elif before_evidence.get("startup_form_property") != FORM_NAME:
        abort_reason = (
            f"pre-open trigger missing: StartupForm={before_evidence.get('startup_form_property')!r}"
        )
    elif pre_locks:
        abort_reason = f"pre-open lock residue: {pre_locks}"
    elif not pre_locks_clear:
        abort_reason = "pre-open lock file did not clear within the grace period"
    if abort_reason:
        record = _aborted_record(cell, run_index, abort_reason, before, run_dir)
        record["pre_locks_clear"] = pre_locks_clear
        record["pre_locks"] = pre_locks
        record["locks"] = sorted(path.name for path in run_dir.glob("*.laccdb"))
        record["before_snapshot"] = before_evidence
        write_json_flushed(run_dir / "run_record.json", record)
        return record

    argv = [
        sys.executable,
        str(SCRATCH / "cell.py"),
        "--cell",
        cell["id"],
        "--run",
        str(run_index),
        "--db",
        str(copy),
        "--out-dir",
        str(run_dir),
        "--security",
        str(cell["security"]),
        "--settle-seconds",
        str(SETTLE_SECONDS),
    ]
    proc, child_creation, child_rc, timed_out = _run_bounded(
        argv, SCRATCH, CELL_TIMEOUT, run_dir / "stdout.txt", run_dir / "stderr.txt"
    )
    identity = read_json(run_dir / "identity.json") or {}
    access_pid = identity.get("access_pid")
    access_creation = identity.get("access_creation")
    access_image = identity.get("access_image")

    timeout_dialogs: list = []
    python_kill: dict[str, Any] = {"result": "not-needed"}
    if timed_out:
        # Observe before killing, then hard-kill by verified identity only.
        if access_pid:
            timeout_dialogs = sample_windows(access_pid)
        cleanup = reap_access(access_pid, access_creation, access_image, baseline)
        python_kill = verified_kill_python(proc.pid, child_creation)
        child_returncode_after_kill = proc.wait(timeout=20)
        reap_mode = "hard-timeout"
        wait_until(lambda: not process_is_alive(access_pid) if access_pid else True, 10.0)
    else:
        child_returncode_after_kill = child_rc
        if access_pid is not None:
            if wait_until(lambda: not process_is_alive(access_pid), 15.0):
                cleanup = {
                    "pid": access_pid,
                    "verified": False,
                    "terminated": False,
                    "exited": True,
                    "detail": "exited within the 15-second post-child grace; no kill attempted",
                }
                reap_mode = "graceful"
            else:
                cleanup = reap_access(access_pid, access_creation, access_image, baseline)
                wait_until(lambda: not process_is_alive(access_pid), 10.0)
                reap_mode = "forced-after-grace"
        else:
            cleanup = {"pid": None, "result": "no-pid-captured"}
            reap_mode = "no-pid-captured"

    # Independent DAO observation #2: only after Access is closed and reaped.
    wait_until(lambda: not (copy.with_suffix(".laccdb")).exists(), 10.0)
    after = _dao_read(copy, "after", run_dir)

    result = read_json(run_dir / "result.json") or {}
    after_evidence = snapshot_trigger_evidence(after)
    if isinstance(after.get("trigger_evidence"), dict):
        after_evidence = after["trigger_evidence"]
    dialogs = [item for item in (result.get("dialogs") or []) if item.get("is_dialog_class")]
    locks = sorted(path.name for path in run_dir.glob("*.laccdb"))
    rows_after = after.get("rows") if isinstance(after.get("rows"), list) else []
    expected = {"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}
    rows_before = before.get("rows") if isinstance(before.get("rows"), list) else []
    unverified_kill = bool(cleanup.get("terminated")) and not cleanup.get("verified")
    record = {
        "cell": cell["id"],
        "run": run_index,
        "security_requested": cell["security"],
        "child_returncode": child_rc,
        "child_returncode_after_kill": child_returncode_after_kill,
        "timed_out": timed_out,
        "python_child_creation": child_creation,
        "python_child_kill": python_kill,
        "identity": identity,
        "identity_verification": identity.get("verification"),
        "access_pid_in_baseline": access_pid in baseline if access_pid else None,
        "cleanup_after": cleanup,
        "reap_mode": reap_mode,
        "residual_owned_pid": bool(access_pid is not None and process_is_alive(access_pid)),
        "graceful_lock_residue": reap_mode == "graceful" and bool(locks),
        "unverified_kill": unverified_kill,
        "pre_locks_clear": pre_locks_clear,
        "pre_locks": pre_locks,
        "locks": locks,
        "rows_before_read_ok": before.get("ok") is True,
        "rows_before": rows_before,
        "rows_before_count": len(rows_before),
        "rows_before_error": before.get("dao_error"),
        "rows_after_read_ok": after.get("ok") is True,
        "rows_after": rows_after,
        "rows_after_count": len(rows_after),
        "rows_after_error": after.get("dao_error"),
        "rows_inserted_observed": [row for row in rows_after if row not in rows_before],
        "rows_unexpected": [row for row in rows_after if row != expected],
        "before_snapshot": before_evidence,
        "after_snapshot": after_evidence,
        "dialogs": dialogs,
        "timeout_dialogs": timeout_dialogs,
        "all_observed_windows": result.get("dialogs") or [],
        "observer_started": result.get("observer_started") is True,
        "observer_error": result.get("observer_error"),
        "security_readback": result.get("security_readback"),
        "open_ok": result.get("open_ok"),
        "open_error": result.get("open_error"),
        "access_version": result.get("access_version"),
        "run_dir": str(run_dir.relative_to(ROOT)).replace("\\", "/"),
    }
    write_json_flushed(run_dir / "run_record.json", record)
    return record


# ---------------------------------------------------------------------------------------
# verdict
# ---------------------------------------------------------------------------------------
def run_is_valid(record: dict[str, Any]) -> bool:
    """Report whether the harness itself worked and stayed honest for one run."""
    before = record.get("before_snapshot") or {}
    return (
        not record.get("timed_out")
        and record.get("child_returncode") == 0
        and record.get("open_ok") is True
        and record.get("security_readback") == record.get("security_requested")
        and record.get("observer_started") is True
        and not record.get("observer_error")
        and record.get("residual_owned_pid") is False
        and record.get("access_pid_in_baseline") is not True
        and record.get("pre_locks_clear") is True
        and not record.get("locks")
        and record.get("graceful_lock_residue") is False
        and record.get("unverified_kill") is False
        and record.get("rows_before_read_ok") is True
        and record.get("rows_before") == []
        and record.get("rows_after_read_ok") is True
        and before.get("startup_form_is_trigger") is True
        and before.get("form_document_present") is True
        and before.get("no_vba_modules") is True
        and before.get("no_named_macros") is True
    )


def compute_verdicts(
    runs: list[dict[str, Any]],
    *,
    build_ok: bool,
    embedding_body_proven: bool,
    overall_timeout_hit: bool,
    any_cell_timed_out: bool,
    timeout_dialog_blocked: bool,
    positive_dialog_observed: bool,
    integrity_errors: list[str],
    hash_diff: dict,
    new_pids: list[int],
    infra_error: str | None,
) -> dict[str, Any]:
    """Compute the non-vacuous PASS/STOP verdict from the run records (pure)."""
    pos = [record for record in runs if record["cell"] == "POS"]
    fd = [record for record in runs if record["cell"] == "FD"]

    positive_exact = len(pos) == 3
    positive_valid = positive_exact and all(run_is_valid(record) for record in pos)
    positive_inserted = positive_valid and all(
        rows_match_expected(record.get("rows_after")) for record in pos
    )
    positive_ok = positive_valid and positive_inserted

    fd_insertions = [
        record["run"]
        for record in fd
        if isinstance(record.get("rows_after"), list) and not rows_empty(record.get("rows_after"))
    ]
    fd_failures = [f"run {record['run']} not valid/clean" for record in fd if not run_is_valid(record)]
    for record in fd:
        after = record.get("after_snapshot") or {}
        if record.get("rows_after_read_ok") and after.get("startup_form_is_trigger") is not True:
            fd_failures.append(
                f"run {record['run']}: startup form trigger absent after the run "
                f"(StartupForm={after.get('startup_form_property')!r})"
            )
    if len(fd) != 3:
        fd_failures.append(f"expected 3 runs, have {len(fd)}")
    fd_valid = len(fd) == 3 and all(run_is_valid(record) for record in fd)
    fd_clean = fd_valid and not fd_insertions and not fd_failures

    unverified_kills = [
        f"{record['cell']} run {record['run']}" for record in runs if record.get("unverified_kill")
    ]
    hash_ok = bool(hash_diff.get("unchanged")) and not new_pids

    status = "PASS"
    reason = "ForceDisable suppressed the embedded startup-form event macro on all three fresh copies"
    if infra_error:
        status, reason = "INFRA-error", f"infra error: {infra_error}"
    elif not build_ok:
        status, reason = "BLOCKED-build", "fixture build did not succeed (see build_result.json)"
    elif overall_timeout_hit:
        status, reason = "BLOCKED-overall-timeout", "overall matrix timeout hit; stopped without retry"
    elif any_cell_timed_out:
        if timeout_dialog_blocked:
            status = "STOP-inconclusive-positive-control"
            reason = (
                "a positive-control cell timed out while a dialog-class window was observed "
                "(likely the action-query confirmation); no synthetic input was sent and no UI "
                "setting was changed, so the positive control is inconclusive"
            )
        else:
            status = "STOP-execution-timeout"
            reason = "a cell timed out with no dialog evidence; stopped without retry"
    elif integrity_errors:
        status, reason = "STOP-integrity", "; ".join(integrity_errors)
    elif unverified_kills:
        status = "STOP-integrity"
        reason = f"a kill was issued without a positive identity proof in {unverified_kills}"
    elif not positive_ok:
        status = "STOP-inconclusive-positive-control"
        if not positive_exact:
            reason = f"positive control did not complete exactly three runs (have {len(pos)})"
        elif not positive_valid:
            reason = "a positive-control run was not valid (harness/observer/open/readback)"
        elif positive_dialog_observed:
            reason = (
                "positive control produced no canary row while a dialog-class window was "
                "observed (likely the action-query confirmation); no synthetic input was sent "
                "and no UI setting was changed, so the positive control is inconclusive"
            )
        elif not embedding_body_proven:
            reason = (
                "positive control never produced the exact canary row [(1,'EMBEDDED_MACRO')] on "
                "every run, and the build could not show the embedded macro body in Access' own "
                "SaveAsText round-trip: the embedded event macro may not have survived the "
                "text build, so no suppression claim follows (BUILD-level inconclusive)"
            )
        else:
            reason = (
                "positive control never produced the exact canary row [(1,'EMBEDDED_MACRO')] on "
                "every run; absence of insertion under ForceDisable would be vacuous"
            )
    elif not hash_ok:
        status = "STOP-integrity"
        reason = (
            f"canonical hash/new-PID integrity failed "
            f"(changed={hash_diff.get('changed', [])}, new_pids={new_pids})"
        )
    elif fd_insertions:
        status = "STOP-recipe-not-clean"
        reason = (
            f"ForceDisable did not suppress the embedded event macro: canary row inserted in FD "
            f"run(s) {fd_insertions}; the recipe cannot back a passive Tier 2 reader"
        )
    elif not fd_clean:
        status = "STOP-recipe-not-clean"
        reason = f"ForceDisable recipe runs were not clean: {fd_failures}"

    return {
        "schema": "v2-spike-embedded.verdict/1",
        "status": status,
        "exit_code": EXIT_CODES[status],
        "stop_reason": reason,
        "positive_control": {
            "exact_three_runs": positive_exact,
            "all_valid": positive_valid,
            "inserted_exact_row_all_runs": positive_inserted,
            "verified": positive_ok,
        },
        "recipe": {
            "cell": "FD",
            "runs": len(fd),
            "all_valid": fd_valid,
            "insertions": fd_insertions,
            "clean": fd_clean,
            "failures": fd_failures,
        },
        "canary": {
            "expected_row": {"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL},
            "positive_rows_after": [record.get("rows_after") for record in pos],
            "force_disable_rows_after": [record.get("rows_after") for record in fd],
        },
        "embedded_macro": {
            "form": FORM_NAME,
            "event": "OnLoad",
            "body_proven_in_roundtrip": embedding_body_proven,
        },
        "hash_ok": hash_ok,
        "new_pids": new_pids,
        "integrity_errors": integrity_errors,
        "unverified_kills": unverified_kills,
        "notes": [
            "PASS requires the positive control verified (exact row on all 3 runs), the "
            "ForceDisable recipe clean on all 3 fresh copies, the startup-form trigger present "
            "before and after every run, unchanged canonical hashes, zero new MSACCESS PIDs, "
            "no lock residue after a graceful close, and no unverified kill.",
            "A missing/failed positive control makes every 'no insertion' result vacuous (STOP).",
            "Even one FD insertion rejects the recipe (STOP-recipe-not-clean); Tier 2 stops at "
            "the planning gate rather than weakening the contract.",
        ],
    }


def verdict_selftest() -> int:
    """Exercise the verdict machine with synthetic run records; return the case count."""

    def syn(cell: str, run: int, rows_after, **overrides) -> dict:
        trigger = {
            "startup_form_property": FORM_NAME,
            "startup_form_is_trigger": True,
            "form_document_present": True,
            "no_vba_modules": True,
            "no_named_macros": True,
            "forms_container": [FORM_NAME],
        }
        record = {
            "cell": cell,
            "run": run,
            "security_requested": MSO_LOW if cell == "POS" else MSO_FORCE_DISABLE,
            "security_readback": MSO_LOW if cell == "POS" else MSO_FORCE_DISABLE,
            "child_returncode": 0,
            "timed_out": False,
            "open_ok": True,
            "observer_started": True,
            "observer_error": None,
            "residual_owned_pid": False,
            "access_pid_in_baseline": False,
            "pre_locks_clear": True,
            "locks": [],
            "graceful_lock_residue": False,
            "unverified_kill": False,
            "rows_before_read_ok": True,
            "rows_before": [],
            "rows_after_read_ok": True,
            "rows_after": rows_after,
            "dialogs": [],
            "timeout_dialogs": [],
            "before_snapshot": dict(trigger),
            "after_snapshot": dict(trigger),
        }
        record.update(overrides)
        return record

    def pos(n: int, rows_after=None, **overrides):
        rows = [{"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}] if rows_after is None else rows_after
        return [syn("POS", index + 1, rows, **overrides) for index in range(n)]

    def fd(n: int, rows_after=None, **overrides):
        rows = [] if rows_after is None else rows_after
        return [syn("FD", index + 1, rows, **overrides) for index in range(n)]

    good_kwargs = {
        "build_ok": True,
        "embedding_body_proven": True,
        "overall_timeout_hit": False,
        "any_cell_timed_out": False,
        "timeout_dialog_blocked": False,
        "positive_dialog_observed": False,
        "integrity_errors": [],
        "hash_diff": {"unchanged": True},
        "new_pids": [],
        "infra_error": None,
    }

    cases = [
        ("three-positives-insert-three-fd-unchanged", pos(3) + fd(3), {}, "PASS"),
        (
            "one-positive-missing-row",
            pos(2) + [syn("POS", 3, [])] + fd(3),
            {},
            "STOP-inconclusive-positive-control",
        ),
        (
            "positive-extra-row-is-not-exact",
            pos(
                3,
                rows_after=[
                    {"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL},
                    {"ProbeID": 2, "Label": "UNEXPECTED"},
                ],
            )
            + fd(3),
            {},
            "STOP-inconclusive-positive-control",
        ),
        ("only-two-positive-runs", pos(2) + fd(3), {}, "STOP-inconclusive-positive-control"),
        (
            "one-fd-insertion-is-recipe-rejection",
            pos(3) + fd(2) + fd(1, rows_after=[{"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}]),
            {},
            "STOP-recipe-not-clean",
        ),
        (
            "fd-clean-but-hash-changed",
            pos(3) + fd(3),
            {"hash_diff": {"unchanged": False, "changed": ["db/northwind.accdb"]}},
            "STOP-integrity",
        ),
        ("foreign-new-msaccess-pid", pos(3) + fd(3), {"new_pids": [4242]}, "STOP-integrity"),
        (
            "positive-observer-error",
            pos(2) + [syn("POS", 3, [], observer_error="boom")] + fd(3),
            {},
            "STOP-inconclusive-positive-control",
        ),
        (
            "positive-open-failure",
            pos(2) + [syn("POS", 3, [], open_ok=False, child_returncode=4)] + fd(3),
            {},
            "STOP-inconclusive-positive-control",
        ),
        (
            "positive-security-readback-mismatch",
            pos(2) + [syn("POS", 3, [], security_readback=MSO_FORCE_DISABLE)] + fd(3),
            {},
            "STOP-inconclusive-positive-control",
        ),
        (
            "fd-residual-process-after-run",
            pos(3) + fd(2) + [syn("FD", 3, [], residual_owned_pid=True)],
            {},
            "STOP-recipe-not-clean",
        ),
        (
            "fd-startup-trigger-missing-after-run",
            pos(3)
            + fd(2)
            + [
                syn(
                    "FD",
                    3,
                    [],
                    after_snapshot={
                        "startup_form_property": None,
                        "startup_form_is_trigger": False,
                        "form_document_present": True,
                        "no_vba_modules": True,
                        "no_named_macros": True,
                    },
                )
            ],
            {},
            "STOP-recipe-not-clean",
        ),
        (
            "positive-lock-residue",
            pos(2)
            + [
                syn(
                    "POS",
                    3,
                    [{"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}],
                    locks=["armed.laccdb"],
                )
            ]
            + fd(3),
            {},
            "STOP-inconclusive-positive-control",
        ),
        (
            "graceful-close-left-lock-residue",
            pos(2)
            + [
                syn(
                    "POS",
                    3,
                    [{"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}],
                    graceful_lock_residue=True,
                )
            ]
            + fd(3),
            {},
            "STOP-inconclusive-positive-control",
        ),
        (
            "fd-graceful-close-left-lock-residue",
            pos(3) + fd(2) + [syn("FD", 3, [], graceful_lock_residue=True)],
            {},
            "STOP-recipe-not-clean",
        ),
        (
            "unverified-kill-is-an-integrity-failure",
            pos(3) + fd(2) + [syn("FD", 3, [], unverified_kill=True)],
            {},
            "STOP-integrity",
        ),
        (
            "unverified-kill-in-positive-control",
            pos(2) + [syn("POS", 3, [], unverified_kill=True)] + fd(3),
            {},
            "STOP-integrity",
        ),
        (
            "pre-existing-canary-row",
            pos(3) + fd(3),
            {"integrity_errors": ["run 1 pre-open DAO read was not empty"]},
            "STOP-integrity",
        ),
        (
            "pos-timeout-with-dialog",
            pos(2)
            + [
                syn(
                    "POS",
                    3,
                    [],
                    timed_out=True,
                    child_returncode=None,
                    timeout_dialogs=[{"class": "#32770", "title": "Append"}],
                )
            ]
            + fd(3),
            {"any_cell_timed_out": True, "timeout_dialog_blocked": True},
            "STOP-inconclusive-positive-control",
        ),
        (
            "pos-timeout-no-dialog",
            pos(2) + [syn("POS", 3, [], timed_out=True, child_returncode=None)] + fd(3),
            {"any_cell_timed_out": True},
            "STOP-execution-timeout",
        ),
        (
            "pos-dialog-observed-no-insertion",
            pos(2) + [syn("POS", 3, [], dialogs=[{"class": "#32770", "title": "Append"}])] + fd(3),
            {"positive_dialog_observed": True},
            "STOP-inconclusive-positive-control",
        ),
        (
            "pos-failure-with-unproven-embedding",
            pos(3, rows_after=[]) + fd(3),
            {"embedding_body_proven": False},
            "STOP-inconclusive-positive-control",
        ),
        ("build-not-ok", pos(3) + fd(3), {"build_ok": False}, "BLOCKED-build"),
        ("infra-error-wins", pos(3) + fd(3), {"infra_error": "boom"}, "INFRA-error"),
    ]

    results = []
    for label, runs, overrides, expected in cases:
        kwargs = dict(good_kwargs)
        kwargs.update(overrides)
        verdict = compute_verdicts(runs, **kwargs)
        status = verdict["status"]
        ok = status == expected
        results.append(
            {
                "case": label,
                "expected": expected,
                "observed": status,
                "exit_code": verdict["exit_code"],
                "ok": ok,
            }
        )
        if not ok:
            raise AssertionError(f"verdict selftest {label!r}: expected {expected}, observed {status}")
    return len(results)


# ---------------------------------------------------------------------------------------
# self check (no COM, no DAO, no Access)
# ---------------------------------------------------------------------------------------
def self_check() -> int:
    """Run the bounded offline preflight (compile, imports, ladders, verdicts)."""
    import os

    from harness_common import (  # noqa: F401 - import surface check (no COM side effects)
        reap_access,
        verified_kill_python,
        verify_access_identity,
    )

    from tests.helpers.dialog_watcher import (
        WindowInfo,
        collect_windows,
    )
    from tests.helpers.dialog_watcher import (
        creation_time as watcher_creation_time,
    )
    from tests.helpers.dialog_watcher import (
        process_image as watcher_process_image,
    )

    # 1. Compile every harness module from source, in memory: this proves syntax without
    #    writing bytecode (a __pycache__ write can be denied by an external file lock).
    compiled = []
    for name in HARNESS_MODULES:
        source = (SCRATCH / name).read_text(encoding="utf-8")
        compile(source, str(SCRATCH / name), "exec")
        compiled.append(name)

    # 2. Import checks (the modules must be importable without COM side effects).
    import build_fixture  # noqa: F401
    import cell  # noqa: F401
    import dao_read  # noqa: F401

    # 3. Watcher surface consumed non-live, so a field-name drift is caught pre-flight.
    sample = WindowInfo(hwnd=1, owner_pid=2, owner_image="x", class_name="#32770", title="t")
    assert sample.class_name == "#32770" and sample.title == "t"
    assert callable(collect_windows)
    self_pid = os.getpid()
    own_creation = watcher_creation_time(self_pid)
    own_image = watcher_process_image(self_pid)
    assert own_creation is not None and own_image.lower().endswith(".exe")
    observer = WindowObserver(set())
    observer.stop()
    assert observer.windows == [] and observer.error is None

    # 4. Fail-closed kill semantics (a kill is never issued without a positive proof).
    assert verify_access_identity(None, None)["owned"] is False
    assert verify_access_identity(self_pid, None)["owned"] is False
    assert verify_access_identity(self_pid, own_creation, {self_pid})["owned"] is False
    assert verify_access_identity(999_999_999, 123)["owned"] is False
    assert verify_access_identity(self_pid, own_creation)["owned"] is False, (
        "this process is not MSACCESS.EXE"
    )
    python_kill = verified_kill_python(self_pid, None)
    assert python_kill["result"] == "skipped-unverified-no-kill", python_kill
    assert verified_kill_python(self_pid, own_creation)["result"] == "skipped-unverified-no-kill", (
        "the harness must never kill its own process"
    )
    assert verified_kill_python(self_pid, own_creation - 1)["result"] == (
        "skipped-unverified-no-kill"
    ), "a creation-time mismatch must never authorize a kill"
    assert reap_access(None, None, None)["terminated"] is False
    assert reap_access(self_pid, own_creation, "MSACCESS.EXE")["terminated"] is False
    assert baseline_pids() == baseline_pids()

    # 5. Form-text dialect ladder (pure string work, no Access).
    marker_report = {
        candidate_id: form_text.candidate_markers(
            candidate_id, form_text.SYNTHETIC_BASE_FORM_TEXT
        )
        for candidate_id in form_text.CANDIDATE_IDS
    }
    for candidate_id, markers in marker_report.items():
        assert markers["stale_checksum_removed"], (candidate_id, markers)
        assert markers["placeholder_present_once"], (candidate_id, markers)
        assert markers["macro_framing_present"], (candidate_id, markers)
        assert markers["body_markers_present"], (candidate_id, markers)
        assert markers["no_form_removal"], (candidate_id, markers)
        assert markers["insert_index_in_property_region"], (candidate_id, markers)
    assert "Checksum =" in form_text.SYNTHETIC_BASE_FORM_TEXT
    assert not form_text.candidate_by_id("E0")["body"]
    assert form_text.candidate_by_id("E1")["body"]
    # The bar and the selection policy are exercised synthetically as well.
    good = {
        "candidate": "E1",
        "expects_body": True,
        "load_ok": True,
        "readback_matches_placeholder": True,
        "roundtrip_placeholder_found": True,
        "roundtrip_body_markers_found": True,
    }
    weak = dict(good, candidate="E2", roundtrip_body_markers_found=False)
    placeholder_only = dict(
        good,
        candidate="E0",
        expects_body=False,
        roundtrip_body_markers_found=False,
    )
    assert form_text.attempt_meets_bar(good) and form_text.attempt_meets_bar(weak)
    assert form_text.select_body_attempt([placeholder_only]) is None
    assert form_text.select_body_attempt([placeholder_only, weak, good])["candidate"] == "E1"
    assert form_text.select_body_attempt([dict(weak, readback_matches_placeholder=False)]) is None

    # 6. Static safety scan: no image-name kill anywhere in the harness.
    for name in SAFETY_SCAN_MODULES:
        source = (SCRATCH / name).read_text(encoding="utf-8")
        for token in FORBIDDEN_TOKENS:
            assert token not in source, f"forbidden token {token!r} in {name}"

    # 7. Synthetic verdict matrix.
    case_count = verdict_selftest()

    # 8. Canonical protection is reachable before any live run.
    hashes = canonical_hashes()
    assert hashes, "no canonical files hashed"

    print(
        json.dumps(
            {
                "canonical_files_hashed": len(hashes),
                "scratch": str(SCRATCH).replace("\\", "/"),
                "compiled_modules": compiled,
                "fixture_dir_exists": FIXTURE_DIR.exists(),
                "watcher_helpers_ok": True,
                "window_observer_ok": True,
                "fail_closed_kill_ok": True,
                "form_text_candidates": list(form_text.CANDIDATE_IDS),
                "form_text_markers": marker_report,
                "verdict_selftest_cases": case_count,
                "matrix_cells": [cell_spec["id"] for cell_spec in CELLS],
                "exit_codes": EXIT_CODES,
                "checksum_probe": sha256_text("self-check")[:12],
            },
            indent=2,
            default=str,
        )
    )
    return 0


# ---------------------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------------------
def main() -> int:
    """Dispatch --self-check, --build-only, or the full build + matrix."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--all", action="store_true", help="run the build + 6-cell matrix")
    parser.add_argument("--build-only", action="store_true", help="bounded fixture build only")
    parser.add_argument("--self-check", action="store_true", help="bounded structural check; no COM")
    parser.add_argument("--overall-timeout", type=float, default=1800.0)
    args = parser.parse_args()

    if args.self_check:
        return self_check()
    if args.build_only:
        EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
        result = build_fixture()
        print(json.dumps({"build_ok": result["ok"], "returncode": result["returncode"],
                          "error": result.get("error")}, indent=2))
        return EXIT_CODES["PASS"] if result["ok"] else EXIT_CODES["BLOCKED-build"]
    if not args.all:
        parser.print_help()
        return 1

    started = time.monotonic()
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    COPY_ROOT.mkdir(parents=True, exist_ok=True)
    baseline_set = set(baseline_pids())
    baseline_list = sorted(baseline_set)
    hashes_before = canonical_hashes()
    write_json_flushed(EVIDENCE_DIR / "hashes_before.json", hashes_before)
    write_json_flushed(EVIDENCE_DIR / "baseline_msaccess_pids.json", baseline_list)

    runs: list[dict] = []
    build: dict = {"ok": False, "error": "not-attempted"}
    overall_timeout_hit = False
    any_cell_timed_out = False
    infra_error: str | None = None
    hashes_after = hashes_before
    new_pids: list[int] = []

    try:
        build = build_fixture()
        if build.get("ok"):
            for cell_spec in CELLS:
                stop_matrix = False
                for run_index in range(1, cell_spec["runs"] + 1):
                    if time.monotonic() - started > args.overall_timeout:
                        overall_timeout_hit = True
                        stop_matrix = True
                        break
                    record = run_one(cell_spec, run_index, baseline_set)
                    runs.append(record)
                    if record["timed_out"]:
                        # Never run further cells after a timeout.
                        any_cell_timed_out = True
                        stop_matrix = True
                        break
                if stop_matrix:
                    break
                if cell_spec["id"] == "POS":
                    pos_runs = [record for record in runs if record["cell"] == "POS"]
                    positive_ok = len(pos_runs) == 3 and all(
                        run_is_valid(record) and rows_match_expected(record.get("rows_after"))
                        for record in pos_runs
                    )
                    if not positive_ok:
                        # No positive control -> every FD result would be vacuous. Stop.
                        break
    except Exception as exc:  # noqa: BLE001 - still attempt scoped cleanup + summary
        infra_error = repr(exc)

    survivors: list[dict] = []
    try:
        for record in runs:
            identity = record.get("identity") or {}
            pid = identity.get("access_pid")
            if pid and process_is_alive(pid):
                survivors.append(
                    {
                        "pid": pid,
                        "cell": record.get("cell"),
                        "run": record.get("run"),
                        "identity": identity,
                    }
                )
        for survivor in survivors:
            identity = survivor.get("identity") or {}
            survivor["cleanup"] = reap_access(
                identity.get("access_pid"),
                identity.get("access_creation"),
                identity.get("access_image"),
                baseline_set,
            )
            wait_until(
                lambda pid=survivor["pid"]: not process_is_alive(pid), 10.0
            )
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"orphan sweep failed: {exc!r}"

    try:
        hashes_after = canonical_hashes()
        hash_diff = diff_hashes(hashes_before, hashes_after)
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"post-hash failed: {exc!r}"
        hash_diff = {"unchanged": False, "changed": [], "added": [], "removed": []}

    try:
        final_pids = sorted(baseline_pids())
        new_pids = sorted(set(final_pids) - baseline_set)
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"final pid scan failed: {exc!r}"
        final_pids, new_pids = [], []

    integrity_errors: list[str] = []
    for record in runs:
        if record.get("rows_before_read_ok") and record.get("rows_before"):
            integrity_errors.append(
                f"{record['cell']} run {record['run']}: fresh copy had pre-existing canary rows "
                f"{record.get('rows_before')}"
            )
        if record.get("rows_before_read_ok") is not True and not record.get("timed_out"):
            integrity_errors.append(
                f"{record['cell']} run {record['run']}: pre-open DAO read failed "
                f"({record.get('rows_before_error')})"
            )
        if record.get("pre_locks_clear") is False:
            integrity_errors.append(
                f"{record['cell']} run {record['run']}: pre-open lock residue {record.get('pre_locks')}"
            )
        if record.get("graceful_lock_residue"):
            integrity_errors.append(
                f"{record['cell']} run {record['run']}: lock residue after a graceful close "
                f"{record.get('locks')}"
            )
        before = record.get("before_snapshot") or {}
        if record.get("rows_before_read_ok") and before.get("startup_form_is_trigger") is not True:
            integrity_errors.append(
                f"{record['cell']} run {record['run']}: fresh copy trigger missing "
                f"(StartupForm={before.get('startup_form_property')!r})"
            )

    timeout_dialog_blocked = any(
        record.get("timed_out") and (record.get("timeout_dialogs") or record.get("dialogs"))
        for record in runs
        if record.get("cell") == "POS"
    )
    positive_dialog_observed = any(
        record.get("dialogs") or record.get("timeout_dialogs")
        for record in runs
        if record.get("cell") == "POS"
    )

    build_report = (build or {}).get("report") or {}
    embedding = (build_report.get("embedded_event_macro") or {}) if isinstance(build_report, dict) else {}
    embedding_body_proven = bool(embedding.get("body_markers_visible_in_roundtrip"))

    try:
        verdicts = compute_verdicts(
            [record for record in runs if record.get("cell")],
            build_ok=bool(build.get("ok")),
            embedding_body_proven=embedding_body_proven,
            overall_timeout_hit=overall_timeout_hit,
            any_cell_timed_out=any_cell_timed_out,
            timeout_dialog_blocked=timeout_dialog_blocked,
            positive_dialog_observed=positive_dialog_observed,
            integrity_errors=integrity_errors,
            hash_diff=hash_diff,
            new_pids=new_pids,
            infra_error=infra_error,
        )
    except Exception as exc:  # noqa: BLE001
        infra_error = infra_error or f"verdict computation failed: {exc!r}"
        verdicts = {
            "status": "INFRA-error",
            "exit_code": EXIT_CODES["INFRA-error"],
            "stop_reason": f"verdict computation failed: {exc!r}",
            "recipe": {"runs": 0, "all_valid": False, "insertions": [], "clean": False},
            "positive_control": {"verified": False},
            "hash_ok": False,
        }

    summary = {
        "schema": "v2-spike-embedded.summary/1",
        "build": build,
        "baseline_msaccess_pids": baseline_list,
        "runs": runs,
        "verdicts": verdicts,
        "status": verdicts["status"],
        "integrity_errors": integrity_errors,
        "timeout_dialog_blocked": timeout_dialog_blocked,
        "positive_dialog_observed": positive_dialog_observed,
        "orphan_sweep": {
            "survivors": survivors,
            "final_msaccess_pids": final_pids,
            "new_msaccess_pids": new_pids,
        },
        "hash_protection": {"before": hashes_before, "after": hashes_after, "diff": hash_diff},
        "overall_timeout_hit": overall_timeout_hit,
        "any_cell_timed_out": any_cell_timed_out,
        "infra_error": infra_error,
        "elapsed_seconds": round(time.monotonic() - started, 1),
    }
    try:
        write_json_flushed(EVIDENCE_DIR / "summary.json", summary)
    except Exception:  # noqa: BLE001 - a summary write must never hide the exit code
        pass

    print(
        json.dumps(
            {
                "status": verdicts["status"],
                "exit_code": verdicts["exit_code"],
                "stop_reason": verdicts.get("stop_reason"),
                "positive_verified": verdicts["positive_control"]["verified"],
                "fd_clean": verdicts["recipe"]["clean"],
                "fd_insertions": verdicts["recipe"]["insertions"],
                "embedded_body_proven": embedding_body_proven,
                "hash_ok": verdicts["hash_ok"],
                "new_msaccess_pids": new_pids,
            },
            indent=2,
            default=str,
        )
    )
    return verdicts["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
