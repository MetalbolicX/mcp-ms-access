# T5 embedded form-event-macro canary spike — scratch harness (throwaway)

Scope: **experiment only**, authorized as task **T5** (Specs S2/S5) of
`odd/tasks/documentation-workflows-v2.md`. No production code, no canonical-fixture edit,
no commit, no push, no Trust Center / registry / trusted-location / Access-option change.
The parent removes this whole scratch root (`db/fixtures/e2e-v2-embedded-20261017-6278b311/`)
after independent verification and archiving.

## What this decides

The two accepted startup spikes proved that a `RunCode` (VBA) `AutoExec`, a startup-form
`OnLoad` **expression** calling VBA, and a **non-VBA `AutoExec` OpenQuery** all stay silent
when a copy is opened under `AutomationSecurity = 3` (force-disable; L7/L9). Both left the
same gap open explicitly: *a pure macro action carried by an **embedded event macro on a
form*** was never measured. A macro engine could execute embedded event macros while VBA
and `AutoExec` are blocked.

This spike answers exactly that. A fresh DAO-built copy carries:

| Element | Value |
| --- | --- |
| Canary table | `CanaryRows([ProbeID] LONG PK NOT NULL, [Label] TEXT(64))`, **zero rows** |
| Saved query | `qryAppendCanary` = `INSERT INTO CanaryRows ([ProbeID], [Label]) VALUES (1, 'EMBEDDED_MACRO')` |
| Form | `frmCanary` with one text-box control `txtProbe` |
| Event | `OnLoad` = `"[Embedded Macro]"`, whose embedded macro's sole action is `OpenQuery("qryAppendCanary")` |
| Startup trigger | database property `StartupForm = "frmCanary"`, set **last** |
| Deliberately absent | VBA module (asserted: `Modules` container empty **and** `CurrentProject.AllModules.Count == 0`), `AutoExec`, `AutoKeys`, `RunCode`, `SetWarnings`, expression/VBA event handlers |

The row is observed with an **independent DAO read** before the armed open and again after
Access is closed and reaped — never by a VBA callback and never by the child that hosted
Access.

- **Suppressed under force-disable on all three fresh copies** (canary row set stays `[]`)
  → embedded form-event macro actions do not execute under force-disable at fixture scope;
  the Tier 2 planning gate may continue.
- **Inserted in any force-disable copy** → the recipe is rejected; stop the Tier 2 planning
  gate rather than weakening the contract (L8 rule).
- **Positive control not firing** → every "no insertion" result is vacuous; the result is
  inconclusive, never a pass.

## Exact commands

Live matrix (launch via the parent's background runner — minutes, never foreground):

```powershell
.venv\Scripts\python.exe db\fixtures\e2e-v2-embedded-20261017-6278b311\run_spike.py --all
```

Bounded preflight — no Access, no COM, no DAO (~2 s):

```powershell
.venv\Scripts\python.exe db\fixtures\e2e-v2-embedded-20261017-6278b311\run_spike.py --self-check
```

Optional bounded build-only gate (still launches Access, but stops before the matrix) to see
a `BUILD_BLOCKER` without spending matrix time:

```powershell
.venv\Scripts\python.exe db\fixtures\e2e-v2-embedded-20261017-6278b311\run_spike.py --build-only
```

`--all` refuses to run if `fixture/` already exists (it never overwrites a fixture) and
never deletes evidence.

## How the embedded macro is built (the hard part)

Access exposes **no** documented object-model call that creates an embedded event macro, so
the builder uses the sanctioned route and records every outcome:

1. The form and its control are created with the proven T4 idiom
   (`CreateForm` → `CreateControl` → `Close(acSaveYes)` → `DoCmd.Rename`).
2. Access' **own** `SaveAsText` export becomes the base text
   (`fixture/form_base_access.txt`) — no hand-written form dialect is ever invented.
3. `form_text.py` strips the now-stale `Checksum` line and inserts one bounded candidate
   framing into the form-property region (before the first nested `Begin`). Five candidates
   are attempted, in order, each written as **UTF-16-LE with BOM** (the encoding
   `backends/access/vba.py` documents for form import) and each imported into a freshly
   deleted object:
   * `E0` — placeholder property only (diagnostic: does the literal round-trip at all?);
   * `E1` — placeholder + `Begin Embedded Macro` … `End` block;
   * `E2` — placeholder + `EmbeddedMacro = Begin` … `End`;
   * `E3` — placeholder + `Begin Macro` … `End`;
   * `E4` — placeholder + bare `Begin` … `End` form-level block.
   Each carries the named-macro framing captured live 2026-10-10
   (`Version =196611` / `ColumnsShown =0` / `Begin` / `Action ="OpenQuery"` /
   `Argument ="qryAppendCanary"` / `End`, CRLF only), re-indented one level.
4. Every attempt records: exact COM error (`describe_com_error`, including `excepinfo` and
   `scode`), design-view readback of `Forms("frmCanary").OnLoad`, Access' re-export
   (`SaveAsText` → `roundtrip_<id>.txt`), its hash, whether the placeholder survived, and
   whether the body markers (`OpenQuery`, `qryAppendCanary`) are visible in the re-export.
5. Selection policy: only a **body-bearing** candidate that (a) imports, (b) still reads
   back as `"[Embedded Macro]"` in design view, and (c) still shows the placeholder in
   Access' re-export is installed. If no candidate meets that bar the build stops with
   **`BUILD_BLOCKER`** and keeps all ladder evidence. There is **no** fallback to VBA or an
   expression event — that would make the suppression test vacuous.

Honesty about body survival: if a body-bearing candidate meets the bar but the macro body
is *not* visible in Access' own re-export, the build records
`body_markers_visible_in_roundtrip: false`, `selection_reason` says so explicitly, and the
low-security positive control becomes the behavioural gate for body survival. A positive
control that then fails is reported as `STOP-inconclusive-positive-control` (exit `10`) with
a reason naming the unproven body — never as a suppression result.

### Build-order discipline (never executes startup code)

1. DAO-only creation of `armed.accdb`, the empty canary table, and the saved append query.
2. `Access.Application` (fresh `DispatchEx`, identity proven fail-closed, security
   set-and-read-back asserted) opens the database while it has **no** auto-run object:
   `AllMacros` empty, `AllForms`/`AllModules` zero, no `StartupForm` property.
3. Form + control are created, Access' own text is captured, the ladder runs, and the
   selected candidate is installed. `Modules` and `Scripts` containers must both still be
   empty and `StartupForm` must still be absent.
4. Database closed, Access quit and reaped, then **`StartupForm` is set through DAO** as the
   very last mutation. The armed fixture is **never** reopened through `Access.Application`
   during the build; the post-build proof is engine-level DAO only.

## Matrix (N = 3 each, positive control first)

| Cell | `AutomationSecurity` | Copy | Expected observation |
| --- | --- | --- | --- |
| `POS` | 1 (low) | fresh copy | after the run the DAO canary read must be exactly `[{ProbeID:1, Label:'EMBEDDED_MACRO'}]`, on every run |
| `FD` | 3 (force-disable) | fresh copy | after the run the DAO canary read must stay `[]` |

Per run the runner performs, in order: (1) copy `armed.accdb` into
`scratch/<CELL>-run<n>/`; (2) **independent DAO read #1**, which must be `[]` and must show
the trigger (`StartupForm = frmCanary`, form document present, no VBA modules, no named
macros); (3) fail-closed lock check; (4) run the cell child (fresh `DispatchEx`, identity
proven and flushed before the armed open, security readback gate, read-only window observer,
`Access.Version` recorded); (5) parent-side grace-then-identity-verified kill if needed;
(6) **independent DAO read #2** after Access is reaped (asserting the trigger is still
present, so "the trigger vanished" can never masquerade as suppression). The row set is
never read by the child that hosted Access.

If the positive control does not insert the exact row, the matrix stops there and no `FD`
cell runs — "no insertion" can never be reported without a non-vacuous control.

## Verdict gates (non-vacuous)

`PASS` (exit `0`) requires **all** of:

1. build ok, `StartupForm` armed through DAO, engine-level post-build proof clean;
2. `POS` inserts exactly `[(1, 'EMBEDDED_MACRO')]` **3/3**, every run valid;
3. `FD` rows stay `[]` **3/3**, trigger still present after each run;
4. canonical hashes (`db/fixtures/documentation/**`, `db/northwind.accdb`) unchanged;
5. zero owned Access survivors / zero new `MSACCESS.EXE` PIDs;
6. no lock residue after a graceful close (graceful close is the expectation);
7. no kill issued without a positive identity proof, and no cell timeout.

## Exit codes

| Exit | Status | Meaning |
| --- | --- | --- |
| 0 | `PASS` | force-disable suppressed the embedded event macro, gates above all true |
| 10 | `STOP-inconclusive-positive-control` | control did not insert (or a modal dialog blocked it, or the embedding body was unproven) — never a pass |
| 11 | `STOP-recipe-not-clean` | an `FD` run inserted the row or a recipe run was invalid/residual → recipe rejected, Tier 2 planning gate |
| 12 | `STOP-execution-timeout` | a cell timed out with no dialog evidence; matrix stopped, no retry |
| 13 | `STOP-integrity` | hash changed, foreign `MSACCESS.EXE`, lock residue, unverified kill, missing trigger, unreadable DAO readback, pre-existing canary rows |
| 20 | `BLOCKED-build` | fixture or embedded-macro build failed (`BUILD_BLOCKER` in `evidence/build_stderr.txt`) |
| 21 | `BLOCKED-overall-timeout` | overall matrix budget hit; stopped without retry |
| 30 | `INFRA-error` | unexpected harness error (summary still written) |

Child exit codes (recorded per run): `0` ok; `3` security readback mismatch (no open);
`4` open failed; `5` fatal; `6` Access identity could not be verified (no open).
DAO observer: `0` ran (`ok` field is the truth), `3` DAO raised, `5` fatal.
Build: `0` ok; `2` `BUILD_BLOCKER`.

## Safety envelope (unchanged boundaries, T2/T3/T4 discipline)

- Fresh **`DispatchEx`** Access instances only. Existing `MSACCESS.EXE` PIDs are baselined,
  recorded, protected, and never killed.
- Ownership is **fail-closed**: an armed open requires a PID absent from the baseline, a
  non-null captured creation time, a live matching creation time, and the `MSACCESS.EXE`
  image. Access reaping uses the **production** verifier
  `ms_access_mcp.application.process_identity.terminate_verified_access` (the same fail-closed
  path T2 delivered and T4 used); harness-owned Python children are reaped through a
  creation-verified PID-scoped helper that additionally refuses to kill the harness' own
  process. No process-name-wide kill and no baseline-diff kill anywhere (proved by a static
  scan in `--self-check`).
- If the pre-open DAO read fails, the trigger is missing, or a lock file remains on the
  copy, the armed copy is **not** opened.
- The child starts a read-only window observer (`tests/helpers/dialog_watcher.py`) before
  the armed open and flushes observed windows every ~2 s, so a hard kill still leaves the
  dialog evidence on disk; the parent samples owned windows before any hard kill. **No
  synthetic keyboard/UI input, no dialog acceptance, no mode/setting change.**
- Per-cell child hard timeout 120 s; the parent owns the kill and the orphan sweep. A
  timeout stops the matrix (no retry).
- Canonical files are sha256-hashed before and after; all copies, form texts and evidence
  live under this scratch root on `D:` (never `%TEMP%` on `C:`) and are never deleted by the
  harness.
- `Application.Version` is recorded as a string; no bitness/provider claim is made that was
  not read back.

## Evidence

```
evidence/
  hashes_before.json, baseline_msaccess_pids.json
  build_result.json, build_stdout.txt, build_stderr.txt
  form_dialect/                     <- T7 parsing reference (unarmed captures)
      form_base_access.txt          <- Access' own SaveAsText of the form before embedding
      form_final_installed.txt      <- the installed candidate text
      embedding_attempts/candidate_<E0..E4>.txt, roundtrip_<E0..E4>.txt
      build_report.json
  summary.json                      <- verdicts, per-cell row sets, orphan sweep, hash diff
scratch/POS-run1..3/, scratch/FD-run1..3/   <- one disposable copy per run
      armed.accdb, identity.json, result.json, run_record.json,
      rows_before.json, rows_after.json, dao_before_*.txt, dao_after_*.txt,
      stdout.txt, stderr.txt
fixture/
      armed.accdb, form_base_access.txt, form_final_installed.txt,
      embedding_attempts/…, build_identity.json, build_report.json
```

Every `run_record.json` preserves the candidate set at every stage: identity capture and
verification, security readback, `Access.Version`, open result, all observed windows,
pre/post lock state, the full DAO row set and row count before/after, rows inserted by the
candidate, rows that are not the expected tuple, the startup-trigger evidence before and
after, the parent's reap record (`graceful` / `forced-after-grace` / `hard-timeout` /
`not-dispatched`), and the exact child return code. The evidence archives no databases.

## Known limitations before the live run

- `--self-check` is deliberately COM-free: the DAO reader, the form build and both Access
  phases are unexercised until the parent launches `--all`. The verdict arithmetic (24
  synthetic cases), fail-closed kill semantics, watcher surface, form-text ladder markers,
  exit codes and the forbidden-token scan are all covered offline.
- The embedded-macro **form-text dialect is unproven** until the live build runs. If no
  candidate imports and round-trips, the build exits `20` with the complete ladder evidence
  in `fixture/embedding_attempts/` and `fixture/build_report.json` — that is a legitimate T5
  outcome, and the honest one, rather than substituting a different vector.
- A **named-macro event reference** (`OnLoad = "mcrX"`) is expressible programmatically and
  would answer a related but *different* question. It is deliberately **not** implemented
  here: T5 asks about the embedded event macro, and swapping vectors silently would make the
  result look like coverage it is not. If the parent wants that vector, it is a separate,
  separately-labelled experiment.
- "No dialogs observed" means the observer sampled no dialog-class windows, not that every
  possible dialog is observable. Absence of action-query dialogs is a host observation, not
  a portable contract.
- This is fixture-scope behaviour on the measured runtime. It is **not** universal macro
  suppression, `AutoKeys` (keyboard-triggered) coverage, table data-macro coverage, or a
  claim about other Access versions/settings, and it does not qualify the production reader.
