# T4 content-read harness (scratch, not production)

ODD `documentation-workflows-v2`, task **T4** (Specs S2, S5) — **preparation only**. This
directory is throwaway research tooling under the D: repo scratch convention
(`db/fixtures/e2e-v2-content-20261017-6bd7ed97/`). It edits no production file, imports the
production modules through `sys.path` only, and never removes its own scratch root. The
parent owns the live launch in the background; this harness does not self-launch the matrix
and never enlarges its own timeouts.

## Exact command (launch via the parent's background runner — takes minutes, do not run foreground)

```bash
cd /d/code/python/mcp-ms-access && .venv/Scripts/python.exe db/fixtures/e2e-v2-content-20261017-6bd7ed97/run_content.py --all
```

Bounded preflight already run by the harness author (no COM, no DAO, no Access, <2 s):

```bash
cd /d/code/python/mcp-ms-access && .venv/Scripts/python.exe db/fixtures/e2e-v2-content-20261017-6bd7ed97/run_content.py --self-check
```

`--all` runs the self-check first and aborts with exit `2` if it fails. The builder refuses
to overwrite an existing fixture, and the runner never deletes evidence.

## What it answers

### 1. REFERENCES — corrected 1-based enumeration (cell `references`, ×3)

Production precedent `src/ms_access_mcp/backends/access/vba.py:50-61` enumerates
`VBProjects` **1-based**; the earlier spike's `References` probe failed with COM scode
`0x800A01C4` because Count and Item shared one exception boundary. This cell records:

* `collection_ok` — whether `Application.References` resolves, in its own boundary;
* `count` / `count_error` — `References.Count` alone, in its own boundary;
* `items[]` — for `i in range(1, count + 1)`, each `References(i)` in its **own** boundary,
  recording the full `excepinfo` (scode/description/source) on failure. Count and Item
  diagnostics are never conflated.

### 2. SAVEASREAD — SaveAsText form 2 / report 3 / macro 4 (cell `saveasread`, ×3)

Under `AutomationSecurity=3`, `SaveAsText` exports the fixture form (2), report (3) and
macro (4) into the cell's evidence directory. Each export is decoded UTF-16-LE-BOM (the
same decode as `backends/access/vba.py:66-80`) and hashed; the byte size, BOM presence,
char count, hash and a bounded snippet are recorded. Non-vacuity requires that the objects
provably exist (DAO Containers, see STARTUPPROPS) **and** that at least one positive read
succeeds somewhere. If every force-disable export fails, **one** low-security (`1`)
`POSCTRL` cell distinguishes "blocked by ForceDisable" from a harness defect.

### 3. TRUSTREFUSAL — VBProject trust refusal degrades, never crashes (cell `trustrefusal`, ×3)

`CurrentProject`, `VBE`, `VBE.VBProjects.Count` and each `VBProjects(i)` are probed in their
own boundaries. `trust_enabled_observed` is a boolean derived from whether the VBProject
reads succeed, so the host's actual either-way outcome is recorded honestly.
`outcome_kind` is `observed` or `unavailable-degraded`. **Nothing is toggled** — no Trust
Center, registry, or trusted-location change; the harness never synthesizes input.

### 4. STARTUPPROPS — DAO Properties + Containers (same copies, engine-level)

A DAO-only probe (`dao_probe.py`, `DBEngine.120`, read-only open) reads the full database
`Properties` list and the `Tables`/`Queries`/`Forms`/`Reports`/`Scripts`/`Modules` container
inventory (document names and dates, each field individually guarded). It runs on the
template and on every cell copy **before** the Access open, so it both answers the Tier-1
data point and supplies the SAVEASREAD non-vacuity evidence.

## Fixture recipe (reads-only; nothing auto-runs)

| Element | Value |
| --- | --- |
| Table | `ContentNotes([NoteID] LONG PK NOT NULL, [Note] TEXT(50))`, one row |
| Module | `ContentModule` with one trivial `ContentProbe()` function (never executed) |
| Form | `frmContent` with one text-box control `txtProbe` (`AcControlType` 109, detail section) |
| Report | `rptContent` (plain) |
| Macro | `mcrContent`, one `OpenForm("frmContent")` action (loaded as `NeutralMacro`, captured, then renamed) |
| Deliberately absent | `AutoExec`, `AutoKeys`, `StartupForm`, `RunCode`, `OnLoad` |

Build-order discipline mirrors `scripts/generate_documentation_fixtures.py` and both prior
spikes: DAO does all DDL first; `Access.Application` opens only while no auto-run object
exists; the module first, then the form/control, then the report, then the macro under the
neutral name; the neutral macro's real `SaveAsText` text is captured and asserted
(`OpenForm` + `frmContent` present; `RunCode`/`Function`/`OnLoad`/`StartupForm`/`VBE`
absent) **before** the rename to `mcrContent`; the database is closed and quit and never
reopened.

## Build/run discipline (identity + security)

Fresh `DispatchEx`; fail-closed PID + creation + image ownership proof before any open;
`Visible=False`/`UserControl=False`; `AutomationSecurity` set **and read back** before
`OpenCurrentDatabase` (mismatch aborts); a read-only window observer starts before the open
and records (never dismisses) owned windows; graceful `CloseCurrentDatabase` + `Quit`. The
runner owns the hard timeout and the PID-scoped reap.

## Safety envelope

* every kill is PID/creation-scoped: harness Python children through `verified_kill_python`
  (`taskkill /F /PID` only), owned Access through the production
  `terminate_verified_access`; `/IM` is never used;
* a pre-existing (baseline) `MSACCESS.EXE` is never killed; a survivor is reaped only when
  its PID equals the identity the child announced;
* `db/fixtures/documentation` and `db/northwind.accdb` are sha256-hashed before and after
  and are never opened by Access; only per-cell disposable copies are opened;
* no Trust Center / registry / trusted-location change, no synthetic input, no dialog
  acceptance;
* the `.laccdb` presence beside each copy is recorded at every stage and **never deleted**;
* the matrix is one bounded pass: no auto-retry, and the first timeout stops it.

## Verdict gates (non-vacuous, fail-closed)

`PASS` requires all of: references outcomes recorded with **separated** Count/Item
diagnostics; SaveAsText outcomes recorded (whatever they are) with the fixture objects
proven present and **at least one positive read somewhere**; the trust path recorded with
its boolean and no settings change; originals unchanged; zero owned survivors; no lock
residue after graceful close; no unverified kill. A SaveAsText failure under force-disable
with a succeeding low-security positive control is a PASS with a recorded limitation
("attributable to ForceDisable"); a failure under **both** is `INCONCLUSIVE` (harness
defect), never a pass.

## Exit codes

| Code | Meaning |
| --- | --- |
| `0` | `PASS` (possibly with recorded limitations) |
| `2` | harness/build error before or instead of the matrix (includes self-check failure) |
| `3` | a content cell gate failed (crash, missing diagnostics, lock residue, survivor) |
| `4` | safety violation (canonical hash changed, new foreign `MSACCESS.EXE`, unverified kill) |
| `5` | a cell exceeded the harness-level cell budget: the matrix stopped there, no retry |
| `6` | inconclusive: the SaveAsText cell is vacuous (no positive read anywhere) |

Child (`content_worker.py`) exit codes: `0` cell completed | `10` bad args | `11`
scratch-path refusal | `12` identity unverified | `13` open failed | `14` fatal |
`15` security readback mismatch.

## Cell list (one disposable copy each)

| Cell | N | Security | Purpose |
| --- | --- | --- | --- |
| `references-run1..3` | 3 | 3 | corrected 1-based References with separated diagnostics |
| `trustrefusal-run1..3` | 3 | 3 | VBProject trust refusal → recorded `unavailable`, no settings change |
| `saveasread-run1..3` | 3 | 3 | SaveAsText form/report/macro, BOM decode + hash |
| `posctrl-run1` | 0 or 1 | 1 | conditional positive control, only if every force-disable export failed |

STARTUPPROPS (DAO Properties + Containers) runs once on the template and once per cell copy.

## Evidence layout

```
evidence/
  self_check.json, baseline_msaccess_pids.json
  hashes_before.json, hashes_after.json
  build_result.json, build_stdout.txt, build_stderr.txt
  template/dao_probe.json, template/dao_probe_result.json
  cells/<cell>/
      dao_probe.json, dao_probe_result.json      <- Tier-1 inventory, run BEFORE the open
      identity.json, child_identity.json         <- flushed before any open
      result.json                                <- incremental per-cell state
      export_form.txt|export_report.txt|export_macro.txt   <- SaveAsText exports
      run_record.json                            <- full gate + exact stdout/stderr + reaps
  v2_content_report.json, summary.json
scratch/
  template/content.accdb           <- the built fixture (never overwritten)
  <cell>-run<n>/content.accdb      <- one unique disposable copy per cell run
```

## `--self-check` coverage (no COM)

Compiles all five modules, imports the three non-runner modules, asserts the cell/export
vocabulary, cross-checks the object-kind ids (`form` 2 / `report` 3 against
`backends/access/object_kinds.py`; `macro` 4 / `module` 5 against
`scripts/generate_documentation_fixtures.py` and `backends/access/macros.py`), asserts the
production `terminate_verified_access` seam, runs static safety scans (`/IM`, Trust Center
mutation, synthetic input, dialog acceptance), unit-checks `decode_utf16_bom` and
`describe_com_error`, checks the per-kind cell gates synthetically, verifies each of the
seven synthetic verdict mutations changes the outcome, and runs a bounded child exit-code
probe. 31 checks total.

## Known limitations and risks (to confirm on the live run)

* The Access build phase (`CreateForm`/`CreateControl`/`CreateReport` under force-disable)
  and every live cell are **unexercised** until the parent launches `--all`; the self-check
  is deliberately COM-free. A blocked step is reported as a concrete build/cell blocker,
  never improvised around.
* The `.venv/Scripts/python.exe` is a uv shim that spawns the real interpreter as a child;
  the worker records its **own** pid+creation to `child_identity.json`, which the runner
  uses for a fail-closed kill on timeout.
* DAO Container dates are recorded best-effort; a single unreadable property or document is
  recorded, not fatal.
* **Recorded production discrepancy (not fixed here):** `backends/access/vba.py`'s
  `SaveAsText`/`LoadFromText` docstrings carry `acReport=4`/`acMacro=8`, and
  `backends/versioning.py` hard-codes `_AC_REPORT = 4` / `_AC_MACRO = 8`. The live-verified
  `AcObjectType` values are form 2, report 3, macro 4 (per `object_kinds.py`,
  `macros.py` and the fixture generator). This harness uses 2/3/4 and records the
  discrepancy in `self_check.json` for the parent's review.

## Files

| File | Role |
| --- | --- |
| `run_content.py` | bounded runner: `--self-check` / `--all`, cell orchestration, pure verdict function |
| `t4_common.py` | constants, hashing, process/kill helpers, COM error formatting, read-only window observer |
| `build_fixture.py` | DAO + controlled Access build of the reads-only fixture |
| `dao_probe.py` | DAO-only Properties + Containers probe (`STARTUPPROPS` and non-vacuity evidence) |
| `content_worker.py` | the per-cell Access child (`REFERENCES`/`SAVEASREAD`/`TRUSTREFUSAL`/`POSCTRL`) |
| `evidence/` | self-check, hashes, build records, per-cell records and exports |
| `scratch/` | the DAO fixture template and one unique disposable copy per cell run |
