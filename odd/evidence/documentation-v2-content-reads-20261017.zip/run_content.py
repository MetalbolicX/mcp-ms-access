"""Bounded T4 content-read runner: corrected References, SaveAsText, trust refusal, DAO
inventory.

ODD ``documentation-workflows-v2``, task **T4** (Specs S2, S5). Throwaway research tooling:
it edits no production file, never cleans up its own scratch root, and does **not** run the
live matrix unless ``--all`` is given (the parent owns the live launch in the background).

It answers, with real ``MSACCESS.EXE`` instances on disposable scratch copies under
``AutomationSecurity = 3``:

1. **REFERENCES** -- with the corrected **1-based** enumeration (production precedent
   ``backends/access/vba.py`` ``VBProjects``), can ``Application.References`` be read?
   ``Count`` is probed alone; every ``References(i)`` is probed in its own boundary with its
   COM error class and ``excepinfo`` recorded. Reproduced 3 times.
2. **SAVEASREAD** -- can forms (2), reports (3) and macros (4) be exported via
   ``SaveAsText`` under force-disable without executing anything? The fixture objects are
   proven present first via DAO Containers, each export is UTF-16-LE-BOM decoded and hashed,
   and if every export fails a single low-security **POSCTRL** distinguishes "blocked by
   ForceDisable" from a harness defect. Reproduced 3 times.
3. **TRUSTREFUSAL** -- probing ``CurrentProject``/``VBE`` when host trust is refused must
   degrade to a recorded ``unavailable``-style outcome, never a crash and never a settings
   change. ``trust_enabled_observed`` records the host's actual either-way outcome.
   Reproduced 3 times.
4. **STARTUPPROPS** -- the full DAO ``Properties`` list and ``Containers`` inventory are read
   on the same copies (engine-level Tier-1 data point, also the SAVEASREAD non-vacuity
   evidence).

Exit codes (documented, no auto-retry, the matrix stops at the first timeout):

* ``0`` -- ``PASS`` (or ``PASS`` with recorded limitations);
* ``2`` -- harness/build error before or instead of the matrix (includes self-check failure);
* ``3`` -- a content cell gate failed (crash, missing diagnostics, lock residue, survivor);
* ``4`` -- safety violation (canonical hash changed, new foreign ``MSACCESS.EXE``,
  unverified kill);
* ``5`` -- a cell exceeded the harness-level cell budget: the matrix stopped there;
* ``6`` -- inconclusive: the SaveAsText cell is vacuous (no positive read anywhere).
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import py_compile
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from t4_common import (  # noqa: E402
    AC_FORM,
    AC_MACRO,
    AC_MODULE,
    AC_REPORT,
    BASELINE_PIDS_FILE,
    CELL_KINDS,
    DB_NAME,
    EVIDENCE_DIR,
    FORM_CONTROL_NAME,
    FORM_NAME,
    HASHES_AFTER_FILE,
    HASHES_BEFORE_FILE,
    MACRO_NAME,
    MODULE_NAME,
    MSO_AUTOMATION_SECURITY_FORCE_DISABLE,
    MSO_AUTOMATION_SECURITY_LOW,
    REPORT_NAME,
    REPORT_FILE,
    ROOT,
    SCRATCH_COPY_DIR,
    SCRATCH_DIR,
    SUMMARY_FILE,
    TABLE_NAME,
    canonical_hashes,
    decode_utf16_bom,
    describe_com_error,
    diff_hashes,
    list_msaccess_pids,
    lock_files,
    new_access_pids,
    read_json,
    terminate_verified_access,
    verified_kill_python,
    wait_until,
    write_json_flushed,
)

BUILD_FIXTURE = SCRATCH_DIR / "build_fixture.py"
DAO_PROBE = SCRATCH_DIR / "dao_probe.py"
CONTENT_WORKER = SCRATCH_DIR / "content_worker.py"
HARNESS_MODULES = (
    "t4_common.py",
    "dao_probe.py",
    "build_fixture.py",
    "content_worker.py",
    "run_content.py",
)
# Static safety scans run over the modules that actually issue process/UI calls; the runner
# itself contains the forbidden-token *list* below, so scanning it would be self-referential.
SAFETY_SCAN_MODULES = ("t4_common.py", "dao_probe.py", "build_fixture.py", "content_worker.py")
OBJECT_KEYS = ("form", "report", "macro", "module", "table")

EXIT_PASS = 0
EXIT_HARNESS_ERROR = 2
EXIT_CONTENT_FAILURE = 3
EXIT_SAFETY_VIOLATION = 4
EXIT_CELL_TIMEOUT = 5
EXIT_INCONCLUSIVE = 6

DEFAULT_REPEAT = 3
DEFAULT_CELL_TIMEOUT = 120.0
DEFAULT_GRACE = 15.0
BUILD_TIMEOUT = 300.0
DAO_TIMEOUT = 90.0


# ---------------------------------------------------------------------------------------
# verdict
# ---------------------------------------------------------------------------------------
def compute_verdict(payload: dict[str, Any]) -> dict[str, Any]:
    """Pure verdict function (unit-checked by ``--self-check`` with synthetic inputs)."""
    cells = payload["cells"]
    by_kind: dict[str, list[dict[str, Any]]] = {}
    for cell in cells:
        by_kind.setdefault(cell.get("kind", "?"), []).append(cell)
    timeouts = [cell["cell"] for cell in cells if cell.get("timeout")]
    gate_failures = [cell["cell"] for cell in cells if not cell.get("gate", {}).get("passed")]

    originals_unchanged = bool(payload["hashes_diff"].get("unchanged"))
    baseline = set(payload["baseline_msaccess_pids"])
    final = set(payload["final_msaccess_pids"])
    survivors = sorted(final - baseline)
    foreign_kills = list(payload.get("foreign_kill_attempts") or [])

    references = by_kind.get("REFERENCES", [])
    trust = by_kind.get("TRUSTREFUSAL", [])
    saveasread = by_kind.get("SAVEASREAD", [])
    posctrl = payload.get("positive_control") or {}
    fd_any_export_ok = any(cell.get("exports_ok") for cell in saveasread)
    pc_ran = bool(posctrl.get("ran"))
    pc_any_export_ok = bool(posctrl.get("any_export_ok"))
    positive_read_somewhere = fd_any_export_ok or pc_any_export_ok
    dao_ok = bool(payload.get("dao_objects_present"))

    def _gates(kind_cells: list[dict[str, Any]], check_name: str) -> bool:
        if not kind_cells:
            return False
        return all(cell.get("gate", {}).get("checks", {}).get(check_name) for cell in kind_cells)

    checks = {
        "references_cells_present": bool(references),
        "references_diagnostics_separated": _gates(references, "references_diagnostics_separated"),
        "trust_cells_present": bool(trust),
        "trust_path_recorded": _gates(trust, "trust_flag_is_bool"),
        "trust_no_settings_change": _gates(trust, "no_settings_change_declared"),
        "saveasread_cells_present": bool(saveasread),
        "dao_fixture_objects_present": dao_ok,
        "positive_read_somewhere": positive_read_somewhere,
        "originals_unchanged": originals_unchanged,
        "zero_owned_survivors": not survivors,
        "no_unverified_kill": not foreign_kills,
        "no_cell_timeout": not timeouts,
        "all_cells_gate_passed": not gate_failures,
    }
    limitations: list[str] = []
    if not fd_any_export_ok and pc_ran and pc_any_export_ok:
        limitations.append(
            "force-disable SaveAsText produced no successful export; the low-security "
            "positive control succeeded, so the block is attributable to ForceDisable"
        )
    if not fd_any_export_ok and not pc_any_export_ok:
        limitations.append(
            "no SaveAsText export succeeded even under low security: harness-defect / "
            "environment blocker, not a ForceDisable result"
        )
    if trust and all(cell.get("trust_enabled_observed") is False for cell in trust):
        limitations.append(
            "VBA project object model trust was refused; VBProject reads degraded to unavailable"
        )
    if references and all(cell.get("references_readable") is False for cell in references):
        limitations.append("Application.References was not readable in any cell (recorded outcome)")

    if survivors or foreign_kills or not originals_unchanged:
        status, exit_code = "FAIL", EXIT_SAFETY_VIOLATION
    elif timeouts:
        status, exit_code = "INCONCLUSIVE_TIMEOUT", EXIT_CELL_TIMEOUT
    elif gate_failures:
        status, exit_code = "FAIL", EXIT_CONTENT_FAILURE
    elif not positive_read_somewhere or not dao_ok:
        status, exit_code = "INCONCLUSIVE", EXIT_INCONCLUSIVE
    else:
        status, exit_code = "PASS", EXIT_PASS
    return {
        "schema": "v2-content.verdict/1",
        "status": status,
        "exit_code": exit_code,
        "checks": checks,
        "gate_failures": gate_failures,
        "cell_timeouts": timeouts,
        "owned_survivors": survivors,
        "foreign_kill_attempts": foreign_kills,
        "saveastext_force_disable_any_export": fd_any_export_ok,
        "positive_control": posctrl,
        "limitations": limitations,
        "matrix_stopped_after": payload.get("matrix_stopped_after"),
    }


# ---------------------------------------------------------------------------------------
# cell gate
# ---------------------------------------------------------------------------------------
def cell_checks(
    cell_kind: str,
    record: dict[str, Any],
    result: dict[str, Any],
    dao_present: dict[str, Any],
) -> dict[str, bool]:
    """Compute the non-vacuous gate for one cell (pure; exercised by ``--self-check``)."""
    checks: dict[str, bool] = {
        "child_returncode_zero": record.get("child_returncode") == 0,
        "child_streams_captured": record.get("stdout") is not None and record.get("stderr") is not None,
        "identity_file_present": bool(record.get("identity")),
        "identity_owned": bool((record.get("identity") or {}).get("verification", {}).get("owned")),
        "security_readback_matches": result.get("security_readback_matches") is True,
        "open_ok": result.get("open_ok") is True,
        "graceful_exit_observed": result.get("access_exited_after_quit") is True,
        "no_lock_residue_after_grace": not record.get("locks_after_grace"),
        "no_owned_survivors": not record.get("survivors_after_grace"),
        "no_unverified_kill": all(
            (not item.get("terminated")) or item.get("verified") for item in (record.get("harness_reap") or [])
        ),
        "dao_objects_present": all(dao_present.get(key) for key in ("form", "report", "macro", "module")),
        "windows_observation_recorded": isinstance(result.get("windows"), list),
    }
    if cell_kind == "REFERENCES":
        references = result.get("references") or {}
        checks["references_probe_recorded"] = bool(references)
        checks["references_count_recorded"] = "count" in references or "count_error" in references
        checks["references_items_recorded"] = references.get("items_all_recorded") is True
        checks["references_diagnostics_separated"] = (
            "collection_ok" in references and ("count" in references or "count_error" in references)
        )
    elif cell_kind in ("SAVEASREAD", "POSCTRL"):
        exports = result.get("exports") or []
        checks["three_exports_attempted"] = len(exports) == 3 and all("ok" in entry for entry in exports)
        checks["export_outcomes_recorded"] = all(
            ("ok" in entry) and (entry.get("ok") or "error" in entry) for entry in exports
        )
    elif cell_kind == "TRUSTREFUSAL":
        trust = result.get("trust") or {}
        refused = trust.get("trust_enabled_observed") is False
        refusal_error = trust.get("vbe_error") or trust.get("vbprojects_count_error") or trust.get("vbe_access_error")
        checks["trust_probe_recorded"] = bool(trust)
        checks["currentproject_probe_recorded"] = "currentproject_ok" in trust
        checks["vbe_probe_recorded"] = "vbe_ok" in trust
        checks["trust_flag_is_bool"] = isinstance(trust.get("trust_enabled_observed"), bool)
        checks["no_settings_change_declared"] = trust.get("settings_changed") is False
        checks["refusal_error_class_recorded"] = (not refused) or isinstance(refusal_error, dict)
    return checks


# ---------------------------------------------------------------------------------------
# bounded subprocess helpers
# ---------------------------------------------------------------------------------------
def run_bounded(argv: list[str], timeout: float) -> dict[str, Any]:
    record: dict[str, Any] = {
        "argv": [str(item) for item in argv],
        "returncode": None,
        "stdout": "",
        "stderr": "",
        "timeout": False,
    }
    try:
        completed = subprocess.run(  # noqa: S603 - fixed argv built in this harness, never a shell
            [str(item) for item in argv], capture_output=True, text=True, timeout=timeout, check=False, cwd=str(SCRATCH_DIR)
        )
    except subprocess.TimeoutExpired as exc:
        record["timeout"] = True
        record["stdout"] = _as_text(exc.stdout)
        record["stderr"] = _as_text(exc.stderr)
        return record
    record["returncode"] = completed.returncode
    record["stdout"] = completed.stdout
    record["stderr"] = completed.stderr
    return record


def _as_text(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return value or ""


def _parse_json(text: str) -> dict[str, Any] | None:
    try:
        parsed = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return None
    return parsed if isinstance(parsed, dict) else None


def _arm_copy(cell_name: str, run_index: int, template: Path) -> Path:
    directory = SCRATCH_COPY_DIR / f"{cell_name}-run{run_index}"
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / DB_NAME
    shutil.copy2(template, destination)
    return destination


def _dao_probe(copy_path: Path, out_dir: Path) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    probe = run_bounded(
        [sys.executable, str(DAO_PROBE), "--db", str(copy_path), "--out", str(out_dir / "dao_probe.json"), "--expect-copy-name"],
        DAO_TIMEOUT,
    )
    (out_dir / "dao_probe_stdout.txt").write_text(probe["stdout"], encoding="utf-8")
    (out_dir / "dao_probe_stderr.txt").write_text(probe["stderr"], encoding="utf-8")
    record = _parse_json(probe["stdout"]) or {"ok": False, "error": "DAO probe produced no JSON", "returncode": probe["returncode"]}
    record["returncode"] = probe["returncode"]
    record["timeout"] = probe["timeout"]
    write_json_flushed(out_dir / "dao_probe_result.json", record)
    return record


# ---------------------------------------------------------------------------------------
# live cell
# ---------------------------------------------------------------------------------------
def run_cell(
    *,
    cell_kind: str,
    run_index: int,
    copy_path: Path,
    baseline: set[int],
    security: int,
    cell_timeout: float,
    grace: float,
) -> dict[str, Any]:
    cell_name = f"{cell_kind.lower()}-run{run_index}"
    out_dir = EVIDENCE_DIR / "cells" / cell_name
    out_dir.mkdir(parents=True, exist_ok=True)
    dao = _dao_probe(copy_path, out_dir)
    dao_present = dao.get("objects_present") or {}
    record: dict[str, Any] = {
        "cell": cell_name,
        "kind": cell_kind,
        "run": run_index,
        "security_requested": security,
        "db": str(copy_path),
        "baseline_msaccess_pids": sorted(baseline),
        "dao_probe": dao,
        "dao_objects_present": dao_present,
        "locks_before_child": lock_files(copy_path.parent),
    }
    argv = [
        sys.executable,
        str(CONTENT_WORKER),
        "--cell",
        cell_kind,
        "--db",
        str(copy_path),
        "--out",
        str(out_dir),
        "--baseline-pids",
        ",".join(str(pid) for pid in sorted(baseline)),
        "--security",
        str(security),
    ]
    record["child_argv"] = [str(item) for item in argv]
    started = time.monotonic()
    proc = subprocess.Popen(  # noqa: S603 - fixed argv built in this harness, never a shell
        [str(item) for item in argv],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(SCRATCH_DIR),
    )
    timeout = False
    child_kills: list[dict[str, Any]] = []
    try:
        raw_out, raw_err = proc.communicate(timeout=cell_timeout)
    except subprocess.TimeoutExpired:
        timeout = True
        child_identity = read_json(out_dir / "child_identity.json", {}) or {}
        identity = child_identity.get("identity") or {}
        child_kills.append(verified_kill_python(child_identity.get("child_pid"), identity.get("creation")))
        if proc.poll() is None:
            proc.kill()
        try:
            raw_out, raw_err = proc.communicate(timeout=15.0)
        except subprocess.TimeoutExpired:
            raw_out, raw_err = b"", b""
    elapsed = round(time.monotonic() - started, 3)

    result = read_json(out_dir / "result.json", {}) or {}
    identity_file = read_json(out_dir / "identity.json", {}) or {}

    # Reap only the identity-announced owned Access; never a foreign PID.
    survivors_immediately = sorted(new_access_pids(baseline))
    harness_reap: list[dict[str, Any]] = []
    announced_pid = identity_file.get("access_pid")
    for pid in survivors_immediately:
        if pid == announced_pid and identity_file.get("access_creation"):
            harness_reap.append(
                dataclasses.asdict(
                    terminate_verified_access(
                        pid=pid,
                        creation=identity_file["access_creation"],
                        image=identity_file.get("access_image") or "",
                        baseline_pids=frozenset(baseline),
                        grace_seconds=grace,
                    )
                )
            )
    if survivors_immediately:
        wait_until(lambda: not new_access_pids(baseline), grace)

    record.update(
        {
            "elapsed_seconds": elapsed,
            "child_returncode": proc.returncode,
            "stdout": raw_out.decode("utf-8", "replace") if raw_out else "",
            "stderr": raw_err.decode("utf-8", "replace") if raw_err else "",
            "result": result,
            "identity": identity_file,
            "survivors_immediately_after": survivors_immediately,
            "harness_reap": harness_reap,
            "survivors_after_grace": sorted(new_access_pids(baseline)),
            "locks_after_grace": lock_files(copy_path.parent),
            "child_timeout_kills": child_kills,
            "timeout": timeout or elapsed > cell_timeout,
        }
    )
    checks = cell_checks(cell_kind, record, result, dao_present)
    record["gate"] = {"passed": all(checks.values()), "checks": checks}
    record["exports_ok"] = list(result.get("exports_ok") or [])
    references = result.get("references") or {}
    record["references_readable"] = references.get("readable") if isinstance(references, dict) else None
    trust = result.get("trust") or {}
    record["trust_enabled_observed"] = trust.get("trust_enabled_observed") if isinstance(trust, dict) else None
    write_json_flushed(out_dir / "run_record.json", record)
    return record


# ---------------------------------------------------------------------------------------
# self-check (no COM)
# ---------------------------------------------------------------------------------------
def _synthetic_cell(cell: str, kind: str, passed: bool = True, **extra: Any) -> dict[str, Any]:
    checks = {"gate": {"passed": passed, "checks": {}}}
    checks["gate"]["checks"]["references_diagnostics_separated"] = passed
    checks["gate"]["checks"]["trust_flag_is_bool"] = passed
    checks["gate"]["checks"]["no_settings_change_declared"] = passed
    base: dict[str, Any] = {"cell": cell, "kind": kind, "timeout": False, **checks}
    base.update(extra)
    return base


def _verdict_inputs(**overrides: Any) -> dict[str, Any]:
    cells = [
        _synthetic_cell("references-run1", "REFERENCES", references_readable=True),
        _synthetic_cell("trustrefusal-run1", "TRUSTREFUSAL", trust_enabled_observed=False),
        _synthetic_cell("saveasread-run1", "SAVEASREAD", exports_ok=["form", "report", "macro"]),
    ]
    payload: dict[str, Any] = {
        "cells": cells,
        "hashes_diff": {"unchanged": True, "changed": [], "added": [], "removed": []},
        "baseline_msaccess_pids": [100],
        "final_msaccess_pids": [100],
        "foreign_kill_attempts": [],
        "dao_objects_present": True,
        "positive_control": {"ran": False, "any_export_ok": False},
        "matrix_stopped_after": None,
    }
    payload.update(overrides)
    return payload


def phase_self_check() -> dict[str, Any]:
    """Compile, import, constant, source and synthetic-verdict checks; never COM."""
    checks: dict[str, bool] = {}
    details: dict[str, Any] = {}

    for module in HARNESS_MODULES:
        py_compile.compile(str(SCRATCH_DIR / module), doraise=True)
    checks["harness_modules_compile"] = True

    import build_fixture
    import content_worker
    import dao_probe

    checks["content_worker_cells"] = tuple(content_worker.CELLS) == ("REFERENCES", "SAVEASREAD", "TRUSTREFUSAL", "POSCTRL")
    checks["content_worker_export_targets"] = tuple(
        label for label, _type, _name in content_worker.EXPORT_TARGETS
    ) == ("form", "report", "macro")
    checks["dao_probe_has_read_database"] = callable(getattr(dao_probe, "read_database", None))
    checks["build_fixture_has_build"] = callable(getattr(build_fixture, "build", None))

    # --- production-constant cross-check (object kind ids vs object_kinds.py) -------------
    from ms_access_mcp.backends.access import object_kinds

    checks["production_form_id_matches"] = object_kinds.OBJECT_KINDS["form"]["ac_type"] == AC_FORM
    checks["production_report_id_matches"] = object_kinds.OBJECT_KINDS["report"]["ac_type"] == AC_REPORT

    generator_source = (ROOT / "scripts" / "generate_documentation_fixtures.py").read_text(encoding="utf-8")
    macros_source = (ROOT / "src" / "ms_access_mcp" / "backends" / "access" / "macros.py").read_text(encoding="utf-8")
    macro_constant = re.search(r"_AC_MACRO\s*=\s*(\d+)", generator_source)
    module_constant = re.search(r"_AC_MODULE\s*=\s*(\d+)", generator_source)
    checks["generator_macro_id_matches"] = bool(macro_constant) and int(macro_constant.group(1)) == AC_MACRO
    checks["generator_module_id_matches"] = bool(module_constant) and int(module_constant.group(1)) == AC_MODULE
    checks["macros_module_uses_acmacro_4"] = "acMacro=4" in macros_source
    legacy = {
        "vba_reports_report_4": "acReport=4" in (ROOT / "src" / "ms_access_mcp" / "backends" / "access" / "vba.py").read_text(encoding="utf-8"),
        "vba_reports_macro_8": "acMacro=8" in (ROOT / "src" / "ms_access_mcp" / "backends" / "access" / "vba.py").read_text(encoding="utf-8"),
        "versioning_report_4": "_AC_REPORT = 4" in (ROOT / "src" / "ms_access_mcp" / "backends" / "versioning.py").read_text(encoding="utf-8"),
        "versioning_macro_8": "_AC_MACRO = 8" in (ROOT / "src" / "ms_access_mcp" / "backends" / "versioning.py").read_text(encoding="utf-8"),
    }
    # The harness uses the live-verified AcObjectType ids (form 2, report 3, macro 4); the
    # docstring/constants above are recorded because they carry the legacy report=4/macro=8
    # pair. This is a recorded discrepancy for the parent, never a silent override.
    details["legacy_constant_discrepancies"] = legacy
    checks["legacy_discrepancies_recorded"] = isinstance(legacy, dict)

    # --- production process-identity seam ------------------------------------------------
    import inspect

    from ms_access_mcp.application import process_identity

    terminate_params = inspect.signature(process_identity.terminate_verified_access).parameters
    checks["terminate_verified_access_scoped"] = all(
        name in terminate_params for name in ("pid", "creation", "image", "baseline_pids", "grace_seconds")
    )
    checks["process_identity_lists_access"] = process_identity.ACCESS_IMAGE_NAME == "MSACCESS.EXE"

    # --- static safety scans -------------------------------------------------------------
    safety_text = "\n".join((SCRATCH_DIR / module).read_text(encoding="utf-8") for module in SAFETY_SCAN_MODULES)
    checks["no_im_kill"] = not re.search(r"[\"']/IM[\"']", safety_text)
    checks["no_trust_center_mutation"] = not any(
        token in safety_text for token in ("VBAWarnings", "AccessVBOM", "TrustedLocations", "AddTrustedLocation")
    )
    checks["no_synthetic_input"] = not any(token in safety_text for token in ("SendKeys", "keybd_event", "mouse_event"))
    checks["no_dialog_acceptance"] = not any(token in safety_text for token in ("WM_CLOSE", "EndDialog"))

    # --- unit checks on the pure helpers -------------------------------------------------
    utf16 = b"\xff\xfe" + "Hello".encode("utf-16-le")
    checks["decode_utf16_bom_round_trip"] = decode_utf16_bom(utf16) == "Hello"

    class _FakeComError(Exception):
        def __init__(self) -> None:
            super().__init__(-2146768444, "invalid ordinal")
            self.excepinfo = (0, "Access", "The object does not exist", None, 0, -2146768444)

    described = describe_com_error(_FakeComError())
    checks["com_error_scode_and_description_recorded"] = (
        described["scode"] == -2146768444 and described["description"] == "The object does not exist"
    )

    # --- synthetic cell-gate assertions --------------------------------------------------
    good_references = {
        "references": {"collection_ok": True, "count": 2, "items_all_recorded": True, "readable": True},
    }
    base_record = {
        "child_returncode": 0,
        "stdout": "",
        "stderr": "",
        "identity": {"verification": {"owned": True}},
        "locks_after_grace": [],
        "survivors_after_grace": [],
        "harness_reap": [],
    }
    base_result = {
        "security_readback_matches": True,
        "open_ok": True,
        "access_exited_after_quit": True,
        "windows": [],
    }
    present = {key: True for key in OBJECT_KEYS}
    references_gate = cell_checks("REFERENCES", base_record, {**base_result, **good_references}, present)
    checks["synthetic_references_gate_passes"] = all(references_gate.values())
    references_count_error_gate = cell_checks(
        "REFERENCES",
        base_record,
        {
            **base_result,
            "references": {
                "collection_ok": True,
                "count_error": describe_com_error(_FakeComError()),
                "items_all_recorded": True,
            },
        },
        present,
    )
    # A Count error is still a recorded, separated diagnostic, so the gate holds.
    checks["synthetic_references_count_error_recorded"] = (
        references_count_error_gate["references_count_recorded"]
        and references_count_error_gate["references_diagnostics_separated"]
    )
    lock_gate = cell_checks("SAVEASREAD", {**base_record, "locks_after_grace": ["x.laccdb"]}, {**base_result, "exports": []}, present)
    checks["synthetic_lock_residue_fails_gate"] = not lock_gate["no_lock_residue_after_grace"]
    trust_gate = cell_checks(
        "TRUSTREFUSAL",
        base_record,
        {**base_result, "trust": {"currentproject_ok": True, "vbe_ok": False, "vbe_error": describe_com_error(_FakeComError()), "trust_enabled_observed": False, "settings_changed": False}},
        present,
    )
    checks["synthetic_trust_refusal_gate_passes"] = all(trust_gate.values())

    # --- synthetic verdict assertions ----------------------------------------------------
    verdicts = {
        "all_pass": compute_verdict(_verdict_inputs()),
        "survivor": compute_verdict(_verdict_inputs(final_msaccess_pids=[100, 777])),
        "hash_changed": compute_verdict(
            _verdict_inputs(hashes_diff={"unchanged": False, "changed": ["db/northwind.accdb"], "added": [], "removed": []})
        ),
        "cell_gate_failed": compute_verdict(
            _verdict_inputs(
                cells=[
                    _synthetic_cell("references-run1", "REFERENCES", passed=False),
                    _synthetic_cell("saveasread-run1", "SAVEASREAD", exports_ok=["form"]),
                ]
            )
        ),
        "timeout": compute_verdict(_verdict_inputs(cells=[_synthetic_cell("saveasread-run1", "SAVEASREAD", timeout=True)], matrix_stopped_after="saveasread-run1")),
        "vacuous_saveasread": compute_verdict(
            _verdict_inputs(cells=[_synthetic_cell("saveasread-run1", "SAVEASREAD", exports_ok=[])], positive_control={"ran": True, "any_export_ok": False})
        ),
        "positive_control_rescues": compute_verdict(
            _verdict_inputs(cells=[_synthetic_cell("saveasread-run1", "SAVEASREAD", exports_ok=[])], positive_control={"ran": True, "any_export_ok": True})
        ),
    }
    details["synthetic_verdicts"] = {
        name: {"status": verdict["status"], "exit_code": verdict["exit_code"]} for name, verdict in verdicts.items()
    }
    checks["synthetic_all_pass"] = verdicts["all_pass"]["status"] == "PASS" and verdicts["all_pass"]["exit_code"] == EXIT_PASS
    checks["synthetic_survivor_fails_safety"] = verdicts["survivor"]["exit_code"] == EXIT_SAFETY_VIOLATION
    checks["synthetic_hash_change_fails_safety"] = verdicts["hash_changed"]["exit_code"] == EXIT_SAFETY_VIOLATION
    checks["synthetic_cell_gate_failure"] = verdicts["cell_gate_failed"]["exit_code"] == EXIT_CONTENT_FAILURE
    checks["synthetic_timeout_stops_matrix"] = verdicts["timeout"]["exit_code"] == EXIT_CELL_TIMEOUT
    checks["synthetic_vacuous_inconclusive"] = verdicts["vacuous_saveasread"]["exit_code"] == EXIT_INCONCLUSIVE
    checks["synthetic_positive_control_rescues"] = verdicts["positive_control_rescues"]["exit_code"] == EXIT_PASS

    # --- bounded child exit-code probe (no COM) ------------------------------------------
    try:
        probe = subprocess.run(  # noqa: S603 - fixed argv, bounded, never a shell
            [sys.executable, "-c", "import os; os._exit(7)"], capture_output=True, timeout=30, check=False, cwd=str(SCRATCH_DIR)
        )
        details["child_exit_code_probe"] = {"returncode": probe.returncode, "expected": 7}
        checks["child_exit_code_reaches_parent"] = probe.returncode == 7
    except Exception as exc:  # noqa: BLE001
        details["child_exit_code_probe"] = {"error": f"{type(exc).__name__}: {exc}"}
        checks["child_exit_code_reaches_parent"] = False

    try:
        from tests.helpers.dialog_watcher import collect_windows  # noqa: F401

        details["dialog_watcher_import"] = {"ok": True}
    except Exception as exc:  # noqa: BLE001
        details["dialog_watcher_import"] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    result = {"schema": "v2-content.self-check/1", "ok": all(checks.values()), "checks": checks, "details": details}
    write_json_flushed(EVIDENCE_DIR / "self_check.json", result)
    return result


# ---------------------------------------------------------------------------------------
# matrix
# ---------------------------------------------------------------------------------------
def run_matrix(args: argparse.Namespace) -> int:
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    SCRATCH_COPY_DIR.mkdir(parents=True, exist_ok=True)

    baseline = set(list_msaccess_pids())
    write_json_flushed(BASELINE_PIDS_FILE, {"baseline_msaccess_pids": sorted(baseline), "recorded_at": time.strftime("%Y-%m-%dT%H:%M:%S")})
    hashes_before = canonical_hashes()
    write_json_flushed(HASHES_BEFORE_FILE, hashes_before)

    template_dir = SCRATCH_COPY_DIR / "template"
    build = run_bounded([sys.executable, str(BUILD_FIXTURE), "--out-dir", str(template_dir)], BUILD_TIMEOUT)
    (EVIDENCE_DIR / "build_stdout.txt").write_text(build["stdout"], encoding="utf-8")
    (EVIDENCE_DIR / "build_stderr.txt").write_text(build["stderr"], encoding="utf-8")
    build_record = _parse_json(build["stdout"]) or {"ok": False, "error": "builder produced no JSON record"}
    build_record["returncode"] = build["returncode"]
    build_record["timeout"] = build["timeout"]
    write_json_flushed(EVIDENCE_DIR / "build_result.json", build_record)
    template_dao = _dao_probe(template_dir / DB_NAME, EVIDENCE_DIR / "template")
    dao_present = bool((template_dao.get("objects_present") or {}).get("form")) and all(
        (template_dao.get("objects_present") or {}).get(key) for key in OBJECT_KEYS
    )

    cells: list[dict[str, Any]] = []
    matrix_stopped_after: str | None = None
    positive_control: dict[str, Any] = {"ran": False, "any_export_ok": False}
    if not build_record.get("ok") or not dao_present:
        verdict = {
            "schema": "v2-content.verdict/1",
            "status": "HARNESS_ERROR",
            "exit_code": EXIT_HARNESS_ERROR,
            "checks": {"fixture_built": bool(build_record.get("ok")), "dao_fixture_objects_present": dao_present},
            "failures": ["fixture build or DAO inventory failed; no live cell ran"],
            "build": build_record,
            "template_dao": template_dao,
        }
    else:
        template = template_dir / DB_NAME
        plan: list[tuple[str, int, int]] = []
        for kind in ("REFERENCES", "TRUSTREFUSAL", "SAVEASREAD"):
            plan += [(kind, index + 1, MSO_AUTOMATION_SECURITY_FORCE_DISABLE) for index in range(args.repeat)]
        for kind, run_index, security in plan:
            cell_name = f"{kind.lower()}-run{run_index}"
            copy_path = _arm_copy(cell_name, run_index, template)
            cell = run_cell(
                cell_kind=kind,
                run_index=run_index,
                copy_path=copy_path,
                baseline=baseline,
                security=security,
                cell_timeout=args.cell_timeout,
                grace=args.grace,
            )
            cells.append(cell)
            print(
                f"[{cell_name}] passed={cell['gate']['passed']} timeout={cell['timeout']} "
                f"exports_ok={cell.get('exports_ok')}",
                flush=True,
            )
            if cell["timeout"]:
                matrix_stopped_after = cell_name
                break

        # Conditional, single low-security positive control: only when every force-disable
        # export failed, and only if the matrix was not stopped by a timeout.
        saveasread = [cell for cell in cells if cell["kind"] == "SAVEASREAD"]
        fd_any_export_ok = any(cell.get("exports_ok") for cell in saveasread)
        if matrix_stopped_after is None and saveasread and not fd_any_export_ok:
            pc_copy = _arm_copy("posctrl", 1, template)
            pc_cell = run_cell(
                cell_kind="POSCTRL",
                run_index=1,
                copy_path=pc_copy,
                baseline=baseline,
                security=MSO_AUTOMATION_SECURITY_LOW,
                cell_timeout=args.cell_timeout,
                grace=args.grace,
            )
            cells.append(pc_cell)
            positive_control = {"ran": True, "any_export_ok": bool(pc_cell.get("exports_ok"))}
            print(f"[posctrl-run1] passed={pc_cell['gate']['passed']} exports_ok={pc_cell.get('exports_ok')}", flush=True)
            if pc_cell["timeout"]:
                matrix_stopped_after = "posctrl-run1"

        hashes_after = canonical_hashes()
        diff = diff_hashes(hashes_before, hashes_after)
        final_pids = sorted(list_msaccess_pids())
        foreign_kill_attempts = _foreign_kill_attempts(cells)
        verdict = compute_verdict(
            {
                "cells": cells,
                "hashes_diff": diff,
                "baseline_msaccess_pids": sorted(baseline),
                "final_msaccess_pids": final_pids,
                "foreign_kill_attempts": foreign_kill_attempts,
                "dao_objects_present": dao_present,
                "positive_control": positive_control,
                "matrix_stopped_after": matrix_stopped_after,
            }
        )
        verdict["build"] = build_record
        verdict["template_dao"] = template_dao
        verdict["hashes_diff"] = diff
        verdict["baseline_msaccess_pids"] = sorted(baseline)
        verdict["final_msaccess_pids"] = final_pids
    write_json_flushed(HASHES_AFTER_FILE, canonical_hashes())

    report = {
        "schema": "v2-content.report/1",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "scratch_root": str(SCRATCH_DIR),
        "root": str(ROOT),
        "python": sys.version,
        "python_executable": sys.executable,
        "baseline_msaccess_pids": sorted(baseline),
        "build": build_record,
        "template_dao_objects_present": dao_present,
        "cells": cells,
        "verdict": verdict,
    }
    write_json_flushed(REPORT_FILE, report)
    write_json_flushed(
        SUMMARY_FILE,
        {
            "schema": "v2-content.summary/1",
            "status": verdict.get("status"),
            "exit_code": verdict.get("exit_code"),
            "checks": verdict.get("checks"),
            "limitations": verdict.get("limitations"),
            "cell_gates": {cell["cell"]: cell["gate"]["passed"] for cell in cells},
            "cell_exports_ok": {cell["cell"]: cell.get("exports_ok") for cell in cells},
            "cell_elapsed_seconds": {cell["cell"]: cell["elapsed_seconds"] for cell in cells},
        },
    )
    print(json.dumps({"status": verdict.get("status"), "exit_code": verdict.get("exit_code")}, indent=2))
    return int(verdict.get("exit_code", EXIT_HARNESS_ERROR))


def _foreign_kill_attempts(cells: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Any kill issued without a positive identity verification (must be empty)."""
    findings: list[dict[str, Any]] = []
    for cell in cells:
        for item in cell.get("harness_reap") or []:
            if item.get("terminated") and not item.get("verified"):
                findings.append({"cell": cell["cell"], "kind": "access-reap", **item})
        for item in cell.get("child_timeout_kills") or []:
            if item.get("result") == "killed":
                verified = (
                    item.get("observed_creation") is not None
                    and item.get("observed_creation") == item.get("expected_creation")
                    and str(item.get("observed_image", "")).casefold().startswith("python")
                )
                if not verified:
                    findings.append({"cell": cell["cell"], "kind": "python-timeout-kill", **item})
    return findings


# ---------------------------------------------------------------------------------------
# entry point
# ---------------------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--self-check", action="store_true", help="compile/import/constant/source/synthetic-verdict checks; no COM")
    mode.add_argument("--all", action="store_true", help="run the full live content matrix (self-check first)")
    parser.add_argument("--repeat", type=int, default=DEFAULT_REPEAT, help="runs per live cell")
    parser.add_argument("--cell-timeout", type=float, default=DEFAULT_CELL_TIMEOUT, help="harness-level cell budget (seconds)")
    parser.add_argument("--grace", type=float, default=DEFAULT_GRACE, help="owned-Access reap grace (seconds)")
    args = parser.parse_args(argv)

    if args.self_check or args.all:
        self_check = phase_self_check()
        if not self_check["ok"]:
            failed = sorted(name for name, ok in self_check["checks"].items() if not ok)
            print(json.dumps({"status": "SELF_CHECK_FAILED", "failed_checks": failed}, indent=2))
            return EXIT_HARNESS_ERROR
        if args.self_check:
            print(json.dumps({"status": "SELF_CHECK_OK", "checks": len(self_check["checks"])}, indent=2))
            return EXIT_PASS

    if not args.all:
        parser.print_help()
        return EXIT_HARNESS_ERROR
    return run_matrix(args)


if __name__ == "__main__":
    raise SystemExit(main())
