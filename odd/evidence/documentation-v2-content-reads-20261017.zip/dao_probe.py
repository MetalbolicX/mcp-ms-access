"""DAO-only Tier-1 probe: full database ``Properties`` list + ``Containers`` inventory.

Engine-level only (DAO ``DBEngine.120``); it never instantiates ``Access.Application`` and
never opens a database for write. It answers the T4 **STARTUPPROPS** data point and also
provides the non-vacuity evidence for the SaveAsText cell: the fixture's forms, reports,
scripts (macros), modules and tables must be observable through DAO Containers *before*
an Access export is attempted.

Every field read is individually guarded, so a single unreadable property or document is
recorded rather than aborting the probe. Usage: ``dao_probe.py --db <file> [--out <json>]``.
Exit codes: 0 ok; 2 probe failure.
"""

from __future__ import annotations

import argparse
import gc
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from t4_common import (  # noqa: E402
    DB_NAME,
    FORM_NAME,
    MACRO_NAME,
    MODULE_NAME,
    REPORT_NAME,
    TABLE_NAME,
    describe_com_error,
    safe_call,
    write_json_flushed,
)

# Container namespaces that carry the T4 objects plus the table/query context.
CONTAINER_NAMES = ("Tables", "Queries", "Forms", "Reports", "Scripts", "Modules")


def read_database(db_path: Path) -> dict[str, Any]:
    """Open ``db_path`` read-only and return its properties and container documents.

    The database is opened with DAO's ``OpenDatabase(name, exclusive=False, readOnly=True)``
    so the probe cannot mutate the file. Returns a JSON-serializable record; a DAO failure
    is captured in ``error`` rather than raised.
    """
    if os.name != "nt":
        return {"ok": False, "error": "DAO probe requires Windows", "db": str(db_path)}
    import pythoncom
    import win32com.client

    record: dict[str, Any] = {
        "schema": "v2-content.dao-probe/1",
        "db": str(db_path),
        "ok": False,
        "properties": [],
        "containers": {},
    }
    pythoncom.CoInitialize()
    engine: Any = None
    db: Any = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        db = engine.OpenDatabase(str(db_path), False, True)

        # --- full Properties list -------------------------------------------------------
        try:
            count = int(db.Properties.Count)
            record["properties_count"] = count
            for index in range(count):
                entry: dict[str, Any] = {"ordinal": index}
                try:
                    prop = db.Properties(index)
                    entry["name_result"] = safe_call(lambda prop=prop: str(prop.Name))
                    entry["type_result"] = safe_call(lambda prop=prop: int(prop.Type))
                    entry["value_result"] = safe_call(lambda prop=prop: str(prop.Value))
                    entry["ok"] = True
                except Exception as exc:  # noqa: BLE001 - one bad property is not fatal
                    entry["ok"] = False
                    entry["error"] = describe_com_error(exc)
                record["properties"].append(entry)
        except Exception as exc:  # noqa: BLE001
            record["properties_error"] = describe_com_error(exc)

        # --- Containers inventory -------------------------------------------------------
        for container_name in CONTAINER_NAMES:
            container_record: dict[str, Any] = {"name": container_name, "documents": []}
            try:
                container = db.Containers(container_name)
                container_record["documents_count_result"] = safe_call(lambda c=container: int(c.Documents.Count))
                try:
                    documents_count = int(container.Documents.Count)
                except Exception:  # noqa: BLE001 - already recorded above
                    documents_count = 0
                for index in range(documents_count):
                    document: dict[str, Any] = {"ordinal": index}
                    try:
                        doc = container.Documents(index)
                        document["name"] = str(doc.Name)
                        document["date_created"] = safe_call(lambda d=doc: str(d.DateCreated))
                        document["date_modified"] = safe_call(lambda d=doc: str(d.DateModified))
                        document["ok"] = True
                    except Exception as exc:  # noqa: BLE001
                        document["ok"] = False
                        document["error"] = describe_com_error(exc)
                    container_record["documents"].append(document)
                container_record["ok"] = True
            except Exception as exc:  # noqa: BLE001 - a missing container is recorded
                container_record["ok"] = False
                container_record["error"] = describe_com_error(exc)
            record["containers"][container_name] = container_record

        record["objects_present"] = _objects_present(record["containers"])
        record["ok"] = True
    except Exception as exc:  # noqa: BLE001 - a probe failure is evidence, not silence
        record["error"] = describe_com_error(exc)
    finally:
        if db is not None:
            try:
                db.Close()
            except Exception:  # noqa: BLE001
                pass
        db = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()
    return record


def _document_names(container_record: dict[str, Any]) -> list[str]:
    names = []
    for document in container_record.get("documents", []):
        name = document.get("name")
        if isinstance(name, str):
            names.append(name)
    return names


def _objects_present(containers: dict[str, Any]) -> dict[str, Any]:
    forms = _document_names(containers.get("Forms", {}))
    reports = _document_names(containers.get("Reports", {}))
    scripts = _document_names(containers.get("Scripts", {}))
    modules = _document_names(containers.get("Modules", {}))
    tables = _document_names(containers.get("Tables", {}))
    return {
        "form": FORM_NAME in forms,
        "report": REPORT_NAME in reports,
        "macro": MACRO_NAME in scripts,
        "module": MODULE_NAME in modules,
        "table": TABLE_NAME in tables,
        "names": {
            "Forms": forms,
            "Reports": reports,
            "Scripts": scripts,
            "Modules": modules,
            "Tables": tables,
        },
    }


def probe(db_path: Path, out_path: Path | None = None) -> dict[str, Any]:
    record = read_database(db_path)
    if out_path is not None:
        write_json_flushed(out_path, record)
    return record


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--db", required=True, type=Path)
    parser.add_argument("--out", type=Path, default=None)
    parser.add_argument("--expect-copy-name", action="store_true", help="refuse anything not named the fixture db")
    args = parser.parse_args(argv)
    if args.expect_copy_name and args.db.name != DB_NAME:
        print(json.dumps({"ok": False, "error": f"refusing non-fixture database name {args.db.name!r}"}))
        return 2
    record = probe(args.db, args.out)
    print(json.dumps(record, ensure_ascii=True, default=str))
    return 0 if record.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
