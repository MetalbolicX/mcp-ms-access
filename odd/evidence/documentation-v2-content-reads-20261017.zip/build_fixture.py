"""Build the disposable T4 content fixture safely (reads-only fixture, no auto-run object).

Fixture shape (exactly what the content-read cells must be able to see):

* table ``ContentNotes`` with one row (DAO-created, bracketed identifiers);
* module ``ContentModule`` with one trivial function (never executed);
* form ``frmContent`` carrying one text-box control ``txtProbe``;
* report ``rptContent``;
* named macro ``mcrContent`` whose only action is ``OpenForm("frmContent")``.

Nothing auto-runs: there is **no** ``AutoExec``, no ``AutoKeys``, and no ``StartupForm``
database property. This fixture tests *reads*, not startup suppression (that was proven
separately). Build-order discipline mirrors ``scripts/generate_documentation_fixtures.py``
and both prior spikes: DAO performs all DDL first; ``Access.Application`` opens only while
no auto-run object exists; the macro is loaded under the neutral name ``NeutralMacro``,
its real stored text is captured with ``SaveAsText`` **before** the rename to
``mcrContent``; the database is closed and quit without being reopened.

Identity/security discipline: fresh ``DispatchEx``, fail-closed PID+creation+image
ownership proof before any open, ``AutomationSecurity=3`` set and read back before
``OpenCurrentDatabase``, ``Visible=False``/``UserControl=False``, a read-only window
observer started before the open, and no synthetic input or dialog acceptance.

Usage: ``build_fixture.py --out-dir <dir>`` writes ``<dir>/content.accdb`` plus the text
sources and prints one JSON build record. Exit codes: 0 ok; 2 build failure.
"""

from __future__ import annotations

import argparse
import gc
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from dao_probe import read_database  # noqa: E402
from t4_common import (  # noqa: E402
    AC_FORM,
    AC_MACRO,
    AC_MODULE,
    AC_REPORT,
    AC_SAVE_YES,
    AC_TEXTBOX,
    DB_NAME,
    DB_VERSION,
    FORM_CONTROL_NAME,
    FORM_NAME,
    LOCALE,
    MACRO_NAME,
    MODULE_NAME,
    MSO_AUTOMATION_SECURITY_FORCE_DISABLE,
    NEUTRAL_MACRO_NAME,
    REPORT_NAME,
    TABLE_NAME,
    WindowObserver,
    baseline_pids,
    describe_com_error,
    lock_files,
    new_access_pids,
    process_is_alive,
    read_process_identity,
    safe_call,
    sha256_file,
    terminate_verified_access,
    wait_until,
    write_json_flushed,
)

# Standard module: raw VBA source (the SaveAsText framing wrapper would import as a
# compile error). The function returns a value but nothing ever calls it.
MODULE_SOURCE = """Option Compare Database
Option Explicit

Public Function ContentProbe() As Boolean
    ContentProbe = True
End Function
"""

# Pure AXL macro dialect (SaveAsText/LoadFromText) as captured live 2026-10-10 and used by
# scripts/generate_documentation_fixtures.py. Only OpenForm: the macro is named mcrContent,
# is not AutoExec/AutoKeys, and therefore never runs on open.
MACRO_SOURCE = '''Version =196611
ColumnsShown =0
Begin
    Action ="OpenForm"
    Argument ="frmContent"
End
'''

TABLE_DDL = (
    f"CREATE TABLE [{TABLE_NAME}] ([NoteID] LONG NOT NULL, [Note] TEXT(50), "
    f"CONSTRAINT [PK_{TABLE_NAME}] PRIMARY KEY ([NoteID]))"
)
TABLE_INSERT = f"INSERT INTO [{TABLE_NAME}] ([NoteID], [Note]) VALUES (1, 'content note')"


def _write_text_sources(out_dir: Path) -> dict[str, Path]:
    paths = {
        "module": out_dir / "content_module.bas",
        "macro": out_dir / "content_macro_neutral.txt",
    }
    paths["module"].write_text(MODULE_SOURCE, encoding="utf-8", newline="\r\n")
    paths["macro"].write_text(MACRO_SOURCE, encoding="utf-8", newline="\r\n")
    return paths


def _create_dao_database(db_path: Path) -> dict[str, Any]:
    if os.name != "nt":
        msg = "fixture build requires Windows and ACE DAO"
        raise RuntimeError(msg)
    import pythoncom
    import win32com.client

    pythoncom.CoInitialize()
    engine: Any = None
    db: Any = None
    record: dict[str, Any] = {"ddl": True}
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        db = engine.CreateDatabase(str(db_path), LOCALE, DB_VERSION)
        db.Execute(TABLE_DDL, 128)
        db.TableDefs.Refresh()
        record["tables"] = sorted(str(db.TableDefs(i).Name) for i in range(db.TableDefs.Count))
        db.Execute(TABLE_INSERT, 128)
    finally:
        if db is not None:
            try:
                db.Close()
            except Exception:  # noqa: BLE001
                pass
        db = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()
    return record


def _add_form_control(app: Any, form_name: str) -> dict[str, Any]:
    """Add one text-box control to a form already open in design view.

    ``CreateForm`` returns the form open in design view, so ``CreateControl`` attaches
    directly. If that fails, the form is closed without saving and reopened in design view
    once before a single retry; both attempts and their errors are recorded.
    """
    record: dict[str, Any] = {"control_name": FORM_CONTROL_NAME, "ac_control_type": AC_TEXTBOX, "added": False}

    def _attempt(label: str) -> None:
        try:
            control = app.CreateControl(form_name, AC_TEXTBOX, 0)  # section 0 = detail
            control.Name = FORM_CONTROL_NAME
            record["added"] = True
            record["attempt"] = label
            record["created_name"] = safe_call(lambda: str(control.Name))
        except Exception as exc:  # noqa: BLE001
            record[f"error_{label}"] = describe_com_error(exc)

    _attempt("direct")
    if not record["added"]:
        try:
            app.DoCmd.Close(AC_FORM, form_name, 2)  # acSaveNo
            app.DoCmd.OpenForm(form_name, 1)  # acDesign
            record["reopened_in_design"] = True
        except Exception as exc:  # noqa: BLE001
            record["reopen_error"] = describe_com_error(exc)
        _attempt("design-reopen")
    return record


def _build_access_phase(db_path: Path, sources: dict[str, Path], out_dir: Path) -> dict[str, Any]:
    import pythoncom
    import win32com.client

    report: dict[str, Any] = {"phase": "access"}
    baseline = baseline_pids()
    report["baseline_msaccess_pids"] = sorted(baseline)
    access_pid: int | None = None
    access_creation: int | None = None
    observer: WindowObserver | None = None
    app: Any = None
    pythoncom.CoInitialize()
    try:
        app = win32com.client.DispatchEx("Access.Application")
        try:
            hwnd = int(app.hWndAccessApp())
            import win32process

            _thread, pid = win32process.GetWindowThreadProcessId(hwnd)
            access_pid = int(pid)
            capture_method = "hWndAccessApp"
        except Exception as exc:  # noqa: BLE001 - baseline-diff fallback, recorded
            candidates = sorted(new_access_pids(baseline))
            capture_method = "baseline-diff"
            access_pid = candidates[0] if len(candidates) == 1 else None
            report["hwnd_error"] = describe_com_error(exc)
            report["baseline_diff_candidates"] = candidates
        identity = read_process_identity(access_pid) if access_pid else None
        if identity is not None:
            access_creation = identity.creation
        verification: dict[str, Any] = {
            "method": capture_method,
            "access_pid": access_pid,
            "owned": False,
            "reasons": [],
        }
        if access_pid is None:
            verification["reasons"].append("no-pid")
        elif access_pid in baseline:
            verification["reasons"].append("pid-in-baseline")
        elif identity is None:
            verification["reasons"].append("identity-unreadable")
        elif identity.image.casefold() != "msaccess.exe":
            verification["reasons"].append(f"image-{identity.image}")
        else:
            verification["owned"] = True
        report["access_identity"] = {
            "capture_method": capture_method,
            "access_pid": access_pid,
            "access_creation": access_creation,
            "access_image": None if identity is None else identity.image,
        }
        report["identity_verification"] = verification
        write_json_flushed(out_dir / "build_identity.json", {**report["access_identity"], "verification": verification})
        if not verification["owned"]:
            raise RuntimeError(f"Access identity not positively verified; build refused: {verification}")

        for attribute, value in (("Visible", False), ("UserControl", False)):
            try:
                setattr(app, attribute, value)
            except Exception as exc:  # noqa: BLE001
                report[f"{attribute.lower()}_error"] = describe_com_error(exc)

        app.AutomationSecurity = MSO_AUTOMATION_SECURITY_FORCE_DISABLE
        readback = int(app.AutomationSecurity)
        report["security_readback"] = readback
        if readback != MSO_AUTOMATION_SECURITY_FORCE_DISABLE:
            raise RuntimeError(f"AutomationSecurity readback {readback} != force-disable; build refused")

        app.OpenCurrentDatabase(str(db_path))
        report["opened"] = True
        observer = WindowObserver({access_pid})
        observer.start()

        # 1. Module first (raw VBA source).
        app.LoadFromText(AC_MODULE, MODULE_NAME, str(sources["module"]))
        report["module_loaded"] = MODULE_NAME

        # 2. Form with one control: CreateForm returns it open in design view.
        form = app.CreateForm()
        default_form = str(form.Name)
        report["form_default_name"] = default_form
        report["form_control"] = _add_form_control(app, default_form)
        app.DoCmd.Close(AC_FORM, default_form, AC_SAVE_YES)
        app.DoCmd.Rename(FORM_NAME, AC_FORM, default_form)
        report["form_renamed_to"] = FORM_NAME

        # 3. Report (plain).
        report_obj = app.CreateReport()
        default_report = str(report_obj.Name)
        report["report_default_name"] = default_report
        app.DoCmd.Close(AC_REPORT, default_report, AC_SAVE_YES)
        app.DoCmd.Rename(REPORT_NAME, AC_REPORT, default_report)
        report["report_renamed_to"] = REPORT_NAME

        # 4. Macro loaded under a NEUTRAL name, its real text captured BEFORE the rename.
        app.LoadFromText(AC_MACRO, NEUTRAL_MACRO_NAME, str(sources["macro"]))
        captured_path = out_dir / "captured_macro_neutral.txt"
        report["macro_capture"] = safe_call(
            lambda: app.SaveAsText(AC_MACRO, NEUTRAL_MACRO_NAME, str(captured_path))
        )
        captured_text = ""
        if captured_path.exists():
            from t4_common import decode_utf16_bom

            captured_text = decode_utf16_bom(captured_path.read_bytes())
            report["captured_macro_sha256"] = sha256_file(captured_path)
            report["captured_macro_chars"] = len(captured_text)
            report["captured_macro_has_openform"] = "OpenForm" in captured_text and FORM_NAME in captured_text
            report["captured_macro_forbidden_markers_present"] = [
                marker
                for marker in ("RunCode", "Function", "OnLoad", "StartupForm", "VBE")
                if marker.casefold() in captured_text.casefold()
            ]
            if not report["captured_macro_has_openform"]:
                raise RuntimeError(f"neutral macro capture does not contain OpenForm/{FORM_NAME}: {captured_text!r}")
            if report["captured_macro_forbidden_markers_present"]:
                raise RuntimeError(
                    f"neutral macro capture carries forbidden markers: "
                    f"{report['captured_macro_forbidden_markers_present']}"
                )
        else:
            raise RuntimeError("neutral macro SaveAsText capture produced no file")
        app.DoCmd.Rename(MACRO_NAME, AC_MACRO, NEUTRAL_MACRO_NAME)
        report["macro_renamed_to"] = MACRO_NAME

        # No AutoExec/AutoKeys/StartupForm is ever armed. Close without reopening.
        app.CloseCurrentDatabase()
        report["closed"] = True
    finally:
        if observer is not None:
            observer.stop()
            report["windows"] = list(observer.windows)
            report["observer_error"] = observer.error
        if app is not None:
            try:
                app.Quit()
            except Exception:  # noqa: BLE001
                pass
        app = None

        # Reap only our own identity-verified Access, and only if it outlived Quit.
        if access_pid is not None and process_is_alive(access_pid):
            wait_until(lambda: not process_is_alive(access_pid), 20.0)
        if access_pid is not None and process_is_alive(access_pid):
            report["reap"] = terminate_verified_access(
                pid=access_pid,
                creation=access_creation or 0,
                image="MSACCESS.EXE",
                baseline_pids=frozenset(baseline),
                grace_seconds=10.0,
            ).__dict__
        report["survivors_after_build"] = sorted(new_access_pids(baseline))
        pythoncom.CoUninitialize()
    return report


def build(out_dir: Path) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    db_path = out_dir / DB_NAME
    if db_path.exists():
        raise RuntimeError(f"refusing to overwrite existing fixture: {db_path}")

    baseline = baseline_pids()
    sources = _write_text_sources(out_dir)
    ddl_report = _create_dao_database(db_path)
    access_report = _build_access_phase(db_path, sources, out_dir)
    readback = read_database(db_path)

    locks = lock_files(out_dir)
    if locks:
        raise RuntimeError(f"fixture build left Access lock file(s): {locks}")
    if access_report.get("survivors_after_build"):
        raise RuntimeError(f"fixture build left MSACCESS.EXE process(es): {access_report['survivors_after_build']}")
    if not readback.get("ok"):
        raise RuntimeError(f"DAO readback failed: {readback.get('error')}")
    present = readback.get("objects_present") or {}
    missing = [key for key in ("form", "report", "macro", "module", "table") if not present.get(key)]
    if missing:
        raise RuntimeError(f"DAO Containers do not show the fixture objects: missing {missing}")
    control = access_report.get("form_control") or {}
    if not control.get("added"):
        raise RuntimeError(f"form control was not added: {control.get('error')}")

    report = {
        "schema": "v2-content.build/1",
        "fixture": str(db_path),
        "sha256": sha256_file(db_path),
        "bytes": db_path.stat().st_size,
        "baseline_msaccess_pids": sorted(baseline),
        "ddl": ddl_report,
        "access_phase": access_report,
        "dao_readback": readback,
        "objects_present": present,
        "form_control_added": bool(control.get("added")),
        "locks_after_build": locks,
    }
    write_json_flushed(out_dir / "build_report.json", report)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        report = build(args.out_dir)
    except Exception as exc:  # noqa: BLE001 - a build failure is evidence, reported not raised
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=True))
        return 2
    print(
        json.dumps(
            {
                "ok": True,
                "fixture": report["fixture"],
                "sha256": report["sha256"],
                "objects_present": report["objects_present"],
                "form_control_added": report["form_control_added"],
            },
            ensure_ascii=True,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
