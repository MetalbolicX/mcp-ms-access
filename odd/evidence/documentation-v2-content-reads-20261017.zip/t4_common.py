"""Shared safety helpers, constants and error formatting for the T4 content harness.

Throwaway research tooling (ODD ``documentation-workflows-v2``, task **T4**, Specs S2/S5,
preparation only). It lives entirely under ``db/fixtures/e2e-v2-content-<id>/``; no
production file is edited, and the production modules are only *imported* through
``sys.path``.

Safety contract enforced here (the same envelope as the three prior v2 spikes):

* every kill is PID-scoped and creation+image verified: harness-owned Python children
  through :func:`verified_kill_python`, owned Access through the *production* fail-closed
  verifier :func:`ms_access_mcp.application.process_identity.terminate_verified_access`;
  ``/IM`` is never used;
* a pre-existing ``MSACCESS.EXE`` (foreign baseline PID) is never killed;
* the canonical fixtures (``db/fixtures/documentation``, ``db/northwind.accdb``) are
  hashed before and after and are never opened by Access;
* Access opens only a disposable copy under this harness' own scratch directory, and only
  after ``AutomationSecurity`` was set **and read back**;
* no registry / Trust Center / trusted-location change, no synthetic input, and no dialog
  is ever accepted -- windows are observed read-only and recorded.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

SCRATCH_DIR = Path(__file__).resolve().parent
ROOT = SCRATCH_DIR.parents[2]
# The production package is imported (never copied or edited) from the repository source.
for _entry in (str(ROOT), str(ROOT / "src")):
    if _entry not in sys.path:
        sys.path.insert(0, _entry)

from ms_access_mcp.application.process_identity import (  # noqa: E402
    ACCESS_IMAGE_NAME,
    list_msaccess_pids,
    process_is_alive,
    read_process_identity,
    terminate_verified_access,
)

# --- fixture vocabulary -----------------------------------------------------------------
DB_NAME = "content.accdb"
TABLE_NAME = "ContentNotes"
MODULE_NAME = "ContentModule"
FORM_NAME = "frmContent"
FORM_CONTROL_NAME = "txtProbe"
REPORT_NAME = "rptContent"
MACRO_NAME = "mcrContent"
NEUTRAL_MACRO_NAME = "NeutralMacro"
AC_FORM = 2
AC_REPORT = 3
AC_MACRO = 4
AC_MODULE = 5
AC_TEXTBOX = 109
AC_SAVE_YES = 1
DB_LONG = 4
DB_TEXT = 10
DB_VERSION = 128
LOCALE = ";LANGID=0x0409;CP=1252;COUNTRY=0"
# msoAutomationSecurityForceDisable / msoAutomationSecurityLow.
MSO_AUTOMATION_SECURITY_FORCE_DISABLE = 3
MSO_AUTOMATION_SECURITY_LOW = 1

EVIDENCE_DIR = SCRATCH_DIR / "evidence"
SCRATCH_COPY_DIR = SCRATCH_DIR / "scratch"
BASELINE_PIDS_FILE = EVIDENCE_DIR / "baseline_msaccess_pids.json"
HASHES_BEFORE_FILE = EVIDENCE_DIR / "hashes_before.json"
HASHES_AFTER_FILE = EVIDENCE_DIR / "hashes_after.json"
REPORT_FILE = EVIDENCE_DIR / "v2_content_report.json"
SUMMARY_FILE = EVIDENCE_DIR / "summary.json"

# Canonical protection targets: hashed before and after the whole matrix.
CANONICAL_TARGETS = (
    ROOT / "db" / "fixtures" / "documentation",
    ROOT / "db" / "northwind.accdb",
)

CELL_KINDS = ("REFERENCES", "TRUSTREFUSAL", "SAVEASREAD", "POSCTRL")


# --- hashing ----------------------------------------------------------------------------
def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical_hashes() -> dict[str, dict[str, Any]]:
    """Return ``{repo_relative_path: {sha256, bytes}}`` for every canonical target file."""
    result: dict[str, dict[str, Any]] = {}
    for target in CANONICAL_TARGETS:
        files = [target] if target.is_file() else sorted(p for p in target.rglob("*") if p.is_file())
        for path in files:
            result[str(path.relative_to(ROOT)).replace("\\", "/")] = {
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
    return result


def diff_hashes(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_keys = set(before)
    after_keys = set(after)
    changed = sorted(key for key in before_keys & after_keys if before[key] != after[key])
    return {
        "unchanged": not changed and before_keys == after_keys,
        "changed": changed,
        "added": sorted(after_keys - before_keys),
        "removed": sorted(before_keys - after_keys),
    }


# --- io helpers -------------------------------------------------------------------------
def write_json_flushed(path: Path, payload: Any) -> None:
    """Write JSON and fsync it so a parent can read it while a child still runs."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n"
    with path.open("w", encoding="utf-8") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())


def read_json(path: Path, default: Any = None) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return default


def wait_until(predicate: Any, timeout: float, interval: float = 0.25) -> bool:
    """Poll ``predicate`` until True or the bounded timeout expires."""
    deadline = time.monotonic() + max(float(timeout), 0.0)
    while True:
        if predicate():
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(interval)


def lock_files(directory: Path) -> list[str]:
    """Names of Access lock files beside a scratch copy; never deleted by the harness."""
    return sorted(path.name for path in directory.glob("*.laccdb"))


def decode_utf16_bom(raw: bytes) -> str:
    """Decode a SaveAsText export exactly like ``backends/access/vba.py`` (UTF-16-LE BOM)."""
    return raw.decode("utf-16-le", errors="replace").lstrip("\ufeff")


# --- process helpers --------------------------------------------------------------------
def baseline_pids() -> set[int]:
    """Pre-spawn Access baseline through the production enumerator."""
    return list_msaccess_pids()


def new_access_pids(baseline: set[int]) -> set[int]:
    """Access PIDs observed now that were absent from the baseline."""
    return list_msaccess_pids() - set(baseline)


def verified_kill_python(pid: int, creation: int | None) -> dict[str, Any]:
    """PID+creation-scoped ``taskkill /F /PID`` for one harness-owned Python child.

    Fails CLOSED: without a live process whose creation time still equals the recorded one
    and whose image is a Python interpreter, no kill is issued. Never ``/IM``.
    """
    record: dict[str, Any] = {"pid": pid, "expected_creation": creation, "result": "skipped-unverified-no-kill"}
    if not isinstance(pid, int) or pid <= 0 or creation is None:
        record["detail"] = "missing pid or creation; no kill attempted"
        return record
    live = read_process_identity(pid)
    if live is None:
        record["result"] = "already-exited-no-kill"
        return record
    record["observed_creation"] = live.creation
    record["observed_image"] = live.image
    if live.creation != creation:
        record["detail"] = "live creation time does not match the recorded one; no kill attempted"
        return record
    if not live.image.casefold().startswith("python"):
        record["detail"] = f"image {live.image!r} is not a Python interpreter; no kill attempted"
        return record
    completed = subprocess.run(  # noqa: S603 - fixed argv, PID-scoped, never a shell
        ["taskkill", "/F", "/PID", str(pid)], capture_output=True, text=True, timeout=30, check=False
    )
    record["result"] = "killed" if completed.returncode == 0 else "taskkill-failed"
    record["taskkill_returncode"] = completed.returncode
    record["taskkill_stdout"] = completed.stdout.strip()
    record["taskkill_stderr"] = completed.stderr.strip()
    record["exited"] = wait_until(lambda: not process_is_alive(pid), 10.0)
    return record


# --- COM error formatting ---------------------------------------------------------------
def describe_com_error(exc: BaseException) -> dict[str, Any]:
    """Record one exception without losing its COM diagnostic shape.

    ``pythoncom.com_error`` is ``(hr, msg, excepinfo, argerror)`` and ``excepinfo`` is the
    six-tuple ``(wCode, source, description, helpFile, helpContext, scode)``. Every field
    is read defensively so a plain Python exception is still described honestly.
    """
    record: dict[str, Any] = {
        "type": type(exc).__name__,
        "str": str(exc),
        "args": [repr(item) for item in getattr(exc, "args", ())],
        "hresult": None,
        "message": None,
        "excepinfo": None,
        "scode": None,
        "description": None,
        "source": None,
    }
    args = getattr(exc, "args", ())
    if args and isinstance(args[0], int):
        record["hresult"] = args[0]
    if len(args) > 1 and isinstance(args[1], str):
        record["message"] = args[1]
    excepinfo = getattr(exc, "excepinfo", None)
    if excepinfo:
        items = list(excepinfo)
        record["excepinfo"] = [repr(item) for item in items]
        if len(items) > 1 and isinstance(items[1], str):
            record["source"] = items[1]
        if len(items) > 2 and isinstance(items[2], str):
            record["description"] = items[2]
        if len(items) > 5 and isinstance(items[5], int):
            record["scode"] = items[5]
    return record


def safe_call(thunk: Any) -> dict[str, Any]:
    """Run ``thunk`` and return ``{ok, value}`` or ``{ok: False, error: describe_com_error}``."""
    try:
        return {"ok": True, "value": thunk()}
    except Exception as exc:  # noqa: BLE001 - a failed read is evidence, never a crash
        return {"ok": False, "error": describe_com_error(exc)}


# --- read-only dialog observation -------------------------------------------------------
class WindowObserver(threading.Thread):
    """Record (never dismiss) every visible top-level window owned by the target PIDs."""

    def __init__(self, target_pids: set[int]) -> None:
        super().__init__(daemon=True)
        self._targets = set(target_pids)
        self._stop_event = threading.Event()
        self.windows: list[dict[str, Any]] = []
        self.error: str | None = None

    def run(self) -> None:
        try:
            from tests.helpers.dialog_watcher import collect_windows
        except Exception as exc:  # noqa: BLE001 - observation is best-effort, never fatal
            self.error = f"{type(exc).__name__}: {exc}"
            return
        while not self._stop_event.is_set():
            try:
                for window in collect_windows(self._targets):
                    item = {
                        "hwnd": hex(window.hwnd),
                        "owner_pid": window.owner_pid,
                        "owner_image": window.owner_image,
                        "class": window.class_name,
                        "title": window.title,
                        "is_dialog_class": window.class_name == "#32770",
                    }
                    if item not in self.windows:
                        self.windows.append(item)
            except Exception as exc:  # noqa: BLE001 - a sampling error is recorded, not raised
                self.error = f"{type(exc).__name__}: {exc}"
            self._stop_event.wait(0.5)

    def stop(self) -> None:
        self._stop_event.set()
        self.join(timeout=3.0)


__all__ = [name for name in dir() if not name.startswith("_")]
