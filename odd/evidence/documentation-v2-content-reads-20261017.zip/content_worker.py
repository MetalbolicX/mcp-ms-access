"""Run one T4 content-read cell (one Access instance, one disposable copy) in a child.

The parent runner owns the hard timeout, the PID-scoped kill, the DAO observations and the
verdict. This child only drives one Access instance under the requested
``AutomationSecurity`` and records exactly what it observes; it never reads DAO, never
sends keyboard/UI input, and never changes a Trust Center / registry setting. During
graceful shutdown it closes and quits only its own instance; the parent still owns the
kill net.

Cells (``--cell``):

``REFERENCES``   Corrected **1-based** ``Application.References`` enumeration with strictly
                 separated diagnostics: ``Count`` alone in one try/except, then each
                 ``References(i)`` in its own try/except recording the COM error class and
                 ``excepinfo`` (scode/description). The two boundaries are never conflated.
``SAVEASREAD``   ``SaveAsText`` of the fixture form (2), report (3) and macro (4) into this
                 cell's evidence directory, decoded UTF-16-LE-BOM and hashed. The parent
                 separately proves, via DAO Containers, that the objects exist, so a failed
                 export is not vacuous.
``TRUSTREFUSAL`` Probe ``CurrentProject`` and ``VBE``/``VBProjects`` access in their own
                 try/except and record the exact COM error class. ``trust_enabled_observed``
                 is derived from whether the VBProject reads succeed; the host's actual
                 either-way outcome is recorded honestly and **nothing** is toggled.
``POSCTRL``      The same SaveAsText procedure under low security (1), used only when every
                 force-disable export failed, to distinguish "blocked by ForceDisable" from
                 a harness defect.

Exit codes: 0 cell completed | 10 bad args | 11 scratch-path refusal |
12 Access identity not verified (no open) | 13 open failed | 14 fatal |
15 security readback mismatch.
"""

from __future__ import annotations

import argparse
import os
import sys
import threading
import time
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from t4_common import (  # noqa: E402
    AC_FORM,
    AC_MACRO,
    AC_REPORT,
    DB_NAME,
    FORM_NAME,
    MACRO_NAME,
    MSO_AUTOMATION_SECURITY_FORCE_DISABLE,
    MSO_AUTOMATION_SECURITY_LOW,
    REPORT_NAME,
    SCRATCH_COPY_DIR,
    WindowObserver,
    decode_utf16_bom,
    describe_com_error,
    lock_files,
    new_access_pids,
    process_is_alive,
    read_process_identity,
    safe_call,
    sha256_text,
    wait_until,
    write_json_flushed,
)

EXIT_OK = 0
EXIT_BAD_ARGS = 10
EXIT_PATH_REFUSED = 11
EXIT_IDENTITY_UNVERIFIED = 12
EXIT_OPEN_FAILED = 13
EXIT_FATAL = 14
EXIT_SECURITY_MISMATCH = 15

CELLS = ("REFERENCES", "SAVEASREAD", "TRUSTREFUSAL", "POSCTRL")
EXPORT_TARGETS = (("form", AC_FORM, FORM_NAME), ("report", AC_REPORT, REPORT_NAME), ("macro", AC_MACRO, MACRO_NAME))


class State:
    """Incremental JSON state so a blocked COM call still leaves readable evidence."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.lock = threading.Lock()
        self.payload: dict[str, Any] = {"schema": "v2-content.cell/1", "windows": []}

    def record(self, **kwargs: Any) -> None:
        with self.lock:
            self.payload.update(kwargs)
            write_json_flushed(self.path, self.payload)

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return dict(self.payload)


def _path_guard(db_path: Path) -> str | None:
    root = SCRATCH_COPY_DIR.resolve()
    resolved = db_path.resolve()
    if not resolved.is_relative_to(root):
        return f"path {resolved} is outside the harness scratch root {root}"
    if resolved.name != DB_NAME:
        return f"path {resolved} is not the disposable copy name {DB_NAME!r}"
    if not resolved.is_file():
        return f"path {resolved} does not exist"
    return None


def _verify_identity(access_pid: int | None, identity: Any, baseline: set[int]) -> dict[str, Any]:
    verification: dict[str, Any] = {"access_pid": access_pid, "owned": False, "reasons": []}
    if access_pid is None:
        verification["reasons"].append("no-pid")
    elif access_pid in baseline:
        verification["reasons"].append("pid-in-baseline")
    elif identity is None:
        verification["reasons"].append("identity-unreadable")
    elif identity.image.casefold() != "msaccess.exe":
        verification["reasons"].append(f"image-{identity.image}")
    else:
        verification["owned"] = True
    return verification


# --- cells ------------------------------------------------------------------------------
def probe_references(app: Any, state: State) -> None:
    """1-based References enumeration with Count and Item diagnostics strictly separated."""
    references: dict[str, Any] = {"probe": "Application.References", "indexing": "1-based", "items": []}
    collection: Any = None
    try:
        collection = app.References
        references["collection_ok"] = True
    except Exception as exc:  # noqa: BLE001
        references["collection_ok"] = False
        references["collection_error"] = describe_com_error(exc)
        state.record(references=references)
        return

    # Count alone: its own boundary.
    count: int | None = None
    try:
        count = int(collection.Count)
        references["count"] = count
    except Exception as exc:  # noqa: BLE001
        references["count_error"] = describe_com_error(exc)

    # Each item alone: its own boundary, recording excepinfo (scode/description).
    if count is not None:
        for ordinal in range(1, count + 1):
            item: dict[str, Any] = {"ordinal": ordinal}
            try:
                reference = collection(ordinal)
                item["ok"] = True
                item["name"] = safe_call(lambda reference=reference: str(reference.Name))
                item["full_path"] = safe_call(lambda reference=reference: str(reference.FullPath))
                item["guid"] = safe_call(lambda reference=reference: str(reference.Guid))
                item["major"] = safe_call(lambda reference=reference: int(reference.Major))
                item["minor"] = safe_call(lambda reference=reference: int(reference.Minor))
                item["built_in"] = safe_call(lambda reference=reference: bool(reference.BuiltIn))
            except Exception as exc:  # noqa: BLE001 - a refused item never aborts the enumeration
                item["ok"] = False
                item["error"] = describe_com_error(exc)
            references["items"].append(item)

    references["count_recorded"] = "count" in references or "count_error" in references
    references["items_all_recorded"] = count is None or len(references["items"]) == count
    references["readable"] = isinstance(references.get("count"), int) and all(
        item.get("ok") for item in references["items"]
    )
    state.record(references=references)


def probe_save_as_text(app: Any, out_dir: Path, state: State) -> None:
    """Export form/report/macro via SaveAsText, decode UTF-16-LE BOM, hash each export."""
    exports: list[dict[str, Any]] = []
    for label, ac_type, object_name in EXPORT_TARGETS:
        destination = out_dir / f"export_{label}.txt"
        entry: dict[str, Any] = {
            "label": label,
            "ac_type": ac_type,
            "object_name": object_name,
            "path": str(destination),
            "ok": False,
        }
        try:
            app.SaveAsText(ac_type, object_name, str(destination))
            entry["ok"] = True
        except Exception as exc:  # noqa: BLE001 - a failed export is recorded, not fatal
            entry["error"] = describe_com_error(exc)
        if destination.exists():
            raw = destination.read_bytes()
            entry["bytes"] = len(raw)
            entry["has_utf16_bom"] = raw[:2] == b"\xff\xfe"
            text = decode_utf16_bom(raw)
            entry["chars"] = len(text)
            entry["sha256"] = sha256_text(text)
            entry["snippet"] = text[:200]
        else:
            entry["file_written"] = False
        exports.append(entry)
    state.record(
        exports=exports,
        exports_ok=[entry["label"] for entry in exports if entry.get("ok") and entry.get("file_written", True)],
    )


def probe_trust(app: Any, state: State) -> None:
    """Probe CurrentProject/VBE/VBProjects without changing any setting."""
    trust: dict[str, Any] = {"probe": "trust-refusal", "settings_changed": False}

    # CurrentProject in its own boundary.
    try:
        current = app.CurrentProject
        trust["currentproject_ok"] = True
        trust["currentproject_name"] = safe_call(lambda: str(current.Name))
    except Exception as exc:  # noqa: BLE001
        trust["currentproject_ok"] = False
        trust["currentproject_error"] = describe_com_error(exc)

    # VBE access in its own boundary.
    vbe: Any = None
    try:
        vbe = app.VBE
        trust["vbe_ok"] = True
    except Exception as exc:  # noqa: BLE001
        trust["vbe_ok"] = False
        trust["vbe_error"] = describe_com_error(exc)

    count: int | None = None
    if vbe is not None:
        try:
            count = int(vbe.VBProjects.Count)
            trust["vbprojects_count"] = count
        except Exception as exc:  # noqa: BLE001
            trust["vbprojects_count_error"] = describe_com_error(exc)
        if count:
            projects: list[dict[str, Any]] = []
            for ordinal in range(1, count + 1):
                project: dict[str, Any] = {"ordinal": ordinal}
                try:
                    vb_project = vbe.VBProjects(ordinal)
                    project["ok"] = True
                    project["name"] = safe_call(lambda vb_project=vb_project: str(vb_project.Name))
                    project["components_count"] = safe_call(
                        lambda vb_project=vb_project: int(vb_project.VBComponents.Count)
                    )
                except Exception as exc:  # noqa: BLE001 - per-project boundary
                    project["ok"] = False
                    project["error"] = describe_com_error(exc)
                projects.append(project)
            trust["vbprojects"] = projects

    trust["trust_enabled_observed"] = bool(vbe is not None and isinstance(count, int) and count > 0)
    trust["outcome_kind"] = "observed" if trust["trust_enabled_observed"] else "unavailable-degraded"
    state.record(trust=trust)


# --- run --------------------------------------------------------------------------------
def run(args: argparse.Namespace) -> int:
    import pythoncom
    import win32com.client

    db_path = Path(args.db)
    refusal = _path_guard(db_path)
    if refusal is not None:
        print(f"PATH_REFUSED: {refusal}", file=sys.stderr)
        return EXIT_PATH_REFUSED
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    baseline = {int(part) for part in args.baseline_pids.split(",") if part.strip().isdigit()}
    security = int(args.security)

    state = State(out_dir / "result.json")
    child_identity = read_process_identity(os.getpid())
    state.record(
        cell=args.cell,
        security_requested=security,
        db=str(db_path.resolve()),
        baseline_msaccess_pids=sorted(baseline),
        child_pid=os.getpid(),
        child_identity=None if child_identity is None else child_identity.__dict__,
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
    )
    write_json_flushed(
        out_dir / "child_identity.json",
        {"child_pid": os.getpid(), "identity": None if child_identity is None else child_identity.__dict__},
    )

    observer: WindowObserver | None = None
    app: Any = None
    access_pid: int | None = None
    access_creation: int | None = None
    pythoncom.CoInitialize()
    try:
        app = win32com.client.DispatchEx("Access.Application")
        try:
            hwnd = int(app.hWndAccessApp())
            import win32process

            _thread, pid = win32process.GetWindowThreadProcessId(hwnd)
            access_pid = int(pid)
            capture_method = "hWndAccessApp"
        except Exception as exc:  # noqa: BLE001 - baseline-diff fallback, recorded
            candidates = sorted(new_access_pids(baseline))
            capture_method = "baseline-diff"
            access_pid = candidates[0] if len(candidates) == 1 else None
            state.record(hwnd_error=describe_com_error(exc), baseline_diff_candidates=candidates)
        identity = read_process_identity(access_pid) if access_pid else None
        if identity is not None:
            access_creation = identity.creation
        verification = {"method": capture_method, **_verify_identity(access_pid, identity, baseline)}
        access_identity = {
            "capture_method": capture_method,
            "access_pid": access_pid,
            "access_creation": access_creation,
            "access_image": None if identity is None else identity.image,
        }
        state.record(access_identity=access_identity, identity_verification=verification)
        write_json_flushed(out_dir / "identity.json", {**access_identity, "verification": verification})
        if not verification["owned"]:
            state.record(aborted="Access identity not positively verified; open refused")
            return EXIT_IDENTITY_UNVERIFIED

        observer = WindowObserver({access_pid})
        observer.start()
        state.record(observer_started=True)

        for attribute, value in (("Visible", False), ("UserControl", False)):
            try:
                setattr(app, attribute, value)
            except Exception as exc:  # noqa: BLE001
                state.record(**{f"{attribute.lower()}_error": describe_com_error(exc)})

        app.AutomationSecurity = security
        readback = int(app.AutomationSecurity)
        state.record(security_readback=readback, security_readback_matches=(readback == security))
        if readback != security:
            state.record(aborted="AutomationSecurity readback mismatch; open refused")
            return EXIT_SECURITY_MISMATCH

        open_started = time.monotonic()
        try:
            app.OpenCurrentDatabase(str(db_path.resolve()))
            state.record(open_ok=True, open_seconds=round(time.monotonic() - open_started, 3))
        except Exception as exc:  # noqa: BLE001 - a failed open is evidence
            state.record(
                open_ok=False,
                open_seconds=round(time.monotonic() - open_started, 3),
                open_error=describe_com_error(exc),
            )
            return EXIT_OPEN_FAILED
        state.record(access_version=safe_call(lambda: str(app.Version)))
        state.record(lock_file_present_after_open=lock_files(db_path.resolve().parent))

        if args.cell == "REFERENCES":
            probe_references(app, state)
        elif args.cell in ("SAVEASREAD", "POSCTRL"):
            probe_save_as_text(app, out_dir, state)
        elif args.cell == "TRUSTREFUSAL":
            probe_trust(app, state)

        # Graceful shutdown of *our own* instance; the parent still owns the kill net.
        try:
            app.CloseCurrentDatabase()
            state.record(close_current_ok=True)
        except Exception as exc:  # noqa: BLE001
            state.record(close_current_ok=False, close_error=describe_com_error(exc))
        try:
            app.Quit()
            state.record(quit_ok=True)
        except Exception as exc:  # noqa: BLE001
            state.record(quit_ok=False, quit_error=describe_com_error(exc))
        exited = wait_until(lambda: not process_is_alive(access_pid), 20.0)
        state.record(access_exited_after_quit=exited, access_exit_seconds=round(time.monotonic() - open_started, 3))
        app = None
        return EXIT_OK
    finally:
        if observer is not None:
            observer.stop()
            state.record(windows=list(observer.windows), observer_error=observer.error)
        if app is not None:
            for action in ("CloseCurrentDatabase", "Quit"):
                try:
                    getattr(app, action)()
                except Exception:  # noqa: BLE001 - teardown never masks the outcome
                    pass
        app = None
        state.record(locks_after=lock_files(db_path.resolve().parent), finished_at=time.strftime("%Y-%m-%dT%H:%M:%S"))
        try:
            pythoncom.CoUninitialize()
        except Exception:  # noqa: BLE001 - already uninitialized on the happy path
            pass


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--cell", required=True, choices=CELLS)
    parser.add_argument("--db", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--baseline-pids", default="")
    parser.add_argument("--security", type=int, default=MSO_AUTOMATION_SECURITY_FORCE_DISABLE)
    args = parser.parse_args(argv)
    if args.security not in (MSO_AUTOMATION_SECURITY_FORCE_DISABLE, MSO_AUTOMATION_SECURITY_LOW):
        print(f"only security 3 (force-disable) or 1 (low) is supported, got {args.security}", file=sys.stderr)
        return EXIT_BAD_ARGS
    try:
        code = run(args)
    except Exception as exc:  # noqa: BLE001 - a crash is evidence, not silence
        try:
            write_json_flushed(Path(args.out) / "fatal.json", {"fatal": f"{type(exc).__name__}: {exc}"})
        except Exception:  # noqa: BLE001
            pass
        print(f"CONTENT_WORKER_FATAL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return EXIT_FATAL
    print(f"CONTENT_WORKER_OK cell={args.cell} security={args.security} exit={code}", file=sys.stderr)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
