"""Job Object ownership experiment for a COM-launched (``DispatchEx``) MSACCESS.EXE.

T3 research tooling, not production code. Windows Job Objects with
``JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`` are the kernel-level alternative to a userspace
kill net: the kernel terminates every job member when the *last handle to the job* is
closed, including when the only holder dies without running cleanup code. The question
this harness answers is whether a Python supervisor can put a COM-activated
(``DispatchEx``) ``MSACCESS.EXE`` into such a job at all, and whether that containment
survives the supervisor's death.

Modes:

``close-after-assign``   create one job, set ``JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`` (and
                         no breakaway flag), ``DispatchEx`` Access, assign it, prove
                         membership, open the disposable copy, then close the last job
                         handle and observe whether Access dies.
``sacrificial-parent``   identical assignment, then hold the job handle and block until
                         the runner hard-kills this exact process. The kernel must close
                         the handle and fire ``KILL_ON_JOB_CLOSE``.

The containment job deliberately carries **no** breakaway flag: a member that could break
away would escape kill-on-close. :func:`contain_common.breakaway_probe` records host
capability separately on a throwaway job.

Exit codes: 0 ok | 15 security readback mismatch | 20 job assignment failed (recorded
limitation, no watchdog escalation) | 21 kill-on-close did not terminate Access |
22 Access identity not verified (no armed open) | 23 fatal | 24 scratch-path refusal |
25 holding budget exhausted without being killed.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from contain_common import (  # noqa: E402
    ARMED_DB_NAME,
    JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE,
    MSO_AUTOMATION_SECURITY_FORCE_DISABLE,
    SCRATCH_COPY_DIR,
    WindowObserver,
    assign_pid_to_job,
    breakaway_probe,
    close_job,
    create_job,
    lock_files,
    new_access_pids,
    process_in_any_job,
    process_is_alive,
    query_job_active_processes,
    query_job_limit_flags,
    read_process_identity,
    set_job_limit_flags,
    wait_until,
    write_json_flushed,
)

MODES = ("close-after-assign", "sacrificial-parent")

EXIT_OK = 0
EXIT_SECURITY_MISMATCH = 15
EXIT_ASSIGN_FAILED = 20
EXIT_KILL_ON_CLOSE_REFUTED = 21
EXIT_IDENTITY_UNVERIFIED = 22
EXIT_FATAL = 23
EXIT_PATH_REFUSED = 24
EXIT_HOLD_BUDGET_EXHAUSTED = 25


def _path_guard(db_path: Path) -> str | None:
    root = SCRATCH_COPY_DIR.resolve()
    resolved = db_path.resolve()
    if not resolved.is_relative_to(root):
        return f"path {resolved} is outside the harness scratch root {root}"
    if resolved.name != ARMED_DB_NAME:
        return f"path {resolved} is not the disposable copy name {ARMED_DB_NAME!r}"
    if not resolved.is_file():
        return f"path {resolved} does not exist"
    return None


def run(args: argparse.Namespace) -> int:
    import pythoncom
    import win32com.client

    db_path = Path(args.db)
    refusal = _path_guard(db_path)
    if refusal is not None:
        print(f"PATH_REFUSED: {refusal}", file=sys.stderr)
        return EXIT_PATH_REFUSED
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    baseline_pids = {int(part) for part in args.baseline_pids.split(",") if part.strip().isdigit()}

    state: dict[str, Any] = {
        "schema": "v2-containment.job-supervisor/1",
        "mode": args.mode,
        "db": str(db_path.resolve()),
        "baseline_msaccess_pids": sorted(baseline_pids),
        "supervisor_real_pid": os.getpid(),
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }
    supervisor_identity = read_process_identity(os.getpid())
    state["supervisor_creation"] = None if supervisor_identity is None else supervisor_identity.creation
    state["supervisor_image"] = None if supervisor_identity is None else supervisor_identity.image
    state["breakaway_probe"] = breakaway_probe()

    def commit(patch: dict[str, Any] | None = None) -> None:
        if patch:
            state.update(patch)
        write_json_flushed(out_dir / "state.json", state)

    job_handle: int | None = None
    app: Any = None
    observer: WindowObserver | None = None
    access_pid: int | None = None
    pythoncom.CoInitialize()
    try:
        job_handle = create_job()
        state["job_created"] = True
        limit = set_job_limit_flags(job_handle, JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE)
        state["kill_on_job_close_limit"] = limit
        if not limit.get("set_ok"):
            state["mode_outcome"] = "job-limit-set-failed"
            commit()
            return EXIT_ASSIGN_FAILED

        app = win32com.client.DispatchEx("Access.Application")
        try:
            hwnd = int(app.hWndAccessApp())
            import win32process

            _thread, pid = win32process.GetWindowThreadProcessId(hwnd)
            access_pid = int(pid)
            capture_method = "hWndAccessApp"
        except Exception as exc:  # noqa: BLE001 - baseline-diff candidate, still verified
            candidates = sorted(new_access_pids(baseline_pids))
            capture_method = "baseline-diff"
            access_pid = candidates[0] if len(candidates) == 1 else None
            state["hwnd_error"] = f"{type(exc).__name__}: {exc}"
            state["baseline_diff_candidates"] = candidates
        identity = read_process_identity(access_pid) if access_pid else None
        verification: dict[str, Any] = {
            "method": capture_method,
            "access_pid": access_pid,
            "owned": False,
            "reasons": [],
        }
        if access_pid is None:
            verification["reasons"].append("no-pid")
        elif access_pid in baseline_pids:
            verification["reasons"].append("pid-in-baseline")
        elif identity is None:
            verification["reasons"].append("identity-unreadable")
        elif identity.image.casefold() != "msaccess.exe":
            verification["reasons"].append(f"image-{identity.image}")
        else:
            verification["owned"] = True
        if identity is not None:
            verification["access_creation"] = identity.creation
            verification["access_image"] = identity.image
        state["access_identity"] = {
            "capture_method": capture_method,
            "access_pid": access_pid,
            "access_creation": None if identity is None else identity.creation,
            "access_image": None if identity is None else identity.image,
        }
        state["identity_verification"] = verification
        state["access_in_any_job_before_assign"] = (
            None if access_pid is None else process_in_any_job(access_pid)
        )
        commit()
        if not verification["owned"]:
            state["aborted"] = "Access identity not positively verified; assignment refused"
            commit()
            return EXIT_IDENTITY_UNVERIFIED

        assignment = assign_pid_to_job(job_handle, access_pid)
        assignment["job_limit_flags_readback"] = query_job_limit_flags(job_handle)
        assignment["job_active_processes"] = query_job_active_processes(job_handle)
        state["job_assignment"] = assignment
        state["access_in_any_job_after_assign"] = process_in_any_job(access_pid)
        commit()
        if not assignment.get("assigned") or not assignment.get("is_process_in_job"):
            # Cell (c): assignment refused. Recorded as a limitation; no watchdog
            # escalation, no alternative containment is invented here.
            state["mode_outcome"] = "assignment-failed-limitation"
            commit()
            _graceful_quit(app)
            return EXIT_ASSIGN_FAILED

        observer = WindowObserver({access_pid})
        observer.start()
        for attribute, value in (("Visible", False), ("UserControl", False)):
            try:
                setattr(app, attribute, value)
            except Exception as exc:  # noqa: BLE001
                state[f"{attribute.lower()}_error"] = f"{type(exc).__name__}: {exc}"
        app.AutomationSecurity = MSO_AUTOMATION_SECURITY_FORCE_DISABLE
        readback = int(app.AutomationSecurity)
        state["security_readback"] = readback
        if readback != MSO_AUTOMATION_SECURITY_FORCE_DISABLE:
            state["mode_outcome"] = "security-readback-mismatch"
            commit()
            _graceful_quit(app)
            return EXIT_SECURITY_MISMATCH
        try:
            app.OpenCurrentDatabase(str(db_path.resolve()))
            state["armed_open_ok"] = True
        except Exception as exc:  # noqa: BLE001
            state["armed_open_ok"] = False
            state["armed_open_error"] = f"{type(exc).__name__}: {exc}"
        state["lock_file_present_after_open"] = lock_files(db_path.resolve().parent)
        state["job_active_processes_after_open"] = query_job_active_processes(job_handle)
        commit()

        if args.mode == "close-after-assign":
            return _close_after_assign(job_handle, access_pid, state, commit, observer)

        # sacrificial-parent: hold the only job handle and block until hard-killed.
        state["phase"] = "holding-job-handle"
        commit()
        deadline = time.monotonic() + args.hold_seconds
        while time.monotonic() < deadline:
            time.sleep(0.5)
            if observer.windows:
                state["windows"] = list(observer.windows)
                write_json_flushed(out_dir / "state.json", state)
        state["phase"] = "hold-budget-exhausted-without-kill"
        state["mode_outcome"] = "hold-budget-exhausted"
        commit()
        _graceful_quit(app)
        return EXIT_HOLD_BUDGET_EXHAUSTED
    finally:
        if observer is not None:
            observer.stop()
            state["windows"] = list(observer.windows)
            state["observer_error"] = observer.error
        state["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        commit()
        if job_handle is not None:
            close_job(job_handle)
        app = None
        try:
            pythoncom.CoUninitialize()
        except Exception:  # noqa: BLE001 - already uninitialized on a returning path
            pass


def _close_after_assign(
    job_handle: int,
    access_pid: int,
    state: dict[str, Any],
    commit: Any,
    observer: WindowObserver,
) -> int:
    """Close the last job handle and observe whether kill-on-close terminates Access."""
    before = query_job_active_processes(job_handle)
    closed = close_job(job_handle)
    started = time.monotonic()
    died = wait_until(lambda: not process_is_alive(access_pid), 20.0)
    observer.stop()
    outcome = "assigned-kill-on-close-verified" if died else "assigned-kill-on-close-refuted"
    commit(
        {
            "job_active_processes_before_close": before,
            "job_handle_closed": closed,
            "kill_on_close_access_died": died,
            "kill_on_close_seconds": round(time.monotonic() - started, 3),
            "access_alive_after_close": process_is_alive(access_pid),
            "supervisor_survived": True,
            "windows": list(observer.windows),
            "observer_error": observer.error,
            "lock_files_after": lock_files(Path(state["db"]).parent),
            "mode_outcome": outcome,
        }
    )
    # Access is dead: releasing the dangling COM proxy at interpreter shutdown adds no
    # information, so exit deterministically with the recorded outcome.
    os._exit(EXIT_OK if died else EXIT_KILL_ON_CLOSE_REFUTED)


def _graceful_quit(app: Any) -> None:
    """Best-effort graceful close of *our own* instance; never a kill, never foreign."""
    for action in ("CloseCurrentDatabase", "Quit"):
        try:
            getattr(app, action)()
        except Exception:  # noqa: BLE001 - teardown never masks the recorded outcome
            pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", required=True, choices=MODES)
    parser.add_argument("--db", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--baseline-pids", default="")
    parser.add_argument("--hold-seconds", type=float, default=300.0)
    args = parser.parse_args()
    try:
        return run(args)
    except Exception as exc:  # noqa: BLE001 - a crash is evidence, not silence
        try:
            write_json_flushed(Path(args.out) / "fatal.json", {"fatal": f"{type(exc).__name__}: {exc}"})
        except Exception:  # noqa: BLE001
            pass
        import traceback

        traceback.print_exc()
        print(f"JOB_SUPERVISOR_FATAL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return EXIT_FATAL


if __name__ == "__main__":
    raise SystemExit(main())
