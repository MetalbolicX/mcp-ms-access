"""Shared safety helpers and Job Object primitives for the T3 containment harness.

Throwaway research tooling (ODD T3, S2/S5 preparation), not production code. It lives
entirely under ``db/fixtures/e2e-v2-contain-<id>/``; no production file is edited and the
production modules are only *imported* through ``sys.path``.

Safety contract enforced here (the same envelope as the two prior v2 spikes):

* every kill is PID-scoped and creation+image verified: Python children through
  :func:`verified_kill_python`, owned Access through the *production* fail-closed
  verifier :func:`ms_access_mcp.application.process_identity.terminate_verified_access`;
  ``/IM`` is never used;
* a pre-existing ``MSACCESS.EXE`` (foreign baseline PID) is never killed;
* the canonical fixtures (``db/fixtures/documentation``, ``db/northwind.accdb``) are
  hashed before and after and are never opened by Access;
* Access opens only a disposable copy under this harness' own scratch directory;
* no registry / Trust Center / trusted-location change, no synthetic input, and no dialog
  is ever accepted -- windows are observed read-only and recorded.
"""

from __future__ import annotations

import ctypes
import hashlib
import io
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

SCRATCH_DIR = Path(__file__).resolve().parent
ROOT = SCRATCH_DIR.parents[2]
# The production package is imported (never copied or edited) from the repository source.
for _entry in (str(ROOT), str(ROOT / "src")):
    if _entry not in sys.path:
        sys.path.insert(0, _entry)

from ms_access_mcp.application.process_identity import (  # noqa: E402
    ACCESS_IMAGE_NAME,
    list_msaccess_pids,
    process_is_alive,
    read_process_identity,
    terminate_verified_access,
)

ARMED_DB_NAME = "armed.accdb"
EVIDENCE_DIR = SCRATCH_DIR / "evidence"
SCRATCH_COPY_DIR = SCRATCH_DIR / "scratch"
BASELINE_PIDS_FILE = EVIDENCE_DIR / "baseline_msaccess_pids.json"
HASHES_BEFORE_FILE = EVIDENCE_DIR / "hashes_before.json"
HASHES_AFTER_FILE = EVIDENCE_DIR / "hashes_after.json"
REPORT_FILE = EVIDENCE_DIR / "v2_containment_report.json"
SUMMARY_FILE = EVIDENCE_DIR / "summary.json"

# Canonical protection targets: hashed before and after the whole matrix.
CANONICAL_TARGETS = (
    ROOT / "db" / "fixtures" / "documentation",
    ROOT / "db" / "northwind.accdb",
)

# --- fixture vocabulary -----------------------------------------------------------------
PROBE_TABLE = "ContainerProbe"
PROBE_TABLE_DDL = (
    f"CREATE TABLE [{PROBE_TABLE}] ([ItemID] LONG NOT NULL, [Label] TEXT(50), "
    f"CONSTRAINT [PK_{PROBE_TABLE}] PRIMARY KEY ([ItemID]))"
)
PROBE_TABLE_INSERT = f"INSERT INTO [{PROBE_TABLE}] ([ItemID], [Label]) VALUES (1, 'containment')"
DB_VERSION = 128
LOCALE = ";LANGID=0x0409;CP=1252;COUNTRY=0"
MSO_AUTOMATION_SECURITY_FORCE_DISABLE = 3


# --- hashing ----------------------------------------------------------------------------
def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_hashes() -> dict[str, dict[str, Any]]:
    """Return ``{repo_relative_path: {sha256, bytes}}`` for every canonical target file."""
    result: dict[str, dict[str, Any]] = {}
    for target in CANONICAL_TARGETS:
        files = [target] if target.is_file() else sorted(p for p in target.rglob("*") if p.is_file())
        for path in files:
            result[str(path.relative_to(ROOT)).replace("\\", "/")] = {
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
    return result


def diff_hashes(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_keys = set(before)
    after_keys = set(after)
    changed = sorted(key for key in before_keys & after_keys if before[key] != after[key])
    return {
        "unchanged": not changed and before_keys == after_keys,
        "changed": changed,
        "added": sorted(after_keys - before_keys),
        "removed": sorted(before_keys - after_keys),
    }


# --- io helpers -------------------------------------------------------------------------
def write_json_flushed(path: Path, payload: Any) -> None:
    """Write JSON and fsync it so the runner can read it while a child still runs."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n"
    with path.open("w", encoding="utf-8") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())


def read_json(path: Path, default: Any = None) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return default


def wait_until(predicate: Any, timeout: float, interval: float = 0.25) -> bool:
    """Poll ``predicate`` until True or the bounded timeout expires."""
    deadline = time.monotonic() + max(float(timeout), 0.0)
    while True:
        if predicate():
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(interval)


def lock_files(directory: Path) -> list[str]:
    """Names of Access lock files beside a scratch copy; never deleted by the harness."""
    return sorted(path.name for path in directory.glob("*.laccdb"))


# --- process helpers --------------------------------------------------------------------
def baseline_pids() -> set[int]:
    """Pre-spawn Access baseline through the production enumerator."""
    return list_msaccess_pids()


def new_access_pids(baseline: set[int]) -> set[int]:
    """Access PIDs observed now that were absent from the baseline."""
    return list_msaccess_pids() - set(baseline)


def verified_kill_python(pid: int, creation: int | None) -> dict[str, Any]:
    """PID+creation-scoped ``taskkill /F /PID`` for one harness-owned Python child.

    Fails CLOSED: without a live process whose creation time still equals the recorded
    one, no kill is issued. Never ``/IM``, never an image-name kill, and the image is
    checked to be a Python interpreter, not anything else.
    """
    record: dict[str, Any] = {"pid": pid, "expected_creation": creation, "result": "skipped-unverified-no-kill"}
    if not isinstance(pid, int) or pid <= 0 or creation is None:
        record["detail"] = "missing pid or creation; no kill attempted"
        return record
    live = read_process_identity(pid)
    if live is None:
        record["result"] = "already-exited-no-kill"
        return record
    record["observed_creation"] = live.creation
    record["observed_image"] = live.image
    if live.creation != creation:
        record["detail"] = "live creation time does not match the recorded one; no kill attempted"
        return record
    if not live.image.casefold().startswith("python"):
        record["detail"] = f"image {live.image!r} is not a Python interpreter; no kill attempted"
        return record
    completed = subprocess.run(  # noqa: S603 - fixed argv, PID-scoped, never a shell
        ["taskkill", "/F", "/PID", str(pid)], capture_output=True, text=True, timeout=30, check=False
    )
    record["result"] = "killed" if completed.returncode == 0 else "taskkill-failed"
    record["taskkill_returncode"] = completed.returncode
    record["taskkill_stdout"] = completed.stdout.strip()
    record["taskkill_stderr"] = completed.stderr.strip()
    record["exited"] = wait_until(lambda: not process_is_alive(pid), 10.0)
    return record


class TeeBinary:
    """Write-through mirror: forwards bytes to the real stream and keeps an exact copy."""

    def __init__(self, real: Any) -> None:
        self._real = real
        self.captured = bytearray()

    def write(self, data: Any) -> int:
        payload = bytes(data)
        self.captured.extend(payload)
        if self._real is not None:
            self._real.write(payload)
        return len(payload)

    def flush(self) -> None:
        if self._real is not None:
            self._real.flush()


# --- read-only dialog observation -------------------------------------------------------
class WindowObserver(threading.Thread):
    """Record (never dismiss) every visible top-level window owned by the target PIDs."""

    def __init__(self, target_pids: set[int]) -> None:
        super().__init__(daemon=True)
        self._targets = set(target_pids)
        self._stop_event = threading.Event()
        self.windows: list[dict[str, Any]] = []
        self.error: str | None = None

    def run(self) -> None:
        try:
            from tests.helpers.dialog_watcher import collect_windows
        except Exception as exc:  # noqa: BLE001 - observation is best-effort, never fatal
            self.error = f"{type(exc).__name__}: {exc}"
            return
        while not self._stop_event.is_set():
            try:
                for window in collect_windows(self._targets):
                    item = {
                        "hwnd": hex(window.hwnd),
                        "owner_pid": window.owner_pid,
                        "owner_image": window.owner_image,
                        "class": window.class_name,
                        "title": window.title,
                        "is_dialog_class": window.class_name == "#32770",
                    }
                    if item not in self.windows:
                        self.windows.append(item)
            except Exception as exc:  # noqa: BLE001 - a sampling error is recorded, not raised
                self.error = f"{type(exc).__name__}: {exc}"
            self._stop_event.wait(0.5)

    def stop(self) -> None:
        self._stop_event.set()
        self.join(timeout=3.0)


# --- Windows Job Object primitives ------------------------------------------------------
JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
JOB_OBJECT_LIMIT_BREAKAWAY_OK = 0x00000800
JOB_OBJECT_LIMIT_SILENT_BREAKAWAY_OK = 0x00001000
JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS = 9
JOB_OBJECT_BASIC_ACCOUNTING_INFORMATION_CLASS = 1

PROCESS_TERMINATE = 0x0001
PROCESS_SET_QUOTA = 0x0100
PROCESS_QUERY_INFORMATION = 0x0400

_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)


class _LARGE_INTEGER(ctypes.Structure):
    _fields_ = [("QuadPart", ctypes.c_longlong)]


class _IO_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("ReadOperationCount", ctypes.c_ulonglong),
        ("WriteOperationCount", ctypes.c_ulonglong),
        ("OtherOperationCount", ctypes.c_ulonglong),
        ("ReadTransferCount", ctypes.c_ulonglong),
        ("WriteTransferCount", ctypes.c_ulonglong),
        ("OtherTransferCount", ctypes.c_ulonglong),
    ]


class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", _LARGE_INTEGER),
        ("PerJobUserTimeLimit", _LARGE_INTEGER),
        ("LimitFlags", ctypes.c_uint32),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", ctypes.c_uint32),
        ("Affinity", ctypes.c_size_t),
        ("PriorityClass", ctypes.c_uint32),
        ("SchedulingClass", ctypes.c_uint32),
    ]


class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
        ("IoInfo", _IO_COUNTERS),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryUsed", ctypes.c_size_t),
        ("PeakJobMemoryUsed", ctypes.c_size_t),
    ]


class JOBOBJECT_BASIC_ACCOUNTING_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("TotalUserTime", _LARGE_INTEGER),
        ("TotalKernelTime", _LARGE_INTEGER),
        ("ThisPeriodTotalUserTime", _LARGE_INTEGER),
        ("ThisPeriodTotalKernelTime", _LARGE_INTEGER),
        ("TotalPageFaultCount", ctypes.c_uint32),
        ("TotalProcesses", ctypes.c_uint32),
        ("ActiveProcesses", ctypes.c_uint32),
        ("TotalTerminatedProcesses", ctypes.c_uint32),
    ]


def create_job() -> int:
    """Create an unnamed Job Object; raises on failure."""
    handle = _kernel32.CreateJobObjectW(None, None)
    if not handle:
        raise OSError(ctypes.get_last_error(), "CreateJobObjectW failed")
    return int(handle)


def set_job_limit_flags(handle: int, limit_flags: int) -> dict[str, Any]:
    """Set ``BasicLimitInformation.LimitFlags`` and read the value back."""
    info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    info.BasicLimitInformation.LimitFlags = limit_flags
    ok = _kernel32.SetInformationJobObject(
        ctypes.c_void_p(handle),
        JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS,
        ctypes.byref(info),
        ctypes.sizeof(info),
    )
    result = {"limit_flags_requested": limit_flags, "set_ok": bool(ok), "winerror": None}
    if not ok:
        result["winerror"] = ctypes.get_last_error()
        return result
    result["readback"] = query_job_limit_flags(handle)
    return result


def query_job_limit_flags(handle: int) -> int | None:
    info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    returned = ctypes.c_uint32(0)
    ok = _kernel32.QueryInformationJobObject(
        ctypes.c_void_p(handle),
        JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS,
        ctypes.byref(info),
        ctypes.sizeof(info),
        ctypes.byref(returned),
    )
    if not ok:
        return None
    return int(info.BasicLimitInformation.LimitFlags)


def query_job_active_processes(handle: int) -> int | None:
    """``ActiveProcesses`` from basic accounting: a non-vacuous membership check."""
    info = JOBOBJECT_BASIC_ACCOUNTING_INFORMATION()
    returned = ctypes.c_uint32(0)
    ok = _kernel32.QueryInformationJobObject(
        ctypes.c_void_p(handle),
        JOB_OBJECT_BASIC_ACCOUNTING_INFORMATION_CLASS,
        ctypes.byref(info),
        ctypes.sizeof(info),
        ctypes.byref(returned),
    )
    if not ok:
        return None
    return int(info.ActiveProcesses)


def assign_pid_to_job(handle: int, pid: int) -> dict[str, Any]:
    """Assign one PID to the job and report membership honestly."""
    record: dict[str, Any] = {"pid": pid, "assigned": False, "winerror": None, "is_process_in_job": None}
    access = PROCESS_SET_QUOTA | PROCESS_TERMINATE | PROCESS_QUERY_INFORMATION
    process_handle = _kernel32.OpenProcess(access, False, pid)
    if not process_handle:
        record["winerror"] = ctypes.get_last_error()
        record["detail"] = "OpenProcess failed"
        return record
    try:
        ok = _kernel32.AssignProcessToJobObject(ctypes.c_void_p(handle), ctypes.c_void_p(process_handle))
        record["assigned"] = bool(ok)
        if not ok:
            record["winerror"] = ctypes.get_last_error()
        member = ctypes.c_int(0)
        in_job = _kernel32.IsProcessInJob(ctypes.c_void_p(process_handle), ctypes.c_void_p(handle), ctypes.byref(member))
        record["is_process_in_job"] = bool(member.value) if in_job else None
    finally:
        _kernel32.CloseHandle(ctypes.c_void_p(process_handle))
    return record


def process_in_any_job(pid: int) -> bool | None:
    """Whether a PID already belongs to *some* job (informational: breakaway/nesting)."""
    process_handle = _kernel32.OpenProcess(PROCESS_QUERY_INFORMATION, False, pid)
    if not process_handle:
        return None
    try:
        member = ctypes.c_int(0)
        ok = _kernel32.IsProcessInJob(ctypes.c_void_p(process_handle), None, ctypes.byref(member))
        return bool(member.value) if ok else None
    finally:
        _kernel32.CloseHandle(ctypes.c_void_p(process_handle))


def close_job(handle: int) -> bool:
    """Close the last handle to the job; with KILL_ON_JOB_CLOSE this must kill members."""
    return bool(_kernel32.CloseHandle(ctypes.c_void_p(handle)))


def breakaway_probe() -> dict[str, Any]:
    """Probe whether the host accepts breakaway limit flags (a separate throwaway job).

    The containment job never sets a breakaway flag: a member that could break away would
    escape ``KILL_ON_JOB_CLOSE``. This probe only records host capability.
    """
    probe: dict[str, Any] = {}
    try:
        handle = create_job()
    except OSError as exc:
        return {"supported": False, "error": str(exc)}
    try:
        probe["breakaway_ok_set"] = set_job_limit_flags(handle, JOB_OBJECT_LIMIT_BREAKAWAY_OK)
        probe["silent_breakaway_ok_set"] = set_job_limit_flags(
            handle, JOB_OBJECT_LIMIT_SILENT_BREAKAWAY_OK
        )
        probe["supported"] = bool(probe["breakaway_ok_set"].get("set_ok"))
    finally:
        close_job(handle)
    return probe


def sentinel_frame_bytes(pid: int, creation: int, image: str) -> bytes:
    """Exact ``@@ACCESS_IDENTITY@@`` bytes from the production emitter (no COM needed)."""
    from ms_access_mcp.application.documentation_worker import emit_access_identity

    buffer = io.BytesIO()
    emit_access_identity(pid, creation, image, stream=buffer)
    return buffer.getvalue()


__all__ = [
    "ACCESS_IMAGE_NAME",
    "ARMED_DB_NAME",
    "BASELINE_PIDS_FILE",
    "CANONICAL_TARGETS",
    "DB_VERSION",
    "EVIDENCE_DIR",
    "HASHES_AFTER_FILE",
    "HASHES_BEFORE_FILE",
    "JOB_OBJECT_LIMIT_BREAKAWAY_OK",
    "JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE",
    "JOB_OBJECT_LIMIT_SILENT_BREAKAWAY_OK",
    "LOCALE",
    "MSO_AUTOMATION_SECURITY_FORCE_DISABLE",
    "PROBE_TABLE",
    "PROBE_TABLE_DDL",
    "PROBE_TABLE_INSERT",
    "REPORT_FILE",
    "ROOT",
    "SCRATCH_COPY_DIR",
    "SCRATCH_DIR",
    "SUMMARY_FILE",
    "TeeBinary",
    "WindowObserver",
    "assign_pid_to_job",
    "baseline_pids",
    "breakaway_probe",
    "canonical_hashes",
    "close_job",
    "create_job",
    "diff_hashes",
    "JOBOBJECT_BASIC_LIMIT_INFORMATION",
    "JOBOBJECT_EXTENDED_LIMIT_INFORMATION",
    "list_msaccess_pids",
    "lock_files",
    "new_access_pids",
    "process_in_any_job",
    "process_is_alive",
    "query_job_active_processes",
    "query_job_limit_flags",
    "read_json",
    "read_process_identity",
    "sentinel_frame_bytes",
    "set_job_limit_flags",
    "sha256_file",
    "terminate_verified_access",
    "verified_kill_python",
    "wait_until",
    "write_json_flushed",
]
