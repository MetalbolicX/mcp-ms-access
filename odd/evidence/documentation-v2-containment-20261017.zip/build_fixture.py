"""Build the trivial disposable armed fixture used by the containment matrix.

The containment research needs an Access *instantiating* fixture, not an auto-run armed
fixture: the crash/deadline/supervisor-death cells only care whether a real
``MSACCESS.EXE`` survives the supervisor. The fixture is therefore one DAO-created table
with one row -- no VBA, no macro, no startup property, no linked table, and nothing that
runs at startup.

Build discipline (inherited from ``scripts/generate_documentation_fixtures.py``): DAO
``DAO.DBEngine.120`` performs all DDL, COM is initialized and uninitialized around the
build, identifiers are bracketed (the L6 reserved-word lesson), and the build asserts that
it started no surviving ``MSACCESS.EXE`` and left no Access lock file. No
``Access.Application`` instance is created at all.

Usage: ``build_fixture.py --out-dir <dir>`` writes ``<dir>/armed.accdb`` and prints one
JSON build record. Exit codes: 0 ok; 2 build failure.
"""

from __future__ import annotations

import argparse
import gc
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from contain_common import (  # noqa: E402
    ARMED_DB_NAME,
    DB_VERSION,
    LOCALE,
    PROBE_TABLE,
    PROBE_TABLE_DDL,
    PROBE_TABLE_INSERT,
    baseline_pids,
    lock_files,
    new_access_pids,
    sha256_file,
    wait_until,
)


def build(out_dir: Path) -> dict[str, Any]:
    if os.name != "nt":
        msg = "the containment fixture builder requires Windows and ACE DAO"
        raise RuntimeError(msg)
    import pythoncom
    import win32com.client

    out_dir.mkdir(parents=True, exist_ok=True)
    db_path = out_dir / ARMED_DB_NAME
    msaccess_baseline = baseline_pids()
    pythoncom.CoInitialize()
    engine: Any = None
    db: Any = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        db = engine.CreateDatabase(str(db_path), LOCALE, DB_VERSION)
        db.Execute(PROBE_TABLE_DDL, 128)
        db.TableDefs.Refresh()
        tables = sorted(str(db.TableDefs(i).Name) for i in range(db.TableDefs.Count))
        db.Execute(PROBE_TABLE_INSERT, 128)
        db.Close()
        db = None
        gc.collect()
    finally:
        db = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()

    owned = new_access_pids(msaccess_baseline)
    if owned:
        raise RuntimeError(f"fixture build started MSACCESS.EXE process(es): {sorted(owned)}")
    if not wait_until(lambda: not lock_files(out_dir), 10.0):
        raise RuntimeError(f"fixture build left an Access lock file: {lock_files(out_dir)}")
    return {
        "ok": True,
        "db": str(db_path),
        "sha256": sha256_file(db_path),
        "bytes": db_path.stat().st_size,
        "tables": tables,
        "probe_table_present": PROBE_TABLE in tables,
        "baseline_msaccess_pids": sorted(msaccess_baseline),
        "owned_msaccess_started": sorted(owned),
        "lock_files_after": lock_files(out_dir),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Build the disposable containment fixture (DAO only).")
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()
    try:
        record = build(args.out_dir)
    except Exception as exc:  # noqa: BLE001 - a build failure is evidence, reported not raised
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}, ensure_ascii=True))
        return 2
    print(json.dumps(record, ensure_ascii=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
