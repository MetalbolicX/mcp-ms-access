"""Armed (Access-instantiating) scratch worker driven by the *production* kill net.

This is T3 experiment tooling, not production code. ``run_containment.py`` launches it
through the production :class:`ms_access_mcp.application.documentation_runtime.DocumentationRuntime`
injectable ``launcher``, so the deadline, the child reap, and the owned-Access kill net are
exercised exactly as production would exercise them -- only the child is replaced.

Protocol contract (the production worker protocol, no hand-built frames):

* the Access identity is captured fail-closed: PID from ``hWndAccessApp`` ->
  ``GetWindowThreadProcessId``, creation time and image via the production
  :func:`ms_access_mcp.application.process_identity.read_process_identity`;
* the identity must prove ownership (PID absent from the pre-spawn baseline, live
  creation time equal to the captured one, image ``MSACCESS.EXE``) or the worker refuses
  to open any source;
* exactly one flushed ``@@ACCESS_IDENTITY@@`` frame is emitted through the production
  :func:`ms_access_mcp.application.documentation_worker.emit_access_identity`, **before**
  the armed open, so the supervisor can reap Access even if this process is killed;
* only the disposable scratch copy named by ``--db`` is ever opened; any path outside the
  harness scratch root is refused before Access is created;
* no dialog is accepted, no input is synthesized, no registry or Trust Center setting is
  touched. Owned windows are observed read-only and recorded.

Scenarios (``--scenario``):

``CRASH``     open the copy, then ``os._exit(1)`` leaving Access alive. The supervisor must
              raise the pinned non-zero-exit ``Err`` and reap Access by PID.
``HANG``      open the copy, then sleep well past the injected deadline. The supervisor must
              raise the pinned deadline ``Err`` after killing this child, then reap Access.
``GRACEFUL``  open the copy, ``CloseCurrentDatabase`` + ``Quit``, wait for the captured
              Access PID to disappear, then emit one valid minimal
              ``access.documentation.evidence/1`` response and exit 0. The supervisor must
              return ``Ok`` and must not have to kill anything.

Exit codes: 0 clean (GRACEFUL) | 1 CRASH | 10 bad arguments | 11 scratch-path refusal |
12 Access identity not verified (no armed open) | 13 armed open failed |
14 fatal | 15 security readback mismatch | 16 hang budget exhausted without a kill.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from contain_common import (  # noqa: E402
    ARMED_DB_NAME,
    MSO_AUTOMATION_SECURITY_FORCE_DISABLE,
    SCRATCH_COPY_DIR,
    TeeBinary,
    WindowObserver,
    lock_files,
    new_access_pids,
    process_is_alive,
    read_process_identity,
    wait_until,
    write_json_flushed,
)

from ms_access_mcp.application.documentation_worker import (  # noqa: E402
    emit_access_identity,
    encode_response,
)

SCENARIOS = ("CRASH", "HANG", "GRACEFUL")

EXIT_OK = 0
EXIT_CRASH = 1
EXIT_BAD_ARGS = 10
EXIT_PATH_REFUSED = 11
EXIT_IDENTITY_UNVERIFIED = 12
EXIT_OPEN_FAILED = 13
EXIT_FATAL = 14
EXIT_SECURITY_MISMATCH = 15
EXIT_HANG_BUDGET_EXHAUSTED = 16


class _TeeText:
    """Text wrapper over :class:`contain_common.TeeBinary` (mirrors stderr exactly)."""

    def __init__(self, binary: TeeBinary) -> None:
        self._binary = binary

    def write(self, text: str) -> int:
        self._binary.write(text.encode("utf-8", "replace"))
        return len(text)

    def flush(self) -> None:
        self._binary.flush()


def minimal_evidence(db_path: Path, identity: dict[str, Any], app_version: str) -> dict[str, Any]:
    """One valid ``access.documentation.evidence/1`` document for the GRACEFUL cell.

    The containment cell is about process ownership, not extraction, so the document is
    deliberately empty of facts and must still satisfy the production evidence contract
    (schema, run/source/coverage shape, and a status consistent with its own facts).
    """
    empty_status = {"inspected": [], "excluded": {}, "unsupported": {}, "failed": {}}
    return {
        "schema": "access.documentation.evidence/1",
        "run": {
            "run_id": "containment-graceful",
            "extractor_version": f"containment-harness/1 (Access {app_version})",
            "scope": {"tables": [], "queries": []},
        },
        "source": {
            "path": str(db_path),
            "format": "ACE",
            "backend_identity": "MSACCESS.EXE",
            "acquisition_mode": "containment-scratch-copy",
            "consistency_marker": f"access_pid={identity.get('access_pid')}",
        },
        "coverage": {
            "tables": dict(empty_status),
            "queries": dict(empty_status),
            "relationships": dict(empty_status),
        },
        "warnings": [],
        "data": {"status": "complete", "tables": [], "relationships": [], "queries": []},
    }


def _path_guard(db_path: Path) -> str | None:
    root = SCRATCH_COPY_DIR.resolve()
    resolved = db_path.resolve()
    if not resolved.is_relative_to(root):
        return f"path {resolved} is outside the harness scratch root {root}"
    if resolved.name != ARMED_DB_NAME:
        return f"path {resolved} is not the disposable copy name {ARMED_DB_NAME!r}"
    if not resolved.is_file():
        return f"path {resolved} does not exist"
    return None


def run(args: argparse.Namespace) -> int:
    import pythoncom
    import win32com.client

    db_path = Path(args.db)
    refusal = _path_guard(db_path)
    if refusal is not None:
        print(f"PATH_REFUSED: {refusal}", file=sys.stderr)
        return EXIT_PATH_REFUSED
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    baseline_pids = {int(part) for part in args.baseline_pids.split(",") if part.strip().isdigit()}

    stdout_tee = TeeBinary(sys.__stdout__.buffer)
    stderr_tee = TeeBinary(getattr(sys.stderr, "buffer", None))
    sys.stderr = _TeeText(stderr_tee)  # type: ignore[assignment]

    state: dict[str, Any] = {
        "schema": "v2-containment.armed-worker/1",
        "scenario": args.scenario,
        "db": str(db_path.resolve()),
        "baseline_msaccess_pids": sorted(baseline_pids),
        "child_pid": os.getpid(),
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }

    def snapshot() -> None:
        write_json_flushed(out_dir / "state.json", state)
        (out_dir / "emitted_protocol.bin").write_bytes(bytes(stdout_tee.captured))
        (out_dir / "stderr.bin").write_bytes(bytes(stderr_tee.captured))

    app: Any = None
    observer: WindowObserver | None = None
    access_pid: int | None = None
    pythoncom.CoInitialize()
    try:
        app = win32com.client.DispatchEx("Access.Application")
        # --- identity capture + fail-closed ownership proof, before any armed open -----
        try:
            hwnd = int(app.hWndAccessApp())
            import win32process

            _thread, pid = win32process.GetWindowThreadProcessId(hwnd)
            access_pid = int(pid)
            capture_method = "hWndAccessApp"
        except Exception as exc:  # noqa: BLE001 - fall back to a baseline-diff candidate
            candidates = sorted(new_access_pids(baseline_pids))
            capture_method = "baseline-diff"
            access_pid = candidates[0] if len(candidates) == 1 else None
            state["hwnd_error"] = f"{type(exc).__name__}: {exc}"
            state["baseline_diff_candidates"] = candidates
        identity = read_process_identity(access_pid) if access_pid else None
        verification: dict[str, Any] = {
            "method": capture_method,
            "access_pid": access_pid,
            "owned": False,
            "reasons": [],
        }
        if access_pid is None:
            verification["reasons"].append("no-pid")
        elif access_pid in baseline_pids:
            verification["reasons"].append("pid-in-baseline")
        elif identity is None:
            verification["reasons"].append("identity-unreadable")
        elif identity.image.casefold() != "msaccess.exe":
            verification["reasons"].append(f"image-{identity.image}")
        else:
            verification["owned"] = True
        if identity is not None:
            verification["access_creation"] = identity.creation
            verification["access_image"] = identity.image
        state["access_identity"] = {
            "capture_method": capture_method,
            "access_pid": access_pid,
            "access_creation": None if identity is None else identity.creation,
            "access_image": None if identity is None else identity.image,
        }
        state["identity_verification"] = verification
        snapshot()
        if not verification["owned"]:
            state["aborted"] = "Access identity not positively verified; armed open refused"
            snapshot()
            return EXIT_IDENTITY_UNVERIFIED

        # --- production protocol ack: one flushed frame BEFORE the armed open -----------
        emit_access_identity(identity.pid, identity.creation, identity.image, stream=stdout_tee)
        state["identity_frame_emitted"] = True
        observer = WindowObserver({access_pid})
        observer.start()
        state["observer_started"] = True

        for attribute, value in (("Visible", False), ("UserControl", False)):
            try:
                setattr(app, attribute, value)
            except Exception as exc:  # noqa: BLE001 - recorded, not fatal
                state[f"{attribute.lower()}_error"] = f"{type(exc).__name__}: {exc}"
        app.AutomationSecurity = MSO_AUTOMATION_SECURITY_FORCE_DISABLE
        readback = int(app.AutomationSecurity)
        state["security_readback"] = readback
        state["security_readback_matches"] = (
            readback == MSO_AUTOMATION_SECURITY_FORCE_DISABLE
        )
        if not state["security_readback_matches"]:
            state["aborted"] = "AutomationSecurity readback mismatch; armed open refused"
            snapshot()
            _graceful_quit(app)
            return EXIT_SECURITY_MISMATCH

        open_started = time.monotonic()
        try:
            app.OpenCurrentDatabase(str(db_path.resolve()))
        except Exception as exc:  # noqa: BLE001 - a failed open is evidence
            state["armed_open_ok"] = False
            state["armed_open_error"] = f"{type(exc).__name__}: {exc}"
            snapshot()
            _graceful_quit(app)
            return EXIT_OPEN_FAILED
        state["armed_open_ok"] = True
        state["armed_open_seconds"] = round(time.monotonic() - open_started, 3)
        state["lock_file_present_after_open"] = lock_files(db_path.resolve().parent)
        try:
            state["access_version"] = str(app.Version)
        except Exception as exc:  # noqa: BLE001
            state["access_version"] = f"<unreadable: {type(exc).__name__}>"
        snapshot()

        if args.scenario == "CRASH":
            # Leave Access alive on purpose; the supervisor must reap it by PID.
            state["phase"] = "crash-exit"
            snapshot()
            os._exit(EXIT_CRASH)

        if args.scenario == "HANG":
            state["phase"] = "hanging"
            snapshot()
            deadline = time.monotonic() + args.hang_seconds
            while time.monotonic() < deadline:
                time.sleep(0.5)
                _drain_windows(observer, state)
            state["phase"] = "hang-budget-exhausted-without-kill"
            snapshot()
            _graceful_quit(app)
            return EXIT_HANG_BUDGET_EXHAUSTED

        # GRACEFUL: close like a well-behaved production reader would.
        state["phase"] = "graceful-close"
        snapshot()
        _graceful_quit(app)
        gone = wait_until(lambda: not process_is_alive(access_pid), 20.0)
        state["access_exited_after_quit"] = gone
        state["access_exit_seconds"] = round(time.monotonic() - open_started, 3)
        if observer is not None:
            observer.stop()
            state["windows"] = list(observer.windows)
            state["observer_error"] = observer.error
        state["lock_file_after_quit"] = lock_files(db_path.resolve().parent)
        response = encode_response(
            {
                "ok": True,
                "evidence": minimal_evidence(
                    db_path.resolve(), state["access_identity"], str(state.get("access_version", ""))
                ),
            }
        )
        stdout_tee.write(response)
        stdout_tee.flush()
        state["phase"] = "graceful-response-emitted"
        state["emitted_response_bytes"] = len(response)
        snapshot()
        app = None
        pythoncom.CoUninitialize()
        return EXIT_OK
    finally:
        if observer is not None:
            observer.stop()
            state["windows"] = list(observer.windows)
            state["observer_error"] = observer.error
        state["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        snapshot()
        app = None
        try:
            pythoncom.CoUninitialize()
        except Exception:  # noqa: BLE001 - already uninitialized on the happy path
            pass


def _drain_windows(observer: WindowObserver | None, state: dict[str, Any]) -> None:
    if observer is not None and observer.windows:
        state["windows"] = list(observer.windows)


def _graceful_quit(app: Any) -> None:
    """Best-effort graceful close of *our own* instance; never a kill, never foreign."""
    for action in ("CloseCurrentDatabase", "Quit"):
        try:
            getattr(app, action)()
        except Exception:  # noqa: BLE001 - teardown never masks the recorded outcome
            pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", required=True, choices=SCENARIOS)
    parser.add_argument("--db", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--baseline-pids", default="")
    parser.add_argument("--hang-seconds", type=float, default=90.0)
    args = parser.parse_args()
    try:
        return run(args)
    except Exception as exc:  # noqa: BLE001 - a crash is evidence, not silence
        try:
            write_json_flushed(Path(args.out) / "fatal.json", {"fatal": f"{type(exc).__name__}: {exc}"})
        except Exception:  # noqa: BLE001
            pass
        print(f"ARMED_WORKER_FATAL: {type(exc).__name__}: {exc}", file=sys.stderr)
        return EXIT_FATAL


if __name__ == "__main__":
    raise SystemExit(main())
