"""Bounded T3 containment runner: Job Object research + production kill-net live cells.

T3 (ODD, S2/S5) preparation harness. It answers, with a real ``MSACCESS.EXE`` on
disposable scratch copies:

1. **JOB research.** Can a Python supervisor assign a COM-activated (``DispatchEx``)
   ``MSACCESS.EXE`` to a Windows Job Object carrying
   ``JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE``, and does that containment survive the
   supervisor's death? Cells: ``job-close-after-assign`` (assign + kill-on-close verified
   by closing the last handle), ``job-sacrificial-parent`` (job handle held only by a
   child Python process that is hard-killed). A refused assignment is recorded as a
   limitation (cell ``c``) with no watchdog escalation.
2. **Production kill-net live cells.** The *real*
   :class:`ms_access_mcp.application.documentation_runtime.DocumentationRuntime` is driven
   with its injectable ``launcher`` pointed at :mod:`armed_worker`, which ``DispatchEx``es
   Access on a scratch copy and emits the production ``@@ACCESS_IDENTITY@@`` frame before
   the armed open. Scenarios: ``CRASH`` (``os._exit(1)`` leaving Access alive), ``HANG``
   (sleep past the injected deadline), ``GRACEFUL`` (``CloseCurrentDatabase`` + ``Quit``,
   exit 0 with a valid evidence response).

This module is throwaway research tooling: it edits no production file, never runs the
matrix unless ``--all`` is given, and never cleans up its own scratch root.

Exit codes (documented, no auto-retry, the matrix stops at the first timeout):

* ``0`` -- ``PASS`` or ``PASS_WITH_JOB_LIMITATION`` (kill-net gates and safety pass; a job
  containment refutation is recorded clearly but is not a run failure);
* ``2`` -- harness/build error before or instead of the matrix (including self-check
  failure);
* ``3`` -- production kill-net verdict gate failed;
* ``4`` -- safety violation (canonical hash changed, new foreign ``MSACCESS.EXE``, or an
  unverified kill);
* ``5`` -- a cell exceeded the harness-level cell budget: the matrix stopped there.
"""

from __future__ import annotations

import argparse
import ctypes
import dataclasses
import inspect
import json
import py_compile
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from contain_common import (  # noqa: E402
    ARMED_DB_NAME,
    BASELINE_PIDS_FILE,
    EVIDENCE_DIR,
    HASHES_AFTER_FILE,
    HASHES_BEFORE_FILE,
    JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE,
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION,
    REPORT_FILE,
    ROOT,
    SCRATCH_COPY_DIR,
    SCRATCH_DIR,
    SUMMARY_FILE,
    canonical_hashes,
    diff_hashes,
    list_msaccess_pids,
    lock_files,
    new_access_pids,
    process_is_alive,
    read_json,
    sentinel_frame_bytes,
    terminate_verified_access,
    verified_kill_python,
    wait_until,
    write_json_flushed,
)

from ms_access_mcp.application.documentation_runtime import DocumentationRuntime  # noqa: E402
from ms_access_mcp.application.documentation_worker import (  # noqa: E402
    AccessIdentity,
    decode_response_with_identities,
    encode_response,
    split_access_identity_frames,
)
from ms_access_mcp.errors import AccessMcpError  # noqa: E402

ARMED_WORKER = SCRATCH_DIR / "armed_worker.py"
JOB_SUPERVISOR = SCRATCH_DIR / "job_supervisor.py"
FIXTURE_BUILDER = SCRATCH_DIR / "build_fixture.py"
HARNESS_MODULES = ("contain_common.py", "build_fixture.py", "armed_worker.py", "job_supervisor.py", "run_containment.py")

EXIT_PASS = 0
EXIT_HARNESS_ERROR = 2
EXIT_KILLNET_FAILURE = 3
EXIT_SAFETY_VIOLATION = 4
EXIT_CELL_TIMEOUT = 5
EXIT_CELL_INCONCLUSIVE = 6

DEFAULT_DEADLINE_SECONDS = 20.0
DEFAULT_GRACE_SECONDS = 10.0
DEFAULT_JOB_GRACE_SECONDS = 20.0
DEFAULT_CELL_TIMEOUT_SECONDS = 75.0
DEFAULT_REPEAT = 2


# ---------------------------------------------------------------------------------------
# verdict
# ---------------------------------------------------------------------------------------
def compute_verdict(payload: dict[str, Any]) -> dict[str, Any]:
    """Pure verdict function (unit-checked by ``--self-check`` with synthetic inputs).

    Required inputs: ``cells`` (list of cell records with ``kind``, ``gate.passed``,
    ``timeout``), ``hashes_diff``, ``baseline_msaccess_pids``, ``final_msaccess_pids``,
    ``foreign_kill_attempts``, ``matrix_stopped_after``.
    """
    cells = payload["cells"]
    killnet = [cell for cell in cells if cell.get("kind") == "killnet"]
    jobs = [cell for cell in cells if cell.get("kind") == "job"]
    timeouts = [cell["cell"] for cell in cells if cell.get("timeout")]
    killnet_failures = [cell["cell"] for cell in killnet if not cell.get("gate", {}).get("passed")]
    graceful_failures = [
        cell["cell"] for cell in killnet if cell.get("scenario") == "GRACEFUL" and not cell.get("gate", {}).get("passed")
    ]
    originals_unchanged = bool(payload["hashes_diff"].get("unchanged"))
    baseline = set(payload["baseline_msaccess_pids"])
    final = set(payload["final_msaccess_pids"])
    survivors = sorted(final - baseline)
    foreign_kills = list(payload.get("foreign_kill_attempts") or [])
    job_values = {cell.get("mode"): cell.get("job_containment") for cell in jobs}
    job_refuted = sorted(mode for mode, value in job_values.items() if value == "REFUTED")
    job_limited = sorted(mode for mode, value in job_values.items() if value == "LIMITATION")
    job_unknown = sorted(
        mode for mode, value in job_values.items() if value not in ("PROVEN", "REFUTED", "LIMITATION")
    )
    if not jobs:
        job_unknown.append("<no job cell ran>")
    limitations = [f"job containment refuted for mode {mode}" for mode in job_refuted]
    limitations += [f"job containment not established (recorded limitation) for mode {mode}" for mode in job_limited]
    checks = {
        "killnet_cells_present": bool(killnet),
        "killnet_cells_passed": bool(killnet) and not killnet_failures,
        "graceful_cell_clean": bool(killnet) and not graceful_failures,
        "job_cells_present": bool(jobs),
        "job_cells_classified": not job_unknown,
        "job_containment_proven": bool(jobs) and not job_refuted and not job_limited and not job_unknown,
        "originals_unchanged": originals_unchanged,
        "zero_owned_survivors": not survivors,
        "zero_new_foreign_msaccess": not survivors,
        "no_unverified_kill": not foreign_kills,
        "no_cell_timeout": not timeouts,
    }
    # Priority: safety first, then an incomplete (timed-out) matrix, then a kill-net
    # verdict failure, then an unclassified job cell, then the pass variants.
    if survivors or foreign_kills or not originals_unchanged:
        status, exit_code = "FAIL", EXIT_SAFETY_VIOLATION
    elif timeouts:
        status, exit_code = "INCONCLUSIVE_TIMEOUT", EXIT_CELL_TIMEOUT
    elif not checks["killnet_cells_passed"]:
        status, exit_code = "FAIL", EXIT_KILLNET_FAILURE
    elif job_unknown:
        status, exit_code = "INCONCLUSIVE", EXIT_CELL_INCONCLUSIVE
    elif job_refuted or job_limited:
        status, exit_code = "PASS_WITH_JOB_LIMITATION", EXIT_PASS
    else:
        status, exit_code = "PASS", EXIT_PASS
    return {
        "schema": "v2-containment.verdict/1",
        "status": status,
        "exit_code": exit_code,
        "checks": checks,
        "killnet_failures": killnet_failures,
        "graceful_failures": graceful_failures,
        "cell_timeouts": timeouts,
        "unclassified_job_cells": job_unknown,
        "owned_survivors": survivors,
        "foreign_kill_attempts": foreign_kills,
        "job_containment": job_values,
        "limitations": limitations,
        "matrix_stopped_after": payload.get("matrix_stopped_after"),
    }


# ---------------------------------------------------------------------------------------
# bounded subprocess helper
# ---------------------------------------------------------------------------------------
def run_bounded(argv: list[str], timeout: float) -> dict[str, Any]:
    record: dict[str, Any] = {"argv": [str(item) for item in argv], "returncode": None, "stdout": "", "stderr": "", "timeout": False}
    try:
        completed = subprocess.run(  # noqa: S603 - fixed argv built in this harness, never a shell
            [str(item) for item in argv], capture_output=True, text=True, timeout=timeout, check=False, cwd=str(SCRATCH_DIR)
        )
    except subprocess.TimeoutExpired as exc:
        record["timeout"] = True
        record["stdout"] = exc.stdout.decode("utf-8", "replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        record["stderr"] = exc.stderr.decode("utf-8", "replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        return record
    record["returncode"] = completed.returncode
    record["stdout"] = completed.stdout
    record["stderr"] = completed.stderr
    return record


def _arm_copy(cell_name: str, run_index: int, template: Path) -> Path:
    """One unique disposable copy per live cell run (never reused, never the template)."""
    directory = SCRATCH_COPY_DIR / f"{cell_name}-run{run_index}"
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / ARMED_DB_NAME
    shutil.copy2(template, destination)
    return destination


# ---------------------------------------------------------------------------------------
# Job Object cells
# ---------------------------------------------------------------------------------------
def run_job_cell(
    *,
    mode: str,
    run_index: int,
    copy_path: Path,
    baseline: set[int],
    grace: float,
    cell_timeout: float,
) -> dict[str, Any]:
    cell_name = f"job-{mode}"
    out_dir = EVIDENCE_DIR / "cells" / cell_name / f"run_{run_index}"
    out_dir.mkdir(parents=True, exist_ok=True)
    state_path = out_dir / "state.json"
    started = time.monotonic()
    argv = [
        sys.executable,
        str(JOB_SUPERVISOR),
        "--mode",
        mode,
        "--db",
        str(copy_path),
        "--out",
        str(out_dir),
        "--baseline-pids",
        ",".join(str(pid) for pid in sorted(baseline)),
    ]
    proc = subprocess.Popen(  # noqa: S603 - fixed argv built in this harness, never a shell
        argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=str(SCRATCH_DIR)
    )
    record: dict[str, Any] = {
        "cell": cell_name,
        "kind": "job",
        "mode": mode,
        "run": run_index,
        "db": str(copy_path),
        "baseline_msaccess_pids": sorted(baseline),
        "supervisor_shim_pid": proc.pid,
        "supervisor_argv": argv,
        "timeout": False,
    }
    kill_record: dict[str, Any] | None = None
    access_died: bool | None = None
    access_death_seconds: float | None = None

    def terminal_state() -> dict[str, Any]:
        return read_json(state_path, {}) or {}

    if mode == "close-after-assign":
        observed = wait_until(lambda: terminal_state().get("mode_outcome") is not None, cell_timeout, 0.5)
        record["state_observed"] = observed
    else:
        observed = wait_until(
            lambda: terminal_state().get("phase") == "holding-job-handle"
            or terminal_state().get("mode_outcome") is not None,
            cell_timeout,
            0.5,
        )
        record["state_observed"] = observed
        holding = terminal_state()
        if holding.get("phase") == "holding-job-handle":
            real_pid = holding.get("supervisor_real_pid")
            creation = holding.get("supervisor_creation")
            record["supervisor_real_pid"] = real_pid
            record["supervisor_creation"] = creation
            kill_record = verified_kill_python(real_pid, creation)
            kill_record["shim_pid"] = proc.pid
            identity = holding.get("access_identity") or {}
            access_pid = identity.get("access_pid")
            record["access_pid"] = access_pid
            timer = time.monotonic()
            access_died = bool(access_pid) and wait_until(lambda: not process_is_alive(access_pid), grace)
            access_death_seconds = round(time.monotonic() - timer, 3)
            record["supervisor_exited_after_kill"] = wait_until(lambda: proc.poll() is not None, grace)

    if proc.poll() is None:
        wait_until(lambda: proc.poll() is not None, grace)
    stdout, stderr = _drain_process(proc, grace)
    elapsed = round(time.monotonic() - started, 3)
    state = terminal_state()
    assignment = state.get("job_assignment") or {}
    identity = state.get("access_identity") or {}

    # Reap any owned survivor with the production fail-closed verifier BEFORE classifying,
    # so the harness never leaves an Access behind -- and record the reap as evidence.
    survivors = sorted(new_access_pids(baseline))
    record["survivors_immediately_after"] = survivors
    harness_reap: list[dict[str, Any]] = []
    announced_pid = identity.get("access_pid")
    for pid in survivors:
        if pid == announced_pid and identity.get("access_creation"):
            harness_reap.append(
                dataclasses.asdict(
                    terminate_verified_access(
                        pid=pid,
                        creation=identity["access_creation"],
                        image=identity.get("access_image") or "",
                        baseline_pids=frozenset(baseline),
                        grace_seconds=grace,
                    )
                )
            )
    if survivors:
        wait_until(lambda: not new_access_pids(baseline), grace)

    if not assignment.get("assigned") or not assignment.get("is_process_in_job"):
        containment = "LIMITATION" if observed else "INCONCLUSIVE"
    elif mode == "close-after-assign":
        containment = "PROVEN" if state.get("kill_on_close_access_died") else "REFUTED"
    else:
        containment = "PROVEN" if access_died else "REFUTED"

    limit_readback = state.get("kill_on_job_close_limit", {}).get("readback") or 0
    checks: dict[str, bool] = {
        "terminal_state_observed": bool(observed),
        "identity_owned": bool((state.get("identity_verification") or {}).get("owned")),
        "breakaway_flag_absent_from_containment_job": not (int(limit_readback) & 0x00000800),
        "kill_on_job_close_set": bool(int(limit_readback) & JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE),
        "assignment_succeeded": bool(assignment.get("assigned")),
        "is_process_in_job": bool(assignment.get("is_process_in_job")),
        "job_active_processes_after_assign": (assignment.get("job_active_processes") or 0) >= 1,
        "armed_open_ok": bool(state.get("armed_open_ok")),
        "no_unverified_kill": all(
            (not item.get("terminated")) or item.get("verified") for item in (harness_reap or [])
        ),
    }
    if mode == "close-after-assign":
        checks["kill_on_close_terminated_access"] = bool(state.get("kill_on_close_access_died"))
        checks["supervisor_survived"] = bool(state.get("supervisor_survived"))
        difficulty = "kill-on-close did not terminate Access"
    else:
        checks["supervisor_hard_killed"] = bool(kill_record and kill_record.get("result") == "killed")
        checks["supervisor_exited"] = bool(record.get("supervisor_exited_after_kill"))
        checks["access_died_after_parent_death"] = bool(access_died)
        difficulty = "Access survived the death of the only job-handle holder"
    record.update(
        {
            "elapsed_seconds": elapsed,
            "child_returncode": proc.returncode,
            "stdout": stdout,
            "stderr": stderr,
            "supervisor_state": state,
            "job_assignment": assignment,
            "kill": kill_record,
            "access_died": None if access_died is None else bool(access_died),
            "access_death_seconds": access_death_seconds,
            "survivors_after_grace": sorted(new_access_pids(baseline)),
            "locks_after": lock_files(copy_path.parent),
            "windows_observed": state.get("windows") or [],
            "harness_reap": harness_reap,
            "job_containment": containment,
            "difficulty": None if containment == "PROVEN" else difficulty,
            "state_observed": bool(observed),
            "timeout": elapsed > cell_timeout,
            "gate": {"passed": all(checks.values()), "checks": checks},
        }
    )
    write_json_flushed(out_dir / "run_record.json", record)
    return record


def _drain_process(proc: subprocess.Popen[bytes], grace: float) -> tuple[str, str]:
    """Read the bounded child streams after reaping; never blocks past the grace."""
    try:
        raw_out, raw_err = proc.communicate(timeout=max(grace, 5.0))
    except subprocess.TimeoutExpired:
        proc.kill()
        raw_out, raw_err = b"", b""
    return (
        (raw_out or b"").decode("utf-8", "replace"),
        (raw_err or b"").decode("utf-8", "replace"),
    )


# ---------------------------------------------------------------------------------------
# production kill-net cells
# ---------------------------------------------------------------------------------------
def run_killnet_cell(
    *,
    scenario: str,
    run_index: int,
    copy_path: Path,
    baseline: set[int],
    deadline: float,
    grace: float,
    cell_timeout: float,
) -> dict[str, Any]:
    cell_name = f"killnet-{scenario.lower()}"
    out_dir = EVIDENCE_DIR / "cells" / cell_name / f"run_{run_index}"
    out_dir.mkdir(parents=True, exist_ok=True)
    record: dict[str, Any] = {
        "cell": cell_name,
        "kind": "killnet",
        "scenario": scenario,
        "run": run_index,
        "db": str(copy_path),
        "baseline_msaccess_pids": sorted(baseline),
        "injected_deadline_seconds": deadline,
        "injected_cleanup_grace_seconds": grace,
    }
    terminations: list[dict[str, Any]] = []
    baseline_snapshots: list[list[int]] = []
    holder: dict[str, subprocess.Popen[bytes] | None] = {"proc": None}

    def pid_lister() -> set[int]:
        pids = list_msaccess_pids()
        baseline_snapshots.append(sorted(pids))
        return pids

    def terminator(**kwargs: Any) -> Any:
        outcome = terminate_verified_access(**kwargs)
        terminations.append(dataclasses.asdict(outcome))
        return outcome

    def launcher() -> subprocess.Popen[bytes]:
        proc = subprocess.Popen(  # noqa: S603 - fixed argv built in this harness, never a shell
            [
                sys.executable,
                str(ARMED_WORKER),
                "--scenario",
                scenario,
                "--db",
                str(copy_path),
                "--out",
                str(out_dir),
                "--baseline-pids",
                ",".join(str(pid) for pid in sorted(baseline)),
            ],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=str(SCRATCH_DIR),
        )
        holder["proc"] = proc
        return proc

    runtime = DocumentationRuntime(
        launcher=launcher,
        deadline_seconds=deadline,
        cleanup_grace_seconds=grace,
        access_pid_lister=pid_lister,
        access_terminator=terminator,
    )
    started = time.monotonic()
    try:
        document = runtime.inspect(str(copy_path), backend="dao", allowed_dirs=[SCRATCH_DIR], tables=None, queries=None)
        outcome: dict[str, Any] = {"kind": "ok", "status": document.status, "schema": document.schema}
    except AccessMcpError as exc:
        outcome = {"kind": "err", "message": str(exc)}
    except BaseException as exc:  # noqa: BLE001 - a harness-visible crash is evidence
        outcome = {"kind": "fatal", "message": f"{type(exc).__name__}: {exc}"}
    elapsed = round(time.monotonic() - started, 3)
    proc = holder["proc"]
    state = read_json(out_dir / "state.json", {}) or {}
    identity = state.get("access_identity") or {}

    survivors = sorted(new_access_pids(baseline))
    harness_reap: list[dict[str, Any]] = []
    for pid in survivors:
        if pid == identity.get("access_pid") and identity.get("access_creation"):
            harness_reap.append(
                dataclasses.asdict(
                    terminate_verified_access(
                        pid=pid,
                        creation=identity["access_creation"],
                        image=identity.get("access_image") or "",
                        baseline_pids=frozenset(baseline),
                        grace_seconds=grace,
                    )
                )
            )
    if survivors:
        wait_until(lambda: not new_access_pids(baseline), grace)

    record.update(
        {
            "child_returncode": None if proc is None else proc.returncode,
            "elapsed_seconds": elapsed,
            "runtime_outcome": outcome,
            "access_terminations": terminations,
            "runtime_access_baseline_snapshots": baseline_snapshots,
            "armed_worker_state": state,
            "child_stdout_bytes": _size_of(out_dir / "emitted_protocol.bin"),
            "child_stderr_bytes": _size_of(out_dir / "stderr.bin"),
            "child_stdout_text": _text_of(out_dir / "emitted_protocol.bin"),
            "child_stderr_text": _text_of(out_dir / "stderr.bin"),
            "child_stdout_bytes_hex_first_frame": (out_dir / "emitted_protocol.bin").read_bytes()[:64].hex()
            if (out_dir / "emitted_protocol.bin").exists()
            else None,
            "stream_capture_note": (
                "the armed worker tees its own protocol bytes, so stdout/stderr are the exact child "
                "streams the production supervisor consumed (same bytes, mirrored to disk)"
            ),
            "windows_observed": state.get("windows") or [],
            "locks_after": lock_files(copy_path.parent),
        }
    )
    record["survivors_immediately_after"] = survivors
    record["harness_reap"] = harness_reap
    record["survivors_after_grace"] = sorted(new_access_pids(baseline))
    record["locks_after_grace"] = lock_files(copy_path.parent)
    checks = _killnet_checks(scenario, record, deadline)
    record["gate"] = {"passed": all(checks.values()), "checks": checks}
    record["timeout"] = elapsed > cell_timeout
    write_json_flushed(out_dir / "run_record.json", record)
    return record


def _size_of(path: Path) -> int | None:
    return path.stat().st_size if path.exists() else None


def _text_of(path: Path, limit: int = 4096) -> str | None:
    """Decoded child stream (bounded) so the exact protocol text is in the evidence."""
    if not path.exists():
        return None
    return path.read_bytes()[:limit].decode("utf-8", "replace")


def _killnet_checks(scenario: str, record: dict[str, Any], deadline: float) -> dict[str, bool]:
    outcome = record["runtime_outcome"]
    message = str(outcome.get("message", ""))
    state = record["armed_worker_state"]
    terminations = record["access_terminations"]
    verified_kills = [item for item in terminations if item.get("terminated") and item.get("verified")]
    checks: dict[str, bool] = {
        "child_returncode_recorded": record["child_returncode"] is not None,
        "frame_emitted_before_open": bool(state.get("identity_frame_emitted")),
        "identity_owned": bool((state.get("identity_verification") or {}).get("owned")),
        "armed_open_ok": bool(state.get("armed_open_ok")),
        "security_forced_disable": state.get("security_readback") == 3
        and bool(state.get("security_readback_matches")),
        "exactly_one_armed_identity_announced": len(terminations) == 1,
        "no_owned_survivors_within_grace": not record["survivors_after_grace"],
        # A forced taskkill cannot remove the .laccdb lock (no graceful close);
        # the contract bounds residue to the disposable copy. locks_after_grace is
        # globbed from the copy's own directory, so entries are bare filenames from
        # that directory by construction; a path-valued entry must match the copy dir.
        "lock_residue_bounded_to_scratch_copy": all(
            str(lock) == Path(str(lock)).name
            or Path(str(lock)).resolve().parent == Path(record["db"]).resolve().parent
            for lock in record["locks_after_grace"]
        ),
        "no_unverified_kill": all(
            (not item.get("terminated")) or item.get("verified") for item in terminations
        )
        and all((not item.get("terminated")) or item.get("verified") for item in record["harness_reap"]),
    }
    if scenario == "CRASH":
        checks["runtime_raised_err"] = outcome.get("kind") == "err"
        checks["pinned_nonzero_exit_message"] = "exit code 1" in message and "was reaped" in message
        checks["no_deadline_claim"] = "deadline" not in message
        # The pinned crash message legitimately never claims a cleanup grace;
        # only the deadline path's message does.
        checks["kill_net_reaped_access"] = len(verified_kills) == 1 and bool(verified_kills[0].get("exited"))
    elif scenario == "HANG":
        checks["runtime_raised_err"] = outcome.get("kind") == "err"
        checks["pinned_deadline_message"] = (
            f"exceeded the {deadline:g}-second deadline" in message and "terminated and reaped" in message
        )
        checks["deadline_was_actually_reached"] = record["elapsed_seconds"] >= deadline
        checks["kill_net_reaped_access"] = len(verified_kills) == 1 and bool(verified_kills[0].get("exited"))
    else:  # GRACEFUL
        checks["runtime_returned_ok"] = outcome.get("kind") == "ok"
        checks["evidence_status_complete"] = outcome.get("status") == "complete"
        checks["child_exit_zero"] = record["child_returncode"] == 0
        checks["access_exited_before_cleanup"] = bool(state.get("access_exited_after_quit"))
        checks["kill_net_issued_no_kill"] = (
            len(terminations) == 1 and not terminations[0].get("terminated") and bool(terminations[0].get("exited"))
        )
    return checks


# ---------------------------------------------------------------------------------------
# self-check (no COM)
# ---------------------------------------------------------------------------------------
def _synthetic_cell(cell: str, kind: str, passed: bool, **extra: Any) -> dict[str, Any]:
    base: dict[str, Any] = {"cell": cell, "kind": kind, "timeout": False, "gate": {"passed": passed, "checks": {}}}
    base.update(extra)
    return base


def _verdict_inputs(**overrides: Any) -> dict[str, Any]:
    cells = [
        _synthetic_cell("killnet-crash", "killnet", True, scenario="CRASH"),
        _synthetic_cell("killnet-hang", "killnet", True, scenario="HANG"),
        _synthetic_cell("killnet-graceful", "killnet", True, scenario="GRACEFUL"),
        _synthetic_cell("job-close-after-assign", "job", True, mode="close-after-assign", job_containment="PROVEN"),
        _synthetic_cell("job-sacrificial-parent", "job", True, mode="sacrificial-parent", job_containment="PROVEN"),
    ]
    payload: dict[str, Any] = {
        "cells": cells,
        "hashes_diff": {"unchanged": True, "changed": [], "added": [], "removed": []},
        "baseline_msaccess_pids": [100],
        "final_msaccess_pids": [100],
        "foreign_kill_attempts": [],
        "matrix_stopped_after": None,
    }
    payload.update(overrides)
    return payload


def phase_self_check() -> dict[str, Any]:
    """Compile, import, structural, protocol and synthetic-verdict checks; never COM."""
    checks: dict[str, bool] = {}
    details: dict[str, Any] = {}

    for module in HARNESS_MODULES:
        py_compile.compile(str(SCRATCH_DIR / module), doraise=True)
    checks["harness_modules_compile"] = True

    import armed_worker
    import job_supervisor

    checks["armed_worker_scenarios"] = tuple(armed_worker.SCENARIOS) == ("CRASH", "HANG", "GRACEFUL")
    checks["job_supervisor_modes"] = tuple(job_supervisor.MODES) == ("close-after-assign", "sacrificial-parent")

    runtime_init = inspect.signature(DocumentationRuntime.__init__).parameters
    checks["runtime_injectable_seams_present"] = all(
        name in runtime_init
        for name in ("launcher", "deadline_seconds", "cleanup_grace_seconds", "access_pid_lister", "access_terminator")
    )
    runtime_inspect = inspect.signature(DocumentationRuntime.inspect).parameters
    checks["runtime_inspect_contract"] = all(
        name in runtime_inspect for name in ("db_path", "backend", "allowed_dirs", "tables", "queries")
    )

    # Production-protocol frame round trip (emit -> split -> decode), plus the v1 no-frame
    # path staying byte-identical.
    frame = sentinel_frame_bytes(4242, 133_700_000_000_000_000, "MSACCESS.EXE")
    frames, remainder = split_access_identity_frames(frame)
    checks["identity_frame_round_trip"] = frames == [
        AccessIdentity(pid=4242, creation=133_700_000_000_000_000, image="MSACCESS.EXE")
    ] and remainder == b""
    payload_bytes = encode_response({"ok": True, "evidence": armed_worker.minimal_evidence(Path("armed.accdb"), {"access_pid": 4242}, "16.0")})
    identities, decoded = decode_response_with_identities(frame + payload_bytes)
    checks["frame_plus_response_decodes"] = len(identities) == 1 and decoded.get("ok") is True
    v1_frames, v1_body = split_access_identity_frames(payload_bytes)
    checks["v1_no_frame_path_byte_identical"] = v1_frames == [] and v1_body == payload_bytes
    checks["facade_worker_matches_containment_worker"] = (
        armed_worker.emit_access_identity is
        __import__("ms_access_mcp.application.documentation_worker", fromlist=["emit_access_identity"]).emit_access_identity
    )

    # The GRACEFUL response must satisfy the production evidence contract.
    from ms_access_mcp.application.documentation import EvidenceDoc

    document = EvidenceDoc.from_dict(
        armed_worker.minimal_evidence(Path("armed.accdb"), {"access_pid": 4242}, "16.0")
    )
    checks["graceful_evidence_is_valid"] = document.status == "complete" and document.schema == "access.documentation.evidence/1"

    # Job Object structure layout and flag values (x64).
    checks["job_struct_layout_x64"] = ctypes.sizeof(JOBOBJECT_EXTENDED_LIMIT_INFORMATION) == 144
    checks["kill_on_job_close_flag_value"] = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE == 0x00002000

    # Job Object smoke readback on a throwaway empty job (kernel call, no COM, no Access):
    # proves the ctypes structures work on this host before any live cell depends on them.
    from contain_common import (
        close_job,
        create_job,
        query_job_active_processes,
        set_job_limit_flags,
    )

    smoke_handle: int | None = None
    try:
        smoke_handle = create_job()
        smoke = set_job_limit_flags(smoke_handle, JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE)
        smoke["active_processes"] = query_job_active_processes(smoke_handle)
        details["job_object_smoke"] = smoke
        checks["job_object_smoke_readback"] = bool(
            smoke.get("set_ok")
            and (smoke.get("readback") or 0) & JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            and smoke.get("active_processes") == 0
        )
    except OSError as exc:
        details["job_object_smoke"] = {"error": f"{type(exc).__name__}: {exc}"}
        checks["job_object_smoke_readback"] = False
    finally:
        if smoke_handle is not None:
            close_job(smoke_handle)

    # Fail-closed path guards: both live children must refuse a path outside their scratch
    # root before any Access instance exists.
    foreign_path = Path(ROOT) / "db" / "northwind.accdb"
    checks["armed_worker_refuses_foreign_path"] = armed_worker._path_guard(foreign_path) is not None  # noqa: SLF001
    checks["job_supervisor_refuses_foreign_path"] = (
        job_supervisor._path_guard(foreign_path) is not None  # noqa: SLF001
    )

    # The armed worker must emit the identity frame before it opens any source.
    worker_source = (SCRATCH_DIR / "armed_worker.py").read_text(encoding="utf-8")
    checks["source_order_frame_before_armed_open"] = worker_source.index("emit_access_identity(") < worker_source.index(
        "OpenCurrentDatabase("
    )
    supervisor_source = (SCRATCH_DIR / "job_supervisor.py").read_text(encoding="utf-8")
    checks["source_uses_pid_scoped_kill_only"] = "/IM" not in supervisor_source and "/IM" not in worker_source

    # The interpreter shim used for every live child must propagate the child's exit code:
    # the CRASH cell's pinned "exit code 1" message depends on exactly that.
    try:
        probe = subprocess.run(  # noqa: S603 - fixed argv, bounded, never a shell
            [sys.executable, "-c", "import os; os._exit(7)"], capture_output=True, timeout=30, check=False, cwd=str(SCRATCH_DIR)
        )
        details["child_exit_code_probe"] = {"returncode": probe.returncode, "expected": 7}
        checks["child_exit_code_reaches_parent"] = probe.returncode == 7
    except Exception as exc:  # noqa: BLE001 - a probe failure is a failed check, not a crash
        details["child_exit_code_probe"] = {"error": f"{type(exc).__name__}: {exc}"}
        checks["child_exit_code_reaches_parent"] = False

    # Dialog observation is optional by contract: the read-only watcher import is recorded
    # (informational) instead of gating the run, because a harness could legitimately lose
    # observer coverage while still producing valid process-containment evidence.
    try:
        from tests.helpers.dialog_watcher import collect_windows  # noqa: F401

        details["dialog_watcher_import"] = {"ok": True}
    except Exception as exc:  # noqa: BLE001
        details["dialog_watcher_import"] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}

    # Synthetic verdict assertions: each mutation must actually change the verdict.
    verdicts = {
        "all_pass": compute_verdict(_verdict_inputs()),
        "crash_survivor": compute_verdict(
            _verdict_inputs(final_msaccess_pids=[100, 777]),
        ),
        "killnet_gate_failed": compute_verdict(
            _verdict_inputs(
                cells=[
                    _synthetic_cell("killnet-crash", "killnet", False, scenario="CRASH"),
                    _synthetic_cell("killnet-hang", "killnet", True, scenario="HANG"),
                    _synthetic_cell("killnet-graceful", "killnet", True, scenario="GRACEFUL"),
                ]
            )
        ),
        "graceful_issued_kill": compute_verdict(
            _verdict_inputs(
                cells=[
                    _synthetic_cell("killnet-graceful", "killnet", False, scenario="GRACEFUL"),
                    _synthetic_cell("killnet-crash", "killnet", True, scenario="CRASH"),
                ]
            )
        ),
        "hash_changed": compute_verdict(
            _verdict_inputs(hashes_diff={"unchanged": False, "changed": ["db/northwind.accdb"], "added": [], "removed": []})
        ),
        "job_refuted": compute_verdict(
            _verdict_inputs(
                cells=[
                    _synthetic_cell("killnet-crash", "killnet", True, scenario="CRASH"),
                    _synthetic_cell("job-close-after-assign", "job", False, mode="close-after-assign", job_containment="REFUTED"),
                ]
            )
        ),
        "cell_timeout": compute_verdict(
            _verdict_inputs(
                cells=[
                    _synthetic_cell("killnet-crash", "killnet", False, scenario="CRASH", timeout=True),
                ],
                matrix_stopped_after="killnet-crash",
            )
        ),
    }
    details["synthetic_verdicts"] = {
        name: {"status": verdict["status"], "exit_code": verdict["exit_code"]} for name, verdict in verdicts.items()
    }
    checks["synthetic_all_pass"] = verdicts["all_pass"]["status"] == "PASS" and verdicts["all_pass"]["exit_code"] == 0
    checks["synthetic_survivor_fails_safety"] = verdicts["crash_survivor"]["exit_code"] == EXIT_SAFETY_VIOLATION
    checks["synthetic_killnet_failure"] = verdicts["killnet_gate_failed"]["exit_code"] == EXIT_KILLNET_FAILURE
    checks["synthetic_graceful_kill_fails"] = verdicts["graceful_issued_kill"]["exit_code"] == EXIT_KILLNET_FAILURE
    checks["synthetic_hash_change_fails_safety"] = verdicts["hash_changed"]["exit_code"] == EXIT_SAFETY_VIOLATION
    checks["synthetic_job_refutation_is_limitation"] = (
        verdicts["job_refuted"]["status"] == "PASS_WITH_JOB_LIMITATION" and verdicts["job_refuted"]["exit_code"] == 0
    )
    checks["synthetic_timeout_stops_matrix"] = verdicts["cell_timeout"]["exit_code"] == EXIT_CELL_TIMEOUT

    result = {"schema": "v2-containment.self-check/1", "ok": all(checks.values()), "checks": checks, "details": details}
    write_json_flushed(EVIDENCE_DIR / "self_check.json", result)
    return result


# ---------------------------------------------------------------------------------------
# matrix
# ---------------------------------------------------------------------------------------
def run_matrix(args: argparse.Namespace) -> int:
    EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    SCRATCH_COPY_DIR.mkdir(parents=True, exist_ok=True)

    baseline = set(list_msaccess_pids())
    write_json_flushed(
        BASELINE_PIDS_FILE,
        {"baseline_msaccess_pids": sorted(baseline), "recorded_at": time.strftime("%Y-%m-%dT%H:%M:%S")},
    )
    hashes_before = canonical_hashes()
    write_json_flushed(HASHES_BEFORE_FILE, hashes_before)

    template_dir = SCRATCH_COPY_DIR / "template"
    build = run_bounded([sys.executable, str(FIXTURE_BUILDER), "--out-dir", str(template_dir)], 180.0)
    (EVIDENCE_DIR / "build_stdout.txt").write_text(build["stdout"], encoding="utf-8")
    (EVIDENCE_DIR / "build_stderr.txt").write_text(build["stderr"], encoding="utf-8")
    build_record = _parse_json(build["stdout"]) or {"ok": False, "error": "builder produced no JSON record"}
    build_record["returncode"] = build["returncode"]
    build_record["timeout"] = build["timeout"]
    write_json_flushed(EVIDENCE_DIR / "build_result.json", build_record)

    cells: list[dict[str, Any]] = []
    matrix_stopped_after: str | None = None
    if not build_record.get("ok"):
        verdict = {
            "schema": "v2-containment.verdict/1",
            "status": "HARNESS_ERROR",
            "exit_code": EXIT_HARNESS_ERROR,
            "checks": {"fixture_built": False},
            "failures": ["fixture build failed; no live cell ran"],
            "build": build_record,
        }
    else:
        template = template_dir / ARMED_DB_NAME
        plan: list[tuple[str, str, int]] = [("job", "close-after-assign", 1)]
        plan += [("job", "sacrificial-parent", index + 1) for index in range(args.repeat)]
        plan += [("killnet", "CRASH", index + 1) for index in range(args.repeat)]
        plan += [("killnet", "HANG", index + 1) for index in range(args.repeat)]
        plan += [("killnet", "GRACEFUL", index + 1) for index in range(args.repeat)]
        for kind, name, run_index in plan:
            cell_name = f"job-{name}" if kind == "job" else f"killnet-{name.lower()}"
            copy_path = _arm_copy(cell_name, run_index, template)
            if kind == "job":
                cell = run_job_cell(
                    mode=name,
                    run_index=run_index,
                    copy_path=copy_path,
                    baseline=baseline,
                    grace=args.job_grace,
                    cell_timeout=args.cell_timeout,
                )
            else:
                cell = run_killnet_cell(
                    scenario=name,
                    run_index=run_index,
                    copy_path=copy_path,
                    baseline=baseline,
                    deadline=args.deadline,
                    grace=args.grace,
                    cell_timeout=args.cell_timeout,
                )
            cells.append(cell)
            print(f"[{cell_name} run {run_index}] passed={cell['gate']['passed']} timeout={cell['timeout']}", flush=True)
            if cell["timeout"]:
                matrix_stopped_after = f"{cell_name}#{run_index}"
                break
        hashes_after = canonical_hashes()
        diff = diff_hashes(hashes_before, hashes_after)
        final_pids = sorted(list_msaccess_pids())
        foreign_kill_attempts = _foreign_kill_attempts(cells)
        verdict = compute_verdict(
            {
                "cells": cells,
                "hashes_diff": diff,
                "baseline_msaccess_pids": sorted(baseline),
                "final_msaccess_pids": final_pids,
                "foreign_kill_attempts": foreign_kill_attempts,
                "matrix_stopped_after": matrix_stopped_after,
            }
        )
        verdict["build"] = build_record
        verdict["hashes_diff"] = diff
        verdict["baseline_msaccess_pids"] = sorted(baseline)
        verdict["final_msaccess_pids"] = final_pids
    write_json_flushed(HASHES_AFTER_FILE, canonical_hashes())

    report = {
        "schema": "v2-containment.report/1",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "scratch_root": str(SCRATCH_DIR),
        "root": str(ROOT),
        "python": sys.version,
        "python_executable": sys.executable,
        "baseline_msaccess_pids": sorted(baseline),
        "build": build_record,
        "cells": cells,
        "verdict": verdict,
    }
    write_json_flushed(REPORT_FILE, report)
    write_json_flushed(
        SUMMARY_FILE,
        {
            "schema": "v2-containment.summary/1",
            "status": verdict.get("status"),
            "exit_code": verdict.get("exit_code"),
            "checks": verdict.get("checks"),
            "job_containment": verdict.get("job_containment"),
            "limitations": verdict.get("limitations"),
            "cell_gates": {f"{cell['cell']}#{cell['run']}": cell["gate"]["passed"] for cell in cells},
            "cell_elapsed_seconds": {f"{cell['cell']}#{cell['run']}": cell["elapsed_seconds"] for cell in cells},
        },
    )
    print(json.dumps({"status": verdict.get("status"), "exit_code": verdict.get("exit_code")}, indent=2))
    return int(verdict.get("exit_code", EXIT_HARNESS_ERROR))


def _parse_json(text: str) -> dict[str, Any] | None:
    try:
        parsed = json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return None
    return parsed if isinstance(parsed, dict) else None


def _foreign_kill_attempts(cells: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Any kill that was issued without a positive identity verification (must be empty)."""
    findings: list[dict[str, Any]] = []
    for cell in cells:
        for item in cell.get("access_terminations") or []:
            if item.get("terminated") and not item.get("verified"):
                findings.append({"cell": cell["cell"], "kind": "access", **item})
        for item in cell.get("harness_reap") or []:
            if item.get("terminated") and not item.get("verified"):
                findings.append({"cell": cell["cell"], "kind": "access-reap", **item})
        kill = cell.get("kill")
        if isinstance(kill, dict) and kill.get("result") == "killed":
            verified = (
                kill.get("observed_creation") is not None
                and kill.get("observed_creation") == kill.get("expected_creation")
                and str(kill.get("observed_image", "")).casefold().startswith("python")
            )
            if not verified:
                findings.append({"cell": cell["cell"], "kind": "python", **kill})
    return findings


# ---------------------------------------------------------------------------------------
# entry point
# ---------------------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--self-check", action="store_true", help="compile/import/structural/protocol/synthetic-verdict checks; no COM")
    mode.add_argument("--all", action="store_true", help="run the full live containment matrix (self-check first)")
    parser.add_argument("--repeat", type=int, default=DEFAULT_REPEAT, help="runs per live cell except job-close-after-assign")
    parser.add_argument("--deadline", type=float, default=DEFAULT_DEADLINE_SECONDS, help="injected runtime deadline (seconds)")
    parser.add_argument("--grace", type=float, default=DEFAULT_GRACE_SECONDS, help="injected runtime cleanup grace (seconds)")
    parser.add_argument("--job-grace", type=float, default=DEFAULT_JOB_GRACE_SECONDS, help="job-cell reap grace (seconds)")
    parser.add_argument("--cell-timeout", type=float, default=DEFAULT_CELL_TIMEOUT_SECONDS, help="harness-level cell budget (seconds)")
    args = parser.parse_args(argv)

    if args.self_check or args.all:
        self_check = phase_self_check()
        if not self_check["ok"]:
            failed = sorted(name for name, ok in self_check["checks"].items() if not ok)
            print(json.dumps({"status": "SELF_CHECK_FAILED", "failed_checks": failed}, indent=2))
            return EXIT_HARNESS_ERROR
        if args.self_check:
            print(json.dumps({"status": "SELF_CHECK_OK", "checks": len(self_check["checks"])}, indent=2))
            return EXIT_PASS

    if not args.all:
        parser.print_help()
        return EXIT_HARNESS_ERROR
    return run_matrix(args)


if __name__ == "__main__":
    raise SystemExit(main())
