# T3 containment research harness (scratch, not production)

ODD `documentation-workflows-v2`, task **T3** (Specs S2, S5) — preparation phase only.
This directory is throwaway research tooling under the D: repo scratch convention
(`db/fixtures/e2e-v2-contain-20261017-d6a5abcc/`). It edits no production file, imports
the production modules through `sys.path` only, and never removes its own scratch root.
The parent owns the live launch; this harness does not self-launch the matrix.

## Exact command

```bash
cd /d/code/python/mcp-ms-access && .venv/Scripts/python.exe db/fixtures/e2e-v2-contain-20261017-d6a5abcc/run_containment.py --all
```

`--all` runs the no-COM self-check first and aborts with exit code `2` if it fails, then
runs the live matrix. `--self-check` alone is bounded (<1 s) and instantiates no COM
object at all (no DAO, no Access); it does create one empty throwaway Job Object and run
one bounded interpreter-exit probe, both without touching a database.

## What it answers

### 1. JOB research (kernel containment for a COM-launched `MSACCESS.EXE`)

| Cell | Question |
| --- | --- |
| `job-close-after-assign` | Can a Python supervisor assign a `DispatchEx`-launched `MSACCESS.EXE` to a Job Object carrying `JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE`, and does closing the **last handle** kill Access? Non-vacuous checks: `AssignProcessToJobObject` success, `IsProcessInJob` membership, `ActiveProcesses >= 1`, KILL_ON_JOB_CLOSE readback, and the supervisor itself surviving (so it was never a job member). |
| `job-sacrificial-parent` | The job handle is held **only** by a child Python process. The runner kills that exact PID (creation-verified `taskkill /F /PID`). `KILL_ON_JOB_CLOSE` must fire from the kernel closing the dead process's handle. |
| cell (c) | Assignment refused (e.g. `ERROR_ACCESS_DENIED`) is recorded as a **limitation** with the `winerror`; there is no watchdog escalation and no invented alternative containment. |

Breakaway is checked but never enabled on the containment job: a member that could break
away would escape `KILL_ON_JOB_CLOSE`. `contain_common.breakaway_probe()` records host
capability on a separate throwaway job.

### 2. Production kill-net live cells (the real `DocumentationRuntime`)

The production supervisor is driven **unmodified** through its documented injectable
seams (`launcher`, `deadline_seconds`, `cleanup_grace_seconds`, `access_pid_lister`,
`access_terminator`). Only the child is replaced, by `armed_worker.py`, which:

1. validates `--db` is a disposable copy inside this scratch root (fail-closed refusal
   before any Access exists);
2. `DispatchEx`es Access, captures the PID via `hWndAccessApp` ->
   `GetWindowThreadProcessId` and the creation/image via the production
   `read_process_identity`;
3. proves ownership fail-closed (PID outside the pre-spawn baseline, live creation match,
   `MSACCESS.EXE` image) or refuses to open;
4. emits exactly one flushed `@@ACCESS_IDENTITY@@` frame through the **production**
   `emit_access_identity` **before** the armed open;
5. opens only the scratch copy under `AutomationSecurity=3` with a readback check, and
   starts a read-only window observer that records windows and never accepts a dialog.

| Cell | Scenario | Required outcome |
| --- | --- | --- |
| `killnet-crash` | `os._exit(1)` after the armed open, leaving Access alive | runtime `Err` with the pinned `exit code 1 ... was reaped` text; the kill net reaps Access (`verified=True, terminated=True, exited=True`); zero survivors, zero locks |
| `killnet-hang` | sleep past the injected 20 s deadline | runtime `Err` with the pinned `exceeded the 20-second deadline` text after the deadline is actually reached; kill net reaps Access; zero survivors, zero locks |
| `killnet-graceful` | `CloseCurrentDatabase` + `Quit`, wait for the captured PID to disappear, emit one valid minimal `access.documentation.evidence/1` response, exit 0 | runtime `Ok` with `status == complete`; the kill net must issue **no** kill (`terminated=False, exited=True`) |

Injected overrides: `--deadline 20` / `--grace 10` / `--job-grace 20` /
`--cell-timeout 75` / `--repeat 2`.

## Verdict gates (non-vacuous, fail-closed)

`PASS` requires **all** of: every kill-net cell gate passed (CRASH and HANG reaped by the
kill net, GRACEFUL clean), zero owned survivors and zero new foreign `MSACCESS.EXE`, all
canonical hashes unchanged, no unverified kill, and the job cells classified.
A job containment **refutation** or assignment **limitation** yields
`PASS_WITH_JOB_LIMITATION` with the reason recorded — it is not a run failure. Safety
violations always dominate; a cell timeout stops the matrix with no retry.

## Exit codes

| Code | Meaning |
| --- | --- |
| `0` | `PASS` or `PASS_WITH_JOB_LIMITATION` |
| `2` | harness/build error before or instead of the matrix (includes self-check failure) |
| `3` | production kill-net verdict gate failed |
| `4` | safety violation (canonical hash changed, new foreign `MSACCESS.EXE`, unverified kill) |
| `5` | a cell exceeded the harness-level cell budget: the matrix stopped there, no retry |
| `6` | a live cell produced no terminal state (harness-inconclusive); the matrix continued |

Child exit codes: `armed_worker.py` `1` CRASH, `10` bad args, `11` scratch-path refusal,
`12` identity unverified, `13` armed open failed, `14` fatal, `15` security readback
mismatch, `16` hang budget exhausted; `job_supervisor.py` `15` security readback
mismatch, `20` assignment failed (limitation), `21` kill-on-close refuted, `22` identity
unverified, `23` fatal, `24` scratch-path refusal, `25` hold budget exhausted.

## Safety envelope

* every kill is PID-scoped through the production fail-closed verifier for Access, and
  through a creation-verified `taskkill /F /PID` for harness-owned Python children only;
  `/IM` appears nowhere;
* a pre-existing (baseline) `MSACCESS.EXE` is never killed, and a survivor is reaped only
  when its PID equals the identity that cell announced;
* `db/fixtures/documentation` and `db/northwind.accdb` are hashed before and after and are
  never opened by Access; only per-cell disposable copies are opened;
* no Trust Center / registry / trusted-location change, no synthetic input, no dialog
  acceptance; windows are observed read-only;
* the `.laccdb` presence next to each copy is recorded (never deleted by the harness);
* the matrix is one bounded pass: no auto-retry, and the first timeout stops it.

## Files

| File | Role |
| --- | --- |
| `run_containment.py` | bounded runner: `--self-check` / `--all`, cell orchestration, pure verdict function |
| `contain_common.py` | hashing, process/kill helpers, tee streams, read-only window observer, Job Object ctypes primitives |
| `build_fixture.py` | DAO-only build of the trivial disposable `armed.accdb` (no VBA/macro/startup property) |
| `armed_worker.py` | the armed child driven by the production runtime (CRASH / HANG / GRACEFUL) |
| `job_supervisor.py` | Job Object assignment/containment child (`close-after-assign`, `sacrificial-parent`) |
| `evidence/` | `self_check.json`, `baseline_msaccess_pids.json`, `hashes_before.json`, `hashes_after.json`, `build_result.json`, `cells/<cell>/run_<n>/`, `v2_containment_report.json`, `summary.json` |
| `scratch/` | the DAO fixture template and one unique disposable copy per live cell run |

## Known limitations of this harness

* The harness-level `--cell-timeout` is applied **after** the call returns: the
  production runtime's own deadline/cleanup grace bound every cell (~35 s worst case), so
  the runner cannot wedge itself; a genuinely wedged runner is the parent's background
  launch ceiling, not a harness watchdog.
* The kill-net cells capture the child's exact protocol stdout/stderr by teeing inside
  `armed_worker.py`, because the production supervisor owns the real pipes.
* Job Object results are host-specific (this Windows build, x64). A refutation is a
  recorded limitation about this host, not a portable claim.
* The injected 20 s deadline leaves roughly 18 s of slack for the first Access cold
  start plus the PowerShell identity read (~1-3 s in the prior spikes). A host whose
  Access cold start exceeded that window would kill the child before the identity frame
  is emitted; that shows up as a missing-frame gate failure plus an owned survivor, which
  the harness reports and reaps with the production verifier rather than hiding.
