import json, os, tempfile
from pathlib import Path
from types import SimpleNamespace
R = {"tree": os.environ["PROBE_TREE"], "package_root": str(Path(__import__("ms_access_mcp").__file__).resolve().parents[1]), "cells": {}}
from ms_access_mcp.application import documentation_app_logic as app_logic
DUMMY = Path(os.environ["PROBE_TMP"]) / "c-src.accdb"; DUMMY.write_bytes(b"x")
ident = SimpleNamespace(pid=1, creation=1, image="X.EXE")
class BoomContainment(Exception): pass
# simulate ContainmentError by making identity capture fail hard path is internal; instead direct:
r = app_logic.AppLogicReader(launcher=lambda: SimpleNamespace(application_version=lambda: "16.0",
    set_automation_security=lambda v: (_ for _ in ()).throw(BoomContainment("boom"))),
    identity_reader=lambda pid: ident, emit_identity=lambda *a: None, assign_job=lambda p: None,
    scratch_root=Path(tempfile.mkdtemp(dir=str(os.environ["PROBE_TMP"]))))
try:
    c = r.read(str(DUMMY))
    R["cells"]["containment_subclass"] = {"raised": False}
except BaseException as e:
    R["cells"]["containment_subclass"] = {"raised": True, "type": type(e).__name__, "msg": str(e)[:120]}
# real ContainmentError from internal step: unreadable identity at capture
r2 = app_logic.AppLogicReader(launcher=lambda: SimpleNamespace(application_version=lambda: "16.0",
    set_automation_security=lambda v: None, read_automation_security=lambda: 3, access_application_pid=lambda: 7),
    identity_reader=lambda pid: None, emit_identity=lambda *a: None, assign_job=lambda p: None,
    scratch_root=Path(tempfile.mkdtemp(dir=str(os.environ["PROBE_TMP"]))))
try:
    c = r2.read(str(DUMMY))
    R["cells"]["real_containment_identity"] = {"raised": False}
except BaseException as e:
    R["cells"]["real_containment_identity"] = {"raised": True, "type": type(e).__name__, "msg": str(e)[:120]}
Path(os.environ["PROBE_OUT"]).write_text(json.dumps(R, indent=1), encoding="utf-8")
print("WROTE")
