"""T2 S3 worker-level differential: default v1, operational Tier2 fail, programmer fail.
WP4 safe protocol: no COM launch in any cell (copy2 patched to raise pre-launch)."""
from __future__ import annotations
import hashlib, io, json, os, sys
from pathlib import Path
from types import SimpleNamespace

TREE = os.environ["PROBE_TREE"]
OUT = Path(os.environ["PROBE_OUT"])
SCRATCH = Path(os.environ["PROBE_SCRATCH"])
R = {"tree": TREE, "package_root": None, "cells": {}}

import ms_access_mcp
R["package_root"] = str(Path(ms_access_mcp.__file__).resolve().parents[1])
from ms_access_mcp.application import documentation_app_logic as app_logic
from ms_access_mcp.application import documentation_worker as worker
from ms_access_mcp.application.documentation_worker import (
    build_request, decode_response_with_identities)

SOURCE_COPY = SCRATCH / "live" / "worker-probe.accdb"
SCRATCH_DIR = SCRATCH / "live" / "worker_t2_scratch"
SCRATCH_DIR.mkdir(parents=True, exist_ok=True)
os.environ[app_logic.SCRATCH_DIR_ENV] = str(SCRATCH_DIR)

SECRET = "PWD=hunter2secret;"
ORDER: list[str] = []
real_inspect = worker.inspect_open_database
def inspect_recorder(*args, **kwargs):
    ORDER.append("passive_extract")
    return real_inspect(*args, **kwargs)
worker.inspect_open_database = inspect_recorder

def patch_copy(exc):
    def failing_copy(_src, _dst):
        ORDER.append("tier2_copy2_raise")
        raise exc
    app_logic.shutil = SimpleNamespace(copy2=failing_copy, rmtree=__import__("shutil").rmtree)

def run_cell(request):
    stdin_buf = io.BytesIO(json.dumps(request).encode("utf-8"))
    stdout_rec = io.BytesIO(); stderr_rec = io.StringIO()
    real = (sys.stdin, sys.stdout, sys.__stdout__)
    try:
        sys.stdin = SimpleNamespace(buffer=stdin_buf)
        sys.stdout = SimpleNamespace(buffer=stdout_rec)
        sys.__stdout__ = stdout_rec
        code = worker.main([])
    finally:
        sys.stdin, sys.stdout, sys.__stdout__ = real
    ids, resp = decode_response_with_identities(stdout_rec.getvalue())
    return {"exit": code, "stdout_sha256": hashlib.sha256(stdout_rec.getvalue()).hexdigest(),
            "stdout_bytes": len(stdout_rec.getvalue()),
            "stdout": json.dumps(resp, sort_keys=True), "identity_frames": len(ids),
            "stderr_tail": stderr_rec.getvalue()[-200:] if hasattr(stderr_rec, "getvalue") else ""}

REQ = dict(db_path=str(SOURCE_COPY), backend="dao", allowed_dirs=[str(SCRATCH)],
           tables=None, queries=None)

cellA = run_cell(build_request(**REQ))
cellA["stage_order"] = list(ORDER); ORDER.clear()
evA = cellA["stdout"].get("evidence", {}) if isinstance(cellA["stdout"], dict) else {}
cellA["status"] = evA.get("status")
cellA["app_logic_key_absent"] = "app_logic" not in evA.get("data", {})
R["cells"]["A_default_v1"] = cellA

patch_copy(OSError("the disposable copy could not be written: " + SECRET))
cellB = run_cell(build_request(**REQ, include_app_logic=True))
ORDER.clear()
evB = cellB["stdout"].get("evidence", {}) if isinstance(cellB["stdout"], dict) else {}
alB = evB.get("data", {}).get("app_logic", {})
cellB["status"] = evB.get("status")
cellB["ok"] = cellB["stdout"].get("ok") if isinstance(cellB["stdout"], dict) else None
cellB["families"] = [[c.get("category"), c.get("name"),
                      c.get("content", {}).get("state")] for c in alB.get("content", [])]
cellB["warning_count"] = len(evB.get("warnings", []))
serB = json.dumps(cellB["stdout"])
cellB["secret_absent"] = SECRET not in serB
cellB["sanitized_present"] = "PWD=***" in serB
R["cells"]["B_operational_OSError"] = cellB

patch_copy(ValueError("programmer defect " + SECRET))
cellC = run_cell(build_request(**REQ, include_app_logic=True))
ORDER.clear()
cellC["ok"] = cellC["stdout"].get("ok") if isinstance(cellC["stdout"], dict) else None
cellC["has_error"] = "error" in cellC["stdout"] if isinstance(cellC["stdout"], dict) else False
cellC["has_evidence"] = "evidence" in cellC["stdout"] if isinstance(cellC["stdout"], dict) else False
serC = json.dumps(cellC["stdout"])
cellC["secret_absent"] = SECRET not in serC
cellC["sanitized_present"] = "PWD=***" in serC
R["cells"]["C_programmer_ValueError"] = cellC
app_logic.shutil = __import__("shutil")

R["probe_copy_sha256"] = hashlib.sha256(SOURCE_COPY.read_bytes()).hexdigest()
OUT.write_text(json.dumps(R, indent=1, default=str), encoding="utf-8")
print("WROTE", OUT)
