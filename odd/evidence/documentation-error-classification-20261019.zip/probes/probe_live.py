"""T2 live proof: real COM success control + corrupted-copy Tier2 failure.
Safety: only disposable copies opened by Access.Application; original hashed, never opened;
no settings changes; bounded single attempt per cell."""
from __future__ import annotations
import hashlib, io, json, os, sys
from pathlib import Path
from types import SimpleNamespace

TREE = os.environ["PROBE_TREE"]
OUT = Path(os.environ["PROBE_OUT"])
SCRATCH = Path(os.environ["PROBE_SCRATCH"])
R = {"tree": TREE, "package_root": None, "cells": {}, "events": [], "identity": None}

import ms_access_mcp
R["package_root"] = str(Path(ms_access_mcp.__file__).resolve().parents[1])
from ms_access_mcp.application import documentation_app_logic as app_logic
from ms_access_mcp.application import documentation_worker as worker
from ms_access_mcp.application.documentation_worker import (
    build_request, decode_response_with_identities)
from ms_access_mcp.backends.access.app_logic_session import ComAccessLauncher
from ms_access_mcp.application.process_identity import read_process_identity

ORIGINAL = Path(r"D:/code/python/mcp-ms-access/db/fixtures/documentation/startup.accdb")
LIVE = SCRATCH / "live"
LIVE.mkdir(parents=True, exist_ok=True)
SUCC = LIVE / f"live-success-{TREE}.accdb"
CORR = LIVE / f"live-corrupt-{TREE}.accdb"
SCRATCH_DIR = LIVE / "t2_live_scratch"
SCRATCH_DIR.mkdir(exist_ok=True)
os.environ[app_logic.SCRATCH_DIR_ENV] = str(SCRATCH_DIR)

import shutil as _shutil
_shutil.copy2(ORIGINAL, SUCC)
_shutil.copy2(ORIGINAL, CORR)
R["original_sha256"] = hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
R["succ_sha_before"] = hashlib.sha256(SUCC.read_bytes()).hexdigest()
R["corr_sha_before"] = hashlib.sha256(CORR.read_bytes()).hexdigest()

class RecordingSession:
    def __init__(self, inner):
        self._inner = inner
        self.events = []
        R["events"].append(self.events)
    def set_automation_security(self, level):
        self.events.append(["set_security", level])
        return self._inner.set_automation_security(level)
    def read_automation_security(self):
        v = self._inner.read_automation_security()
        self.events.append(["read_security", v])
        return v
    def open_current_database(self, path):
        self.events.append(["open", Path(path).name])
        return self._inner.open_current_database(path)
    def access_application_pid(self):
        pid = self._inner.access_application_pid()
        self.events.append(["pid", pid])
        return pid
    def __getattr__(self, name):
        return getattr(self._inner, name)

_real_default_launcher = app_logic._default_launcher
def recording_launcher():
    return RecordingSession(_real_default_launcher())
app_logic._default_launcher = recording_launcher

def run_worker(db_path, **extra):
    stdin_buf = io.BytesIO(json.dumps(
        build_request(db_path=str(db_path), backend="dao", allowed_dirs=[str(SCRATCH)],
                      tables=None, queries=None, **extra)).encode("utf-8"))
    stdout_rec = io.BytesIO(); stderr_rec = io.StringIO()
    real = (sys.stdin, sys.stdout, sys.__stdout__)
    try:
        sys.stdin = SimpleNamespace(buffer=stdin_buf)
        sys.stdout = SimpleNamespace(buffer=stdout_rec)
        sys.__stdout__ = stdout_rec
        code = worker.main([])
    finally:
        sys.stdin, sys.stdout, sys.__stdout__ = real
    ids, resp = decode_response_with_identities(stdout_rec.getvalue())
    return {"exit": code, "resp": resp, "stdout_sha": hashlib.sha256(stdout_rec.getvalue()).hexdigest(),
            "identities": [[i.pid, i.creation, i.image] for i in ids],
            "stderr": stderr_rec.getvalue()[-400:]}

def summarize(resp):
    ev = resp.get("evidence", {})
    al = ev.get("data", {}).get("app_logic", {})
    vba = [x for x in al.get("content", []) if x.get("category") == "vba_module"]
    return {"ok": resp.get("ok"), "error": resp.get("error"), "status": ev.get("status"),
            "tables": [t.get("name") for t in ev.get("data", {}).get("tables", [])],
            "warnings": ev.get("warnings", []),
            "families": [[x.get("category"), x.get("name"), x.get("content", {}).get("state"),
                          (x.get("content", {}).get("reason") or "")[:220]]
                         for x in al.get("content", [])],
            "vba_full": vba,
            "ref_failed_all": all(
                al.get("references", [{}])[0].get(p, {}).get("state") == "failed"
                for p in ("path", "guid", "major", "minor", "built_in")) if al.get("references") else None}

# ---- L1: passive control on the corrupt target BEFORE corruption (dao reads fine) ----
R["cells"]["L0_passive_control_uncorrupted"] = summarize(run_worker(CORR)["resp"])

# ---- L1: live success control on disposable copy (real COM, VBA content observed) ----
res = run_worker(SUCC, include_app_logic=True, include_app_logic_source=True)
summ = summarize(res["resp"])
vba_ok = False
for v in summ["vba_full"]:
    c = v.get("content", {})
    if c.get("state") == "observed" and isinstance(c.get("source"), str) and len(c["source"]) > 0:
        vba_ok = True
        R["vba_source_head"] = c["source"][:160]
R["cells"]["L1_live_success"] = {
    "exit": res["exit"], "stdout_sha": res["stdout_sha"],
    "identity_frames": res["identities"],
    **summ, "vba_observed_with_source": vba_ok,
    "security_events": R["events"][-1] if R["events"] else None}
if res["identities"]:
    R["identity"] = res["identities"][-1]
    pid, creation, image = R["identity"]
    import time
    live_after = read_process_identity(pid)
    R["cells"]["L1_live_success"]["owned_survivor_after"] = (
        None if live_after is None else [live_after.pid, live_after.creation, live_after.image])
R["cells"]["L1_live_success"]["laccdb_left"] = sorted(p.name for p in LIVE.glob("*.laccdb"))

# ---- L2: corrupt ONLY the disposable corrupt copy at the tail boundary ----
with open(CORR, "r+b") as fh:
    fh.seek(0, os.SEEK_END)
    size = fh.tell()
    fh.seek(max(0, size - 256))
    fh.write(b"\xff" * 256)
R["corr_sha_after_corrupt"] = hashlib.sha256(CORR.read_bytes()).hexdigest()
R["cells"]["L2a_passive_after_corruption"] = summarize(run_worker(CORR)["resp"])
res = run_worker(CORR, include_app_logic=True)
summ = summarize(res["resp"])
vba_state = next((f[2] for f in summ["families"] if f[0] == "vba_module"), None)
vba_reason = next((f[3] for f in summ["families"] if f[0] == "vba_module"), "")
R["cells"]["L2b_corrupted_tier2"] = {
    "exit": res["exit"], "identity_frames": res["identities"], **summ,
    "vba_state": vba_state, "vba_reason_head": vba_reason[:220],
    "vba_not_trust_label": vba_state == "failed" and "Trust access" not in vba_reason,
    "passive_retained": summ["tables"] == R["cells"]["L0_passive_control_uncorrupted"]["tables"],
    "status_partial": summ["status"] == "partial"}
if res["identities"]:
    pid2, creation2, image2 = res["identities"][-1]
    live2 = read_process_identity(pid2)
    R["cells"]["L2b_corrupted_tier2"]["owned_survivor_after"] = (
        None if live2 is None else [live2.pid, live2.creation, live2.image])
R["cells"]["L2b_corrupted_tier2"]["laccdb_left"] = sorted(p.name for p in LIVE.glob("*.laccdb"))

app_logic._default_launcher = _real_default_launcher
app_logic.shutil = __import__("shutil")
R["original_sha_after"] = hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
R["original_unchanged"] = R["original_sha_after"] == R["original_sha256"]
R["succ_sha_after"] = hashlib.sha256(SUCC.read_bytes()).hexdigest()
OUT.write_text(json.dumps(R, indent=1, default=str), encoding="utf-8")
print("WROTE", OUT)
