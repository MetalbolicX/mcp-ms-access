"""T2 S1-S3 independent offline differential probe. Same script on BASE and CURRENT."""
from __future__ import annotations
import hashlib, json, logging, os, tempfile, traceback
from pathlib import Path
from types import SimpleNamespace

import pythoncom

TREE = os.environ["PROBE_TREE"]
OUT = Path(os.environ["PROBE_OUT"])
R = {"tree": TREE, "package_root": None, "file_shas": {}, "cells": {}}

import ms_access_mcp
R["package_root"] = str(Path(ms_access_mcp.__file__).resolve().parents[1])

from ms_access_mcp.backends.access import vba as vba_mod
from ms_access_mcp.backends.access import app_logic_session as ses_mod
from ms_access_mcp.application import documentation_app_logic as app_logic

for label, mod in (("vba.py", vba_mod), ("app_logic_session.py", ses_mod),
                   ("documentation_app_logic.py", app_logic)):
    R["file_shas"][label] = hashlib.sha256(Path(mod.__file__).read_bytes()).hexdigest()

TRUST_U = 0x800A17B4
TRUST_S = -2146822220
UNKNOWN_S = -2147418113
SECRET = "PWD=hunter2secret;"
CRLF = chr(13) + chr(10)

def ce(hresult_signed, excep=None):
    return pythoncom.com_error(hresult_signed, "Exception occurred.", excep, None)

TRUST_NESTED = ce(-2147352567, (0, "Microsoft Access", "denied", "help", 0, TRUST_S))
TRUST_DIRECT = ce(TRUST_S)
TRUST_DUCK = SimpleNamespace(hresult=TRUST_U, args=(TRUST_U,))
UNKNOWN_NESTED = ce(-2147352567, (0, "Microsoft Access", "catastrophic", "help", 0, UNKNOWN_S))
UNKNOWN_DIRECT = ce(UNKNOWN_S)

class AppVBEFail:
    def __init__(self, exc): self._exc = exc
    @property
    def VBE(self): raise self._exc

class AppVBEEmpty:
    class VBE:
        class VBProjects:
            Count = 0

class AppVBECountBoom:
    class VBE:
        class VBProjects:
            @property
            def Count(self): raise UNKNOWN_NESTED

class FakeProject:
    class VBComponents:
        Count = 1
        def __call__(self, i):
            return SimpleNamespace(Name="modMain", Type=1,
                CodeModule=SimpleNamespace(CountOfLines=2,
                    Lines=lambda a, b: "Option Explicit" + CRLF + "Sub Main()" + CRLF))

class AppVBEOne:
    class VBE:
        VBProjects = FakeProject

def outcome(fn, *a, **k):
    try:
        v = fn(*a, **k)
        return {"raised": False, "value": repr(v)}
    except BaseException as e:
        trust = getattr(ses_mod, "VbaTrustRefusedError", ())
        return {"raised": True, "type": type(e).__name__, "module": type(e).__module__,
                "msg": str(e), "is_trust": isinstance(e, trust) if trust else False,
                "is_unavail": type(e).__name__ == "VbaProjectUnavailableError"}

def cell(name, fn):
    c = {"name": name}
    try:
        c["result"] = fn()
        c["ok"] = True
    except BaseException as e:
        c["ok"] = False
        c["exc_type"] = type(e).__name__
        c["exc_msg"] = str(e)
        c["trace_tail"] = traceback.format_exc().strip().splitlines()[-3:]
    R["cells"][name] = c

def c1_default_fail():
    app = AppVBEFail(UNKNOWN_NESTED)
    captured = []
    h = logging.Handler()
    h.emit = lambda rec: captured.append([rec.levelname, rec.getMessage()])
    lg = logging.getLogger(vba_mod.__name__)
    lg.addHandler(h); old = lg.level; lg.setLevel(logging.DEBUG)
    try:
        v = vba_mod.get_vb_project(app)
    finally:
        lg.removeHandler(h); lg.setLevel(old)
    return {"value": repr(v), "logs": captured}

cell("C1a_default_VBE_success_returns_project",
     lambda: outcome(vba_mod.get_vb_project, AppVBEOne()))
cell("C1b_default_VBE_fail_unknown", c1_default_fail)
cell("C1c_default_empty_list", lambda: outcome(vba_mod.get_vb_project, AppVBEEmpty()))
cell("C1d_default_count_raises", lambda: outcome(vba_mod.get_vb_project, AppVBECountBoom()))
cell("C1e_strict_kw_exists", lambda: outcome(vba_mod.get_vb_project, AppVBEEmpty(), strict=True))

def strict_count(app):
    s = ses_mod.ComAccessSession(app)
    return outcome(s.vba_module_count)

cell("C2a_session_trust_nested", lambda: strict_count(AppVBEFail(TRUST_NESTED)))
cell("C2b_session_trust_direct", lambda: strict_count(AppVBEFail(TRUST_DIRECT)))
cell("C2c_session_trust_duck", lambda: strict_count(AppVBEFail(TRUST_DUCK)))
cell("C2d_session_unknown_nested_8000FFFF", lambda: strict_count(AppVBEFail(UNKNOWN_NESTED)))
cell("C2e_session_unknown_direct", lambda: strict_count(AppVBEFail(UNKNOWN_DIRECT)))
cell("C2f_session_empty_no_project", lambda: strict_count(AppVBEEmpty()))
cell("C2g_session_count_raises", lambda: strict_count(AppVBECountBoom()))
cell("C2h_session_success_count_and_cache", lambda: strict_count(AppVBEOne()))

def has(attr): return hasattr(vba_mod, attr)

cell("C3a_fhr_trust_nested",
     lambda: {"result": vba_mod.failing_hresults(TRUST_NESTED) if has("failing_hresults") else "ABSENT"})
cell("C3b_fhr_unknown_direct",
     lambda: {"result": vba_mod.failing_hresults(UNKNOWN_DIRECT) if has("failing_hresults") else "ABSENT"})
cell("C3c_fhr_bool_success",
     lambda: {"result": vba_mod.failing_hresults(SimpleNamespace(hresult=1, args=(True, 3, (0,)*6))) if has("failing_hresults") else "ABSENT"})
cell("C3d_is_trust_unknown",
     lambda: {"result": outcome(vba_mod.is_vba_trust_refusal, UNKNOWN_NESTED) if has("is_vba_trust_refusal") else "ABSENT"})
cell("C3e_is_trust_duck",
     lambda: {"result": outcome(vba_mod.is_vba_trust_refusal, TRUST_DUCK) if has("is_vba_trust_refusal") else "ABSENT"})
cell("C3f_unavail_exc_presence", lambda: {"VbaProjectUnavailableError": has("VbaProjectUnavailableError")})

class FakeSession:
    def __init__(self, vba_count_fn): self._vba_count_fn = vba_count_fn
    def application_version(self): return "16.0"
    def set_automation_security(self, level): self._sec = level
    def read_automation_security(self): return self._sec
    def access_application_pid(self): return 4242
    def open_current_database(self, path): pass
    def close_current_database(self): pass
    def quit_application(self): pass
    def current_project_object_names(self, collection):
        return ["frmMain"] if collection == "AllForms" else []
    def save_as_text(self, object_type, name, destination):
        blob = bytes([255, 254]) + "Form=frmMain".encode("utf-16-le")
        Path(destination).write_bytes(blob)
    def vba_module_count(self): return self._vba_count_fn()
    def reference_count(self): return 0

def make_reader(session):
    ident = SimpleNamespace(pid=4242, creation=111, image="ACCESS.EXE")
    return app_logic.AppLogicReader(
        launcher=lambda: session,
        identity_reader=lambda pid: ident,
        emit_identity=lambda *a: None,
        assign_job=lambda pid: None,
        scratch_root=Path(tempfile.mkdtemp(prefix="t2probe-scratch-")),
    )

def read_result(vba_count_fn):
    r = make_reader(FakeSession(vba_count_fn))
    try:
        c = r.read("whatever.accdb")
        blob = json.dumps(c, sort_keys=True,
                          default=lambda o: o.to_dict() if hasattr(o, "to_dict") else str(o))
        return {"raised": False, "json": blob}
    except BaseException as e:
        return {"raised": True, "type": type(e).__name__, "msg": str(e)}

cell("C4a_reader_vba_success", lambda: read_result(lambda: 1))
cell("C4b_reader_vba_trust",
     lambda: read_result(lambda: ses_mod.ComAccessSession(AppVBEFail(TRUST_NESTED)).vba_module_count()))
cell("C4c_reader_vba_unknown_8000FFFF",
     lambda: read_result(lambda: ses_mod.ComAccessSession(AppVBEFail(UNKNOWN_NESTED)).vba_module_count()))
cell("C4d_reader_vba_empty",
     lambda: read_result(lambda: ses_mod.ComAccessSession(AppVBEEmpty()).vba_module_count()))

def stage(exc):
    def launch():
        raise exc
    ident = SimpleNamespace(pid=4242, creation=111, image="ACCESS.EXE")
    r = app_logic.AppLogicReader(launcher=launch, identity_reader=lambda pid: ident,
                                 emit_identity=lambda *a: None, assign_job=lambda pid: None,
                                 scratch_root=Path(tempfile.mkdtemp(prefix="t2probe-s2-")))
    try:
        c = r.read("whatever.accdb")
        fams = []
        for x in (c.content or []):
            st = getattr(x.content, "state", None)
            if st is None:
                st = getattr(getattr(x.content, "status", None), "state", None)
            fams.append([getattr(x, "category", None), getattr(x, "name", None), str(st)])
        return {"raised": False, "families": fams,
                "warnings": [str(w) for w in (c.warnings or [])]}
    except BaseException as e:
        return {"raised": True, "type": type(e).__name__, "msg": str(e)}

cell("C5a_stage_ValueError", lambda: stage(ValueError("programmer defect " + SECRET)))
cell("C5b_stage_com_error_unknown", lambda: stage(UNKNOWN_NESTED))
cell("C5c_stage_OSError", lambda: stage(OSError("disk full " + SECRET)))
cell("C5d_stage_RuntimeError_bare", lambda: stage(RuntimeError("bare runtime " + SECRET)))
cell("C5e_stage_AttributeError", lambda: stage(AttributeError("none has no attr " + SECRET)))
cell("C5f_stage_KeyboardInterrupt", lambda: stage(KeyboardInterrupt()))
cell("C5g_stage_TypeError", lambda: stage(TypeError("bad type")))

def stage_reason_probe(exc):
    def launch():
        raise exc
    ident = SimpleNamespace(pid=4242, creation=111, image="ACCESS.EXE")
    r = app_logic.AppLogicReader(launcher=launch, identity_reader=lambda pid: ident,
                                 emit_identity=lambda *a: None, assign_job=lambda pid: None,
                                 scratch_root=Path(tempfile.mkdtemp(prefix="t2probe-s3-")))
    c = r.read("whatever.accdb")
    s = json.dumps([x.to_dict() if hasattr(x, "to_dict") else str(x)
                    for x in (c.content or [])], default=str)
    return {"secret_present": SECRET in s, "sanitized": "PWD=***" in s, "sample": s[:260]}

cell("C6_secret_redaction_OSError",
     lambda: stage_reason_probe(OSError("copy failed " + SECRET)))

OUT.write_text(json.dumps(R, indent=1, default=str), encoding="utf-8")
print("WROTE", OUT)
