import sys
try:
    import win32com.client
    app = win32com.client.DispatchEx("Access.Application")
    app.Visible = False
    app.UserControl = False
    ver = str(app.Version)
    app.Quit()
    print("ACCESS AVAILABLE version=", ver)
except BaseException as e:
    print("ACCESS UNAVAILABLE:", type(e).__name__, str(e)[:300])
    sys.exit(2)
