"""Round 4: (a) 512B@size//3 corruption variant; (b) real no-VBA-project DB through ComAccessSession."""
from __future__ import annotations
import hashlib, io, json, os, sys
from pathlib import Path
from types import SimpleNamespace

TREE = os.environ["PROBE_TREE"]
OUT = Path(os.environ["PROBE_OUT"])
SCRATCH = Path(os.environ["PROBE_SCRATCH"])
R = {"tree": TREE, "package_root": None, "cells": {}}

import ms_access_mcp
R["package_root"] = str(Path(ms_access_mcp.__file__).resolve().parents[1])
from ms_access_mcp.application import documentation_worker as worker
from ms_access_mcp.application.documentation_worker import (
    build_request, decode_response_with_identities)
from ms_access_mcp.application import documentation_app_logic as app_logic
from ms_access_mcp.application.process_identity import read_process_identity

ORIGINAL = Path(r"D:/code/python/mcp-ms-access/db/fixtures/documentation/startup.accdb")
LIVE = SCRATCH / "live"
SCRATCH_DIR = LIVE / "t2_live_scratch"
SCRATCH_DIR.mkdir(exist_ok=True)
os.environ[app_logic.SCRATCH_DIR_ENV] = str(SCRATCH_DIR)
import shutil as _shutil

def run_worker(db_path, **extra):
    stdin_buf = io.BytesIO(json.dumps(
        build_request(db_path=str(db_path), backend="dao", allowed_dirs=[str(SCRATCH)],
                      tables=None, queries=None, **extra)).encode("utf-8"))
    stdout_rec = io.BytesIO(); stderr_rec = io.StringIO()
    real = (sys.stdin, sys.stdout, sys.__stdout__)
    try:
        sys.stdin = SimpleNamespace(buffer=stdin_buf)
        sys.stdout = SimpleNamespace(buffer=stdout_rec)
        sys.__stdout__ = stdout_rec
        code = worker.main([])
    finally:
        sys.stdin, sys.stdout, sys.__stdout__ = real
    ids, resp = decode_response_with_identities(stdout_rec.getvalue())
    return {"exit": code, "resp": resp,
            "identities": [[i.pid, i.creation, i.image] for i in ids]}

def summarize(resp):
    ev = resp.get("evidence", {})
    al = ev.get("data", {}).get("app_logic", {})
    return {"ok": resp.get("ok"), "error": (resp.get("error") or "")[:220],
            "status": ev.get("status"),
            "warnings": ev.get("warnings", []),
            "families": [[x.get("category"), x.get("content", {}).get("state"),
                          (x.get("content", {}).get("reason") or "")[:220]]
                         for x in al.get("content", [])]}

# ---- (a) corruption variant: 512 bytes at size//3 ----
CORR = LIVE / f"live-corrupt4-{TREE}.accdb"
_shutil.copy2(ORIGINAL, CORR)
R["db_size"] = CORR.stat().st_size
with open(CORR, "r+b") as fh:
    fh.seek(R["db_size"] // 3)
    fh.write(b"\x00\xff" * 256)
R["cells"]["Q1_passive_512_at_third"] = summarize(run_worker(CORR)["resp"])
OUT.write_text(json.dumps(R, indent=1, default=str), encoding="utf-8")
res = run_worker(CORR, include_app_logic=True)
R["cells"]["Q2_tier2_512_at_third"] = {"exit": res["exit"], **summarize(res["resp"])}
OUT.write_text(json.dumps(R, indent=1, default=str), encoding="utf-8")

# ---- (b) no-VBA-project live probe: fresh empty DB built by Access COM in scratch ----
EMPTY = LIVE / f"live-novba-{TREE}.accdb"
if EMPTY.exists():
    EMPTY.unlink()
import win32com.client
app = win32com.client.DispatchEx("Access.Application")
try:
    app.Visible = False
    app.UserControl = False
    app.NewCurrentDatabase(str(EMPTY))
finally:
    app.Quit()
import time as _time
R["empty_lock_wait_s"] = 0
for _ in range(10):
    try:
        R["empty_sha256"] = hashlib.sha256(EMPTY.read_bytes()).hexdigest()
        break
    except PermissionError:
        _time.sleep(1); R["empty_lock_wait_s"] += 1
if "empty_sha256" not in R:
    R["empty_sha256"] = "STILL_LOCKED_AFTER_10s"
R["cells"]["N1_passive_novba"] = summarize(run_worker(EMPTY)["resp"])
OUT.write_text(json.dumps(R, indent=1, default=str), encoding="utf-8")
res = run_worker(EMPTY, include_app_logic=True)
s = summarize(res["resp"])
cellN = {"exit": res["exit"], "identity_frames": res["identities"], **s}
vba = next((f for f in s["families"] if f[0] == "vba_module"), None)
cellN["vba_state"] = vba[1] if vba else None
cellN["vba_reason"] = vba[2] if vba else None
cellN["vba_is_trust_label"] = bool(vba and vba[1] == "unavailable" and "Trust access" in vba[2])
cellN["vba_is_failed_nontrust"] = bool(vba and vba[1] == "failed" and "Trust access" not in vba[2])
if res["identities"]:
    pid, creation, image = res["identities"][-1]
    after = read_process_identity(pid)
    cellN["owned_survivor_after"] = None if after is None else [after.pid, after.creation]
cellN["laccdb_left"] = sorted(p.name for p in LIVE.glob("*.laccdb"))
R["cells"]["N2_tier2_novba"] = cellN
R["original_sha_after"] = hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
OUT.write_text(json.dumps(R, indent=1, default=str), encoding="utf-8")
print("WROTE", OUT)
