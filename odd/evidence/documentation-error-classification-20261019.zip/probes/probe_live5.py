"""Raw stdout equality for the live successful app-logic worker run (uuid-normalized offline)."""
from __future__ import annotations
import base64, hashlib, io, json, os, sys
from pathlib import Path
from types import SimpleNamespace

TREE = os.environ["PROBE_TREE"]
OUT = Path(os.environ["PROBE_OUT"])
SCRATCH = Path(os.environ["PROBE_SCRATCH"])
import ms_access_mcp
from ms_access_mcp.application import documentation_app_logic as app_logic
from ms_access_mcp.application import documentation_worker as worker
from ms_access_mcp.application.documentation_worker import (
    build_request, decode_response_with_identities)

ORIGINAL = Path(r"D:/code/python/mcp-ms-access/db/fixtures/documentation/startup.accdb")
LIVE = SCRATCH / "live"
SUCC = LIVE / f"live-raw-{TREE}.accdb"
import shutil as _shutil
_shutil.copy2(ORIGINAL, SUCC)
os.environ[app_logic.SCRATCH_DIR_ENV] = str(LIVE / "t2_live_scratch")
stdin_buf = io.BytesIO(json.dumps(build_request(
    db_path=str(SUCC), backend="dao", allowed_dirs=[str(SCRATCH)],
    tables=None, queries=None, include_app_logic=True)).encode("utf-8"))
stdout_rec = io.BytesIO()
real = (sys.stdin, sys.stdout, sys.__stdout__)
try:
    sys.stdin = SimpleNamespace(buffer=stdin_buf)
    sys.stdout = SimpleNamespace(buffer=stdout_rec)
    sys.__stdout__ = stdout_rec
    code = worker.main([])
finally:
    sys.stdin, sys.stdout, sys.__stdout__ = real
raw = stdout_rec.getvalue()
ids, resp = decode_response_with_identities(raw)
OUT.write_text(json.dumps({
    "tree": TREE, "exit": code, "stdout_len": len(raw),
    "stdout_b64": base64.b64encode(raw).decode("ascii"),
    "identity_count": len(ids)}, indent=1), encoding="utf-8")
print("WROTE", OUT, "exit", code)
