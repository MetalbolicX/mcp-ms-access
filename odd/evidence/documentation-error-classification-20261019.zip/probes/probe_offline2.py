"""T2 S1-S3 offline differential probe v2: real dummy source file, fixed fakes."""
from __future__ import annotations
import json, logging, os, tempfile, traceback
from pathlib import Path
from types import SimpleNamespace

import pythoncom

TREE = os.environ["PROBE_TREE"]
OUT = Path(os.environ["PROBE_OUT"])
TMPD = Path(os.environ["PROBE_TMP"])
R = {"tree": TREE, "package_root": None, "cells": {}}

import ms_access_mcp
R["package_root"] = str(Path(ms_access_mcp.__file__).resolve().parents[1])

from ms_access_mcp.backends.access import vba as vba_mod
from ms_access_mcp.backends.access import app_logic_session as ses_mod
from ms_access_mcp.application import documentation_app_logic as app_logic

TRUST_U = 0x800A17B4
TRUST_S = -2146822220
UNKNOWN_S = -2147418113
SECRET = "PWD=hunter2secret;"
CRLF = chr(13) + chr(10)

def ce(hresult_signed, excep=None):
    return pythoncom.com_error(hresult_signed, "Exception occurred.", excep, None)

TRUST_NESTED = ce(-2147352567, (0, "Microsoft Access", "denied", "help", 0, TRUST_S))
TRUST_DIRECT = ce(TRUST_S)
UNKNOWN_NESTED = ce(-2147352567, (0, "Microsoft Access", "catastrophic", "help", 0, UNKNOWN_S))
UNKNOWN_DIRECT = ce(UNKNOWN_S)

class DuckTrustError(Exception):
    """Real exception carrying only a duck-typed .hresult status."""
    hresult = TRUST_U
    def __init__(self): super().__init__("duck trust")

DUMMY = TMPD / "probe-src.accdb"
DUMMY.write_bytes(b"fake accdb payload for copy stage")

class AppVBEFail:
    def __init__(self, exc): self._exc = exc
    @property
    def VBE(self): raise self._exc

class _Boom:
    @property
    def Count(self): raise UNKNOWN_NESTED

class AppVBECountBoom:
    def __init__(self): self.VBE = SimpleNamespace(VBProjects=_Boom())

class _Proj:
    def __init__(self):
        self.VBComponents = SimpleNamespace(Count=1)
    def __call__(self, i):
        return SimpleNamespace(Name="modMain", Type=1,
            CodeModule=SimpleNamespace(CountOfLines=2,
                Lines=lambda a, b: "Option Explicit" + CRLF + "Sub Main()" + CRLF))

class _VBProjCol:
    Count = 1
    def __call__(self, i): return _Proj()

class AppVBEOne:
    def __init__(self):
        self.VBE = SimpleNamespace(VBProjects=_VBProjCol())

def outcome(fn, *a, **k):
    try:
        v = fn(*a, **k)
        return {"raised": False, "value": repr(v)}
    except BaseException as e:
        trust = getattr(ses_mod, "VbaTrustRefusedError", ())
        return {"raised": True, "type": type(e).__name__, "module": type(e).__module__,
                "msg": str(e), "is_trust": isinstance(e, trust) if trust else False,
                "is_unavail": type(e).__name__ == "VbaProjectUnavailableError"}

def cell(name, fn):
    c = {"name": name}
    try:
        c["result"] = fn()
        c["ok"] = True
    except BaseException as e:
        c["ok"] = False
        c["exc_type"] = type(e).__name__
        c["exc_msg"] = str(e)
        c["trace_tail"] = traceback.format_exc().strip().splitlines()[-3:]
    R["cells"][name] = c

def strict_count(app):
    s = ses_mod.ComAccessSession(app)
    return outcome(s.vba_module_count)

cell("C2a_session_trust_nested", lambda: strict_count(AppVBEFail(TRUST_NESTED)))
cell("C2b_session_trust_direct", lambda: strict_count(AppVBEFail(TRUST_DIRECT)))
cell("C2c_session_trust_duck_hresult", lambda: strict_count(AppVBEFail(DuckTrustError())))
cell("C2d_session_unknown_nested_8000FFFF", lambda: strict_count(AppVBEFail(UNKNOWN_NESTED)))
cell("C2e_session_unknown_direct", lambda: strict_count(AppVBEFail(UNKNOWN_DIRECT)))
cell("C2f_session_empty_no_project", lambda: strict_count(AppVBEEmpty()))
cell("C2g_session_count_raises_com", lambda: strict_count(AppVBECountBoom()))
cell("C2h_session_success_count", lambda: strict_count(AppVBEOne()))

class AppVBEEmpty:
    def __init__(self): self.VBE = SimpleNamespace(VBProjects=SimpleNamespace(Count=0))

class FakeSession:
    def __init__(self, vba_count_fn): self._vba_count_fn = vba_count_fn
    def application_version(self): return "16.0"
    def set_automation_security(self, level): self._sec = level
    def read_automation_security(self): return self._sec
    def access_application_pid(self): return 4242
    def open_current_database(self, path): pass
    def close_current_database(self): pass
    def quit_application(self): pass
    def current_project_object_names(self, collection):
        return ["frmMain"] if collection == "AllForms" else []
    def save_as_text(self, object_type, name, destination):
        blob = bytes([255, 254]) + "Form=frmMain".encode("utf-16-le")
        Path(destination).write_bytes(blob)
    def vba_module_count(self): return self._vba_count_fn()
    def reference_count(self): return 0

def make_reader(session):
    ident = SimpleNamespace(pid=4242, creation=111, image="ACCESS.EXE")
    return app_logic.AppLogicReader(
        launcher=lambda: session,
        identity_reader=lambda pid: ident,
        emit_identity=lambda *a: None,
        assign_job=lambda pid: None,
        scratch_root=Path(tempfile.mkdtemp(prefix="t2probe-scratch-", dir=str(TMPD))),
    )

def extract(c):
    fams = []
    for x in (c.content or []):
        f = x.content
        st = getattr(f, "state", None) or getattr(getattr(f, "status", None), "state", None)
        reason = getattr(f, "reason", None) or getattr(getattr(f, "status", None), "reason", None)
        fams.append([getattr(x, "category", None), getattr(x, "name", None), str(st), str(reason)])
    refs = []
    for x in (c.references or []):
        refs.append([getattr(x, "name", None),
                     {p: str(getattr(getattr(x, p), "state", None)) for p in
                      ("path", "guid", "major", "minor", "built_in") if hasattr(x, p)}])
    return {"content": fams, "references": refs,
            "warnings": [str(w) for w in (c.warnings or [])]}

def read_vba(vba_count_fn):
    r = make_reader(FakeSession(vba_count_fn))
    try:
        return {"raised": False, "extract": extract(r.read(str(DUMMY)))}
    except BaseException as e:
        return {"raised": True, "type": type(e).__name__, "msg": str(e)}

cell("C4a_reader_vba_success", lambda: read_vba(lambda: 1))
cell("C4b_reader_vba_trust",
     lambda: read_vba(lambda: ses_mod.ComAccessSession(AppVBEFail(TRUST_NESTED)).vba_module_count()))
cell("C4c_reader_vba_unknown_8000FFFF",
     lambda: read_vba(lambda: ses_mod.ComAccessSession(AppVBEFail(UNKNOWN_NESTED)).vba_module_count()))
cell("C4d_reader_vba_empty",
     lambda: read_vba(lambda: ses_mod.ComAccessSession(AppVBEEmpty()).vba_module_count()))
cell("C4e_reader_vba_count_raises_com",
     lambda: read_vba(lambda: ses_mod.ComAccessSession(AppVBECountBoom()).vba_module_count()))

def stage(exc):
    def launch():
        raise exc
    ident = SimpleNamespace(pid=4242, creation=111, image="ACCESS.EXE")
    r = app_logic.AppLogicReader(launcher=launch, identity_reader=lambda pid: ident,
                                 emit_identity=lambda *a: None, assign_job=lambda pid: None,
                                 scratch_root=Path(tempfile.mkdtemp(prefix="t2probe-s2-", dir=str(TMPD))))
    try:
        return {"raised": False, "extract": extract(r.read(str(DUMMY)))}
    except BaseException as e:
        return {"raised": True, "type": type(e).__name__, "msg": str(e)}

cell("C5a_stage_ValueError", lambda: stage(ValueError("programmer defect " + SECRET)))
cell("C5b_stage_com_error_unknown", lambda: stage(UNKNOWN_NESTED))
cell("C5c_stage_OSError", lambda: stage(OSError("disk full " + SECRET)))
cell("C5d_stage_RuntimeError_bare", lambda: stage(RuntimeError("bare runtime " + SECRET)))
cell("C5e_stage_AttributeError", lambda: stage(AttributeError("none has no attr " + SECRET)))
cell("C5f_stage_KeyboardInterrupt", lambda: stage(KeyboardInterrupt()))
cell("C5g_stage_TypeError", lambda: stage(TypeError("bad type")))

def stage_reason_probe(exc):
    def launch():
        raise exc
    ident = SimpleNamespace(pid=4242, creation=111, image="ACCESS.EXE")
    r = app_logic.AppLogicReader(launcher=launch, identity_reader=lambda pid: ident,
                                 emit_identity=lambda *a: None, assign_job=lambda pid: None,
                                 scratch_root=Path(tempfile.mkdtemp(prefix="t2probe-s3-", dir=str(TMPD))))
    c = r.read(str(DUMMY))
    s = json.dumps(extract(c), default=str)
    return {"secret_present": SECRET in s, "sanitized": "PWD=***" in s, "sample": s[:400]}

cell("C6_secret_redaction_OSError", lambda: stage_reason_probe(OSError("copy failed " + SECRET)))
cell("C7_worker_ok_shape_check", lambda: {"has_main": hasattr(__import__(
    "ms_access_mcp.application.documentation_worker", fromlist=["main"]), "main")})

OUT.write_text(json.dumps(R, indent=1, default=str), encoding="utf-8")
print("WROTE", OUT)
