"""Fix C2f (empty project, strict+default) and C1d (clean default count-raise)."""
from __future__ import annotations
import json, logging, os, traceback
from pathlib import Path
from types import SimpleNamespace

import pythoncom

TREE = os.environ["PROBE_TREE"]
OUT = Path(os.environ["PROBE_OUT"])
R = {"tree": TREE, "package_root": None, "cells": {}}

import ms_access_mcp
R["package_root"] = str(Path(ms_access_mcp.__file__).resolve().parents[1])
from ms_access_mcp.backends.access import vba as vba_mod
from ms_access_mcp.backends.access import app_logic_session as ses_mod

UNKNOWN_NESTED = pythoncom.com_error(-2147352567, "Exception occurred.",
    (0, "Microsoft Access", "catastrophic", "help", 0, -2147418113), None)

class _Boom:
    @property
    def Count(self): raise UNKNOWN_NESTED

class AppVBECountBoomInst:
    def __init__(self): self.VBE = SimpleNamespace(VBProjects=_Boom())

class AppVBEEmpty:
    def __init__(self): self.VBE = SimpleNamespace(VBProjects=SimpleNamespace(Count=0))

def outcome(fn, *a, **k):
    try:
        v = fn(*a, **k)
        return {"raised": False, "value": repr(v)}
    except BaseException as e:
        trust = getattr(ses_mod, "VbaTrustRefusedError", ())
        return {"raised": True, "type": type(e).__name__, "module": type(e).__module__,
                "msg": str(e), "is_trust": isinstance(e, trust) if trust else False,
                "is_unavail": type(e).__name__ == "VbaProjectUnavailableError"}

def cell(name, fn):
    c = {"name": name}
    try:
        c["result"] = fn(); c["ok"] = True
    except BaseException as e:
        c["ok"] = False; c["exc_type"] = type(e).__name__; c["exc_msg"] = str(e)
        c["trace_tail"] = traceback.format_exc().strip().splitlines()[-3:]
    R["cells"][name] = c

def default_fail_logs(app):
    captured = []
    h = logging.Handler()
    h.emit = lambda rec: captured.append([rec.levelname, rec.getMessage()])
    lg = logging.getLogger(vba_mod.__name__)
    lg.addHandler(h); old = lg.level; lg.setLevel(logging.DEBUG)
    try:
        v = vba_mod.get_vb_project(app)
    finally:
        lg.removeHandler(h); lg.setLevel(old)
    return {"value": repr(v), "logs": captured}

cell("D1_default_empty_returns_None", lambda: outcome(vba_mod.get_vb_project, AppVBEEmpty()))
cell("D2_default_empty_logs_debug", lambda: default_fail_logs(AppVBEEmpty()))
cell("D3_strict_empty_unavailable", lambda: outcome(vba_mod.get_vb_project, AppVBEEmpty(), strict=True))
cell("D4_default_count_raise_raw", lambda: outcome(vba_mod.get_vb_project, AppVBECountBoomInst()))
cell("D5_strict_count_raise_classified", lambda: outcome(vba_mod.get_vb_project, AppVBECountBoomInst(), strict=True))
OUT.write_text(json.dumps(R, indent=1, default=str), encoding="utf-8")
print("WROTE", OUT)
