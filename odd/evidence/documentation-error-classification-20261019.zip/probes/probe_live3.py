"""Corrupted-copy Tier2 failure round 2: 4096-byte tail corruption, one escalation."""
from __future__ import annotations
import hashlib, io, json, os, sys
from pathlib import Path
from types import SimpleNamespace

TREE = os.environ["PROBE_TREE"]
OUT = Path(os.environ["PROBE_OUT"])
SCRATCH = Path(os.environ["PROBE_SCRATCH"])
R = {"tree": TREE, "package_root": None, "cells": {}}

import ms_access_mcp
R["package_root"] = str(Path(ms_access_mcp.__file__).resolve().parents[1])
from ms_access_mcp.application import documentation_worker as worker
from ms_access_mcp.application.documentation_worker import (
    build_request, decode_response_with_identities)
from ms_access_mcp.application import documentation_app_logic as app_logic
from ms_access_mcp.application.process_identity import read_process_identity

ORIGINAL = Path(r"D:/code/python/mcp-ms-access/db/fixtures/documentation/startup.accdb")
LIVE = SCRATCH / "live"
CORR = LIVE / f"live-corrupt3-{TREE}.accdb"
SCRATCH_DIR = LIVE / "t2_live_scratch"
SCRATCH_DIR.mkdir(exist_ok=True)
os.environ[app_logic.SCRATCH_DIR_ENV] = str(SCRATCH_DIR)
import shutil as _shutil
_shutil.copy2(ORIGINAL, CORR)

def run_worker(db_path, **extra):
    stdin_buf = io.BytesIO(json.dumps(
        build_request(db_path=str(db_path), backend="dao", allowed_dirs=[str(SCRATCH)],
                      tables=None, queries=None, **extra)).encode("utf-8"))
    stdout_rec = io.BytesIO(); stderr_rec = io.StringIO()
    real = (sys.stdin, sys.stdout, sys.__stdout__)
    try:
        sys.stdin = SimpleNamespace(buffer=stdin_buf)
        sys.stdout = SimpleNamespace(buffer=stdout_rec)
        sys.__stdout__ = stdout_rec
        code = worker.main([])
    finally:
        sys.stdin, sys.stdout, sys.__stdout__ = real
    ids, resp = decode_response_with_identities(stdout_rec.getvalue())
    return {"exit": code, "resp": resp,
            "identities": [[i.pid, i.creation, i.image] for i in ids]}

def summarize(resp):
    ev = resp.get("evidence", {})
    al = ev.get("data", {}).get("app_logic", {})
    return {"ok": resp.get("ok"), "error": resp.get("error"), "status": ev.get("status"),
            "tables": [t.get("name") for t in ev.get("data", {}).get("tables", [])],
            "warnings": ev.get("warnings", []),
            "families": [[x.get("category"), x.get("content", {}).get("state"),
                          (x.get("content", {}).get("reason") or "")[:260]]
                         for x in al.get("content", [])]}

def corrupt(fh_offset_len):
    with open(CORR, "r+b") as fh:
        fh.seek(0, os.SEEK_END)
        size = fh.tell()
        off = fh_offset_len[0] if fh_offset_len[0] >= 0 else size + fh_offset_len[0]
        fh.seek(off)
        fh.write(b"\x00\xff" * (fh_offset_len[1] // 2))
    return hashlib.sha256(CORR.read_bytes()).hexdigest()

R["cells"]["P0_passive_fresh"] = summarize(run_worker(CORR)["resp"])
R["db_size"] = CORR.stat().st_size
R["corrupt1_sha"] = corrupt((R["db_size"] // 2, 2048))
R["cells"]["P1_passive_mid2k"] = summarize(run_worker(CORR)["resp"])
res = run_worker(CORR, include_app_logic=True)
s = summarize(res["resp"])
cell = {"exit": res["exit"], **s}
if res["identities"]:
    pid, creation, image = res["identities"][-1]
    after = read_process_identity(pid)
    cell["owned_survivor_after"] = None if after is None else [after.pid, after.creation]
cell["laccdb_left"] = sorted(p.name for p in LIVE.glob("*.laccdb"))
R["cells"]["P2_tier2_mid2k"] = cell

tier2_still_succeeded = cell.get("status") == "complete" and cell.get("ok") is True
if tier2_still_succeeded:
    R["corrupt2_sha"] = corrupt((R["db_size"] // 3, 512))
    R["cells"]["P3_passive_third512"] = summarize(run_worker(CORR)["resp"])
    res = run_worker(CORR, include_app_logic=True)
    s = summarize(res["resp"])
    cell = {"exit": res["exit"], **s}
    if res["identities"]:
        pid, creation, image = res["identities"][-1]
        after = read_process_identity(pid)
        cell["owned_survivor_after"] = None if after is None else [after.pid, after.creation]
    cell["laccdb_left"] = sorted(p.name for p in LIVE.glob("*.laccdb"))
    R["cells"]["P4_tier2_third512"] = cell

R["original_sha_after"] = hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()
OUT.write_text(json.dumps(R, indent=1, default=str), encoding="utf-8")
print("WROTE", OUT)
