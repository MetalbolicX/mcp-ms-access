"""Shared constants and safety helpers for the T5 embedded form-event-macro spike.

ODD ``documentation-workflows-v2``, task **T5** (Specs S2, S5). Throwaway research
tooling: it lives entirely under ``db/fixtures/embedded-macro-requal/``, edits no
production file, and only *imports* the production fail-closed process verifier
(``ms_access_mcp.application.process_identity``, delivered by T2 and already used by
the T4 harness).

Safety contract enforced here (the same envelope as the three prior v2 matrices):

* every Access instance is a fresh ``DispatchEx`` owned by this harness;
* kills are PID+creation(+image) verified through the production verifier and never
  filter by image name (no process-name-wide kill, no baseline-diff kill);
* a pre-existing ``MSACCESS.EXE`` (foreign baseline PID) is never touched;
* canonical files (``db/fixtures/documentation``, ``db/northwind.accdb``) are hashed
  before and after and are never opened by Access;
* an armed copy is opened only after a positive ownership proof, an
  ``AutomationSecurity`` set-and-read-back gate, and a clear lock state;
* no registry / Trust Center / trusted-location change, no synthetic input, and no
  dialog is ever accepted -- windows are only observed and recorded.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

SCRATCH_DIR = Path(__file__).resolve().parent
ROOT = SCRATCH_DIR.parents[2]
# The production package is imported (never copied or edited) from the repository source.
for _entry in (str(ROOT), str(ROOT / "src")):
    if _entry not in sys.path:
        sys.path.insert(0, _entry)

from ms_access_mcp.application.process_identity import (  # noqa: E402
    ACCESS_IMAGE_NAME,
    list_msaccess_pids,
    process_is_alive,
    read_process_identity,
    terminate_verified_access,
)

# --- fixture vocabulary -----------------------------------------------------------------
FIXTURE_DB_NAME = "armed.accdb"
CANARY_TABLE = "CanaryRows"
CANARY_QUERY = "qryAppendCanary"
CANARY_PROBE_ID = 1
CANARY_LABEL = "EMBEDDED_MACRO"
# Exact saved append query: one known row, no other effect. Bracketed identifiers follow
# the L6 lesson (a previously reserved DDL identifier broke the build).
CANARY_INSERT_SQL = (
    "INSERT INTO CanaryRows ([ProbeID], [Label]) VALUES (1, 'EMBEDDED_MACRO')"
)
CANARY_EXPECTED_ROW = {"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL}
FORM_NAME = "frmCanary"
FORM_CONTROL_NAME = "txtProbe"
EVENT_NAME = "OnLoad"
# The startup form IS the trigger: the database property below makes opening the copy
# open this form, which fires its embedded event macro.
STARTUP_FORM_PROPERTY = "StartupForm"

# msoAutomationSecurity values.
MSO_LOW = 1
MSO_FORCE_DISABLE = 3

# Access.Application object/DoCmd constants (same values the generator uses).
AC_FORM = 2
AC_MODULE = 5
AC_TEXTBOX = 109
AC_SAVE_YES = 1
AC_SAVE_NO = 2
AC_DESIGN = 1
AC_NORMAL = 0
DB_VERSION = 128
DB_LONG = 4
DB_TEXT = 10
LOCALE = ";LANGID=0x0409;CP=1252;COUNTRY=0"

# Canonical protection targets: hashed before and after the whole matrix.
CANONICAL_TARGETS = (
    ROOT / "db" / "fixtures" / "documentation",
    ROOT / "db" / "northwind.accdb",
)


def expected_row() -> dict[str, Any]:
    return dict(CANARY_EXPECTED_ROW)


# --- hashing ----------------------------------------------------------------------------
def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical_hashes() -> dict[str, dict[str, Any]]:
    """Return ``{repo_relative_path: {sha256, bytes}}`` for every canonical target file."""
    result: dict[str, dict[str, Any]] = {}
    for target in CANONICAL_TARGETS:
        files = [target] if target.is_file() else sorted(p for p in target.rglob("*") if p.is_file())
        for path in files:
            result[str(path.relative_to(ROOT)).replace("\\", "/")] = {
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
    return result


def diff_hashes(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    before_keys = set(before)
    after_keys = set(after)
    changed = sorted(key for key in before_keys & after_keys if before[key] != after[key])
    return {
        "unchanged": not changed and before_keys == after_keys,
        "changed": changed,
        "added": sorted(after_keys - before_keys),
        "removed": sorted(before_keys - after_keys),
    }


# --- rows -------------------------------------------------------------------------------
def rows_match_expected(rows: Any) -> bool:
    """Exactly one row, exactly the known tuple (ordered field comparison)."""
    return isinstance(rows, list) and rows == [CANARY_EXPECTED_ROW]


def rows_empty(rows: Any) -> bool:
    return isinstance(rows, list) and rows == []


# --- io helpers -------------------------------------------------------------------------
def write_json_flushed(path: Path, payload: Any) -> None:
    """Write JSON and fsync it so a parent can read it while a child still runs."""
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n"
    with path.open("w", encoding="utf-8") as handle:
        handle.write(text)
        handle.flush()
        os.fsync(handle.fileno())


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="")


def read_json(path: Path, default: Any = None) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return default


def wait_until(predicate: Any, timeout: float, interval: float = 0.25) -> bool:
    deadline = time.monotonic() + max(float(timeout), 0.0)
    while True:
        if predicate():
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(interval)


def lock_file_for(db_path: Path) -> Path:
    return db_path.with_suffix(".laccdb")


def lock_files(directory: Path) -> list[str]:
    """Names of Access lock files beside a scratch copy; never deleted by the harness."""
    return sorted(path.name for path in directory.glob("*.laccdb"))


def wait_for_no_lock(db_path: Path, timeout: float = 10.0) -> bool:
    lock = lock_file_for(db_path)
    return wait_until(lambda: not lock.exists(), timeout)


def decode_save_as_text(raw: bytes) -> str:
    """Decode a SaveAsText export (UTF-16-LE-with-BOM or 8-bit ANSI)."""
    if raw.startswith(b"\xff\xfe") or raw.startswith(b"\xfe\xff"):
        return raw.decode("utf-16")
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


# --- process helpers --------------------------------------------------------------------
def baseline_pids() -> set[int]:
    """Pre-spawn Access baseline through the production enumerator."""
    return list_msaccess_pids()


def new_access_pids(baseline: set[int]) -> set[int]:
    return list_msaccess_pids() - set(baseline)


def verify_access_identity(
    pid: int | None,
    expected_creation: int | None,
    baseline_pids: set[int] | None = None,
) -> dict[str, Any]:
    """Fail-closed ownership proof for a captured Access PID (recorded, never a kill).

    Ownership requires ALL of: a pid, a pid absent from the foreign baseline, a
    non-null captured creation time, a live process whose current creation time still
    equals the captured value, and the ``MSACCESS.EXE`` image.
    """
    record: dict[str, Any] = {
        "pid": pid,
        "expected_creation": expected_creation,
        "owned": False,
        "reasons": [],
    }
    if pid is None:
        record["reasons"].append("no-pid")
        return record
    if baseline_pids and pid in baseline_pids:
        record["reasons"].append("pid-in-baseline")
        return record
    if expected_creation is None:
        record["reasons"].append("no-captured-creation")
        return record
    live = read_process_identity(pid)
    if live is None:
        record["reasons"].append("identity-unreadable")
        record["alive"] = process_is_alive(pid)
        return record
    record["observed_creation"] = live.creation
    record["image"] = live.image
    if live.creation != expected_creation:
        record["reasons"].append("creation-mismatch")
        return record
    if live.image.casefold() != ACCESS_IMAGE_NAME.casefold():
        record["reasons"].append(f"image-not-{ACCESS_IMAGE_NAME}")
        return record
    record["owned"] = True
    return record


def reap_access(
    access_pid: int | None,
    access_creation: int | None,
    access_image: str | None,
    baseline_pids: set[int] | None = None,
    *,
    grace_seconds: float = 10.0,
) -> dict[str, Any]:
    """Production fail-closed owned-Access reap; performs NO kill unless all proofs hold."""
    if not access_pid or access_creation is None:
        return {
            "pid": access_pid,
            "verified": False,
            "terminated": False,
            "exited": access_pid is None,
            "detail": "no captured Access pid/creation; no kill attempted",
        }
    termination = terminate_verified_access(
        pid=int(access_pid),
        creation=int(access_creation),
        image=access_image or ACCESS_IMAGE_NAME,
        baseline_pids=frozenset(baseline_pids or set()),
        grace_seconds=grace_seconds,
    )
    return dataclasses.asdict(termination)


def verified_kill_python(pid: int, creation: int | None) -> dict[str, Any]:
    """PID+creation-scoped ``taskkill /F /PID`` for one harness-owned Python child.

    Fails CLOSED: without a live process whose creation time still equals the recorded
    one and whose image is a Python interpreter, no kill is issued. The kill is always a
    single PID-scoped force-kill, never a process-name filter.
    """
    record: dict[str, Any] = {
        "pid": pid,
        "expected_creation": creation,
        "result": "skipped-unverified-no-kill",
    }
    if not isinstance(pid, int) or pid <= 0 or creation is None:
        record["detail"] = "missing pid or creation; no kill attempted"
        return record
    if pid == os.getpid():
        record["detail"] = "refusing to kill the harness's own process; no kill attempted"
        return record
    live = read_process_identity(pid)
    if live is None:
        record["result"] = "already-exited-no-kill"
        return record
    record["observed_creation"] = live.creation
    record["observed_image"] = live.image
    if live.creation != creation:
        record["detail"] = "live creation time differs from the recorded one; no kill attempted"
        return record
    if not live.image.casefold().startswith("python"):
        record["detail"] = f"image {live.image!r} is not a Python interpreter; no kill attempted"
        return record
    completed = subprocess.run(  # noqa: S603 - fixed argv, PID-scoped, never a shell
        ["taskkill", "/F", "/PID", str(pid)], capture_output=True, text=True, timeout=30, check=False
    )
    record["result"] = "killed" if completed.returncode == 0 else "taskkill-failed"
    record["taskkill_returncode"] = completed.returncode
    record["taskkill_stdout"] = completed.stdout.strip()
    record["taskkill_stderr"] = completed.stderr.strip()
    record["exited"] = wait_until(lambda: not process_is_alive(pid), 10.0)
    return record


# --- COM error formatting ---------------------------------------------------------------
def describe_com_error(exc: BaseException) -> dict[str, Any]:
    """Record one exception without losing its COM diagnostic shape."""
    record: dict[str, Any] = {
        "type": type(exc).__name__,
        "str": str(exc),
        "args": [repr(item) for item in getattr(exc, "args", ())],
        "hresult": None,
        "message": None,
        "excepinfo": None,
        "scode": None,
        "description": None,
        "source": None,
    }
    args = getattr(exc, "args", ())
    if args and isinstance(args[0], int):
        record["hresult"] = args[0]
    if len(args) > 1 and isinstance(args[1], str):
        record["message"] = args[1]
    excepinfo = getattr(exc, "excepinfo", None)
    if excepinfo:
        items = list(excepinfo)
        record["excepinfo"] = [repr(item) for item in items]
        if len(items) > 1 and isinstance(items[1], str):
            record["source"] = items[1]
        if len(items) > 2 and isinstance(items[2], str):
            record["description"] = items[2]
        if len(items) > 5 and isinstance(items[5], int):
            record["scode"] = items[5]
    return record


def safe_call(thunk: Any) -> dict[str, Any]:
    """Run ``thunk`` and return ``{ok, value}`` or ``{ok: False, error}``."""
    try:
        return {"ok": True, "value": thunk()}
    except Exception as exc:  # noqa: BLE001 - a failed read is evidence, never a crash
        return {"ok": False, "error": describe_com_error(exc)}


# --- read-only dialog observation -------------------------------------------------------
class WindowObserver(threading.Thread):
    """Record (never dismiss) every visible top-level window owned by the target PIDs."""

    def __init__(self, target_pids: set[int] | list[int]) -> None:
        super().__init__(daemon=True)
        self._targets = {int(pid) for pid in target_pids}
        # Deliberately NOT named ``_stop``: ``threading.Thread._stop`` is a private
        # method, and shadowing it broke the T3 attempt-1 harness (L12).
        self._stop_event = threading.Event()
        self.windows: list[dict[str, Any]] = []
        self.error: str | None = None

    def run(self) -> None:
        try:
            from tests.helpers.dialog_watcher import collect_windows
        except Exception as exc:  # noqa: BLE001 - observation is best-effort, never fatal
            self.error = f"{type(exc).__name__}: {exc}"
            return
        while not self._stop_event.is_set():
            try:
                for window in collect_windows(self._targets):
                    item = {
                        "hwnd": hex(window.hwnd),
                        "owner_pid": window.owner_pid,
                        "owner_image": window.owner_image,
                        "class": window.class_name,
                        "title": window.title,
                        "is_dialog_class": window.class_name == "#32770",
                    }
                    if item not in self.windows:
                        self.windows.append(item)
            except Exception as exc:  # noqa: BLE001 - a sampling error is recorded, not raised
                self.error = f"{type(exc).__name__}: {exc}"
            self._stop_event.wait(0.5)

    def stop(self) -> None:
        self._stop_event.set()
        if self.ident is not None:  # never join a thread that was not started
            self.join(timeout=3.0)


def sample_windows(access_pid: int | None) -> list[dict[str, Any]]:
    """Parent-side read-only window sample (used before any hard kill)."""
    if not access_pid:
        return []
    try:
        from tests.helpers.dialog_watcher import collect_windows

        return [
            {
                "hwnd": hex(window.hwnd),
                "owner_pid": window.owner_pid,
                "owner_image": window.owner_image,
                "class": window.class_name,
                "title": window.title,
                "is_dialog_class": window.class_name == "#32770",
            }
            for window in collect_windows({access_pid})
        ]
    except Exception as exc:  # noqa: BLE001
        return [{"observer_error": f"{type(exc).__name__}: {exc}"}]


# --- DAO engine-level observation (never instantiates Access) ---------------------------
def read_canary_snapshot(db_path: Path) -> dict[str, Any]:
    """Independent DAO-only observation of a disposable copy.

    Opens the copy through ``DAO.DBEngine.120``, records the full canary row set, the
    object inventory (tables, QueryDefs, Containers), and the ``StartupForm`` database
    property, then closes. It executes nothing and writes nothing.
    """
    import gc

    import pythoncom
    import win32com.client

    record: dict[str, Any] = {
        "schema": "v2-spike-embedded.dao-read/1",
        "db": str(db_path),
        "ok": False,
        "rows": [],
        "row_count": 0,
        "dao_error": None,
        "inventory_error": None,
        "canary_table_present": False,
        "querydefs": {},
        "tables": [],
        "containers": {},
        "startup_form_property": None,
        "db_bytes": None,
    }
    pythoncom.CoInitialize()
    engine = None
    db = None
    recordset = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        db = engine.OpenDatabase(str(db_path), False, True)
        try:
            tables = [str(db.TableDefs(i).Name) for i in range(db.TableDefs.Count)]
            record["tables"] = sorted(tables)
            record["canary_table_present"] = CANARY_TABLE in tables
            querydefs: dict[str, str] = {}
            for i in range(db.QueryDefs.Count):
                query = db.QueryDefs(i)
                try:
                    querydefs[str(query.Name)] = str(query.SQL)
                except Exception as exc:  # noqa: BLE001
                    querydefs[str(query.Name)] = f"<unreadable: {exc}>"
            record["querydefs"] = querydefs
            for container_name in ("Modules", "Forms", "Reports", "Scripts"):
                try:
                    container = db.Containers(container_name)
                    names = [str(container.Documents(i).Name) for i in range(container.Documents.Count)]
                    record["containers"][container_name] = sorted(names)
                except Exception as exc:  # noqa: BLE001
                    record["containers"][container_name] = f"<unreadable: {exc}>"
            try:
                record["startup_form_property"] = str(db.Properties(STARTUP_FORM_PROPERTY).Value)
            except Exception:
                record["startup_form_property"] = None
        except Exception as exc:  # noqa: BLE001
            record["inventory_error"] = repr(exc)

        rows: list[dict[str, Any]] = []
        recordset = db.OpenRecordset(
            f"SELECT [ProbeID], [Label] FROM {CANARY_TABLE} ORDER BY [ProbeID]", 4
        )
        while not recordset.EOF:
            rows.append(
                {
                    "ProbeID": int(recordset.Fields("ProbeID").Value),
                    "Label": str(recordset.Fields("Label").Value),
                }
            )
            recordset.MoveNext()
        record["rows"] = rows
        record["row_count"] = len(rows)
        record["ok"] = True
    except Exception as exc:  # noqa: BLE001 - a read failure is evidence, not silence
        record["dao_error"] = repr(exc)
    finally:
        if recordset is not None:
            try:
                recordset.Close()
            except Exception:  # noqa: BLE001
                pass
        recordset = None
        if db is not None:
            try:
                db.Close()
            except Exception:  # noqa: BLE001
                pass
        db = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()
    try:
        record["db_bytes"] = db_path.stat().st_size
    except OSError:
        record["db_bytes"] = None
    return record


def snapshot_trigger_evidence(snapshot: dict[str, Any] | None) -> dict[str, Any]:
    """Reduce one DAO snapshot to the trigger facts the matrix gates on."""
    snapshot = snapshot or {}
    containers = snapshot.get("containers") or {}
    forms = containers.get("Forms")
    scripts = containers.get("Scripts")
    modules = containers.get("Modules")
    startup_form = snapshot.get("startup_form_property")
    return {
        "canary_table_present": bool(snapshot.get("canary_table_present")),
        "querydef_present": CANARY_QUERY in (snapshot.get("querydefs") or {}),
        "forms_container": forms,
        "modules_container": modules,
        "scripts_container": scripts,
        "startup_form_property": startup_form,
        "form_document_present": isinstance(forms, list) and FORM_NAME in forms,
        "startup_form_is_trigger": startup_form == FORM_NAME,
        "no_named_macros": isinstance(scripts, list) and scripts == [],
        "no_vba_modules": isinstance(modules, list) and modules == [],
        "db_bytes": snapshot.get("db_bytes"),
    }


def arm_startup_form(db_path: Path, form_name: str = FORM_NAME) -> dict[str, Any]:
    """LAST build mutation: set the ``StartupForm`` database property through DAO.

    Engine-level only -- Access is never reopened for the arming step, so the armed
    fixture is never instantiated by ``Access.Application`` during the build.
    """
    import gc

    import pythoncom
    import win32com.client

    record: dict[str, Any] = {
        "db": str(db_path),
        "property": STARTUP_FORM_PROPERTY,
        "value": form_name,
        "deleted_existing": None,
        "appended": False,
        "readback": None,
        "error": None,
    }
    pythoncom.CoInitialize()
    engine = None
    db = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        db = engine.OpenDatabase(str(db_path), False, False)
        try:
            db.Properties.Delete(STARTUP_FORM_PROPERTY)
            record["deleted_existing"] = True
        except Exception:  # noqa: BLE001 - absent property is the normal case
            record["deleted_existing"] = False
        prop = db.CreateProperty(STARTUP_FORM_PROPERTY, DB_TEXT, form_name)
        db.Properties.Append(prop)
        db.Properties.Refresh()
        record["appended"] = True
        record["readback"] = str(db.Properties(STARTUP_FORM_PROPERTY).Value)
    except Exception as exc:  # noqa: BLE001
        record["error"] = repr(exc)
    finally:
        if db is not None:
            try:
                db.Close()
            except Exception:  # noqa: BLE001
                pass
        db = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()
    return record


__all__ = [name for name in dir() if not name.startswith("_")]
