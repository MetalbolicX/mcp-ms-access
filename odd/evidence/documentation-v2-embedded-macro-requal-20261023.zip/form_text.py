r"""Pure form-text dialect ladder for the embedded event-macro build (no COM here).

The research question needs a form whose event carries an **embedded macro** whose sole
action is ``OpenQuery("qryAppendCanary")``. Access exposes no documented object-model call
that creates an embedded event macro, so the builder attempts the sanctioned route instead:
build the form with ``CreateForm``/``CreateControl`` (proven in T4), let Access itself emit
the form text with ``SaveAsText``, modify that text to attach the embedded macro, and
``LoadFromText`` it back. Every candidate framing below is therefore *mixed into Access'
own text*, never into a hand-written form dialect.

This module is deliberately COM-free and side-effect-free so ``run_spike.py
--self-check`` can prove, bounded and offline, that

* each candidate inserts the placeholder property exactly once,
* each body candidate inserts the ``OnLoadEmMacro`` block and the
  OpenQuery/query-name markers,
* the insertion lands in the form-property region (before the first nested ``Begin``),
* the AXL comment is wrapped onto ~80-character quoted continuation lines,
* the candidate list is bounded and ordered (no unbounded search).

Real grammar (ground truth, not invented)
-----------------------------------------
The previous ladder (E0-E4) failed only because every framing used an invented block
keyword: Access rejected each one *at the keyword* (``Expected: 'Begin'. Found:
Embedded.``, ``Expected: 'Begin'. Found: Macro.``, ``Expected: 'End'. Found:
EmbeddedMacro.``, ``Expected: 'Begin'. Found: Version.``). The real SaveAsText grammar for
an embedded event macro is a **property block** named ``<EventProperty>EmMacro``:

.. code-block:: text

    OnClickEmMacro = Begin
        Version =196611
        Begin
            Action ="OpenReport"
            Argument ="rptLearn"
        End
        Begin
            Comment ="_AXL:<x/>"
        End
    End

(``accdt`` crate parser for Microsoft ``.accdt`` templates; Microsoft Q&A: "each embedded
macro starts with text like ' EmMacro = Begin'"). Each macro action is an anonymous
``Begin`` ... ``End`` carrying ``Action =`` and repeated ``Argument =`` lines, and a real
Access 2010+ export additionally stores the AXL body in a ``Comment ="_AXL:..."`` block.
Long quoted strings wrap at ~80 characters onto continuation lines that hold only a quoted
fragment; escapes are ``\\"``, ``\\\\`` and ``\\015\\012``. The wrapping and the AXL
shape are copied from the *live captured* named-macro text in
``src/ms_access_mcp/backends/access/macros.py`` (``Comment ="_AXL:...`` split across four
lines of 80-character fragments).

Two details that came out of the archived E0-E4 evidence and shape the insertion order:

* ``OnLoad ="[Embedded Macro]"`` alone imports and round-trips (E0), so the placeholder is
  a legal form property and stays exactly as Access writes it;
* a property assignment placed *immediately after* the placeholder was rejected with
  ``Expected: 'End'. Found: EmbeddedMacro.`` (E2), while a block opener in that position
  was accepted (E0). The ``OnLoadEmMacro`` block is therefore inserted **before** the
  placeholder, leaving the placeholder as the last property line, directly above the
  controls container -- the exact shape E0 proved importable.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any

EVENT_PROPERTY = "OnLoad"
PLACEHOLDER_VALUE = "[Embedded Macro]"
PLACEHOLDER_LINE = f'    {EVENT_PROPERTY} ="{PLACEHOLDER_VALUE}"'

#: Form-text property that carries the embedded macro body (real SaveAsText grammar).
MACRO_PROPERTY = f"{EVENT_PROPERTY}EmMacro"
#: ``Version`` value Access writes for a macro body (live captured 2026-10-10).
MACRO_VERSION = "196611"
#: Width of one quoted fragment, matching the live captured named-macro text (80 chars).
QUOTE_WRAP_WIDTH = 80
#: Insertion order: the macro block first, the placeholder last (see the module docstring).
INSERT_ORDER = "macro-block-then-placeholder"

#: Escapes understood by the form-text dialect: ``\015`` (three digits) and ``\x``.
_ESCAPE_UNIT = re.compile(r"\\(?:\d{3}|.)", re.DOTALL)

#: The real AXL body of one embedded ``OpenQuery`` action, in *file* escaping (``\"`` for a
#: quote, ``\015\012`` for the CRLF between the XML declaration and the root element).
AXL_COMMENT_VALUE = (
    '_AXL:<?xml version=\\"1.0\\" encoding=\\"UTF-16\\" standalone=\\"no\\"?>\\015\\012'
    '<UserInterfaceMacro For=\\"frmCanary\\" Event=\\"OnLoad\\" '
    'xmlns=\\"http://schemas.microsoft.com/office/accessservices/2009/11/application\\">'
    '<Statements><Action Name=\\"OpenQuery\\">'
    '<Argument Name=\\"QueryName\\">qryAppendCanary</Argument>'
    '</Action></Statements></UserInterfaceMacro>'
)

# Markers the builder searches for in Access' own round-tripped form text.
ROUNDTRIP_BODY_MARKERS = ("openquery", "qryappendcanary")
# The stricter bar also requires the macro block itself to survive the re-export.
ROUNDTRIP_MACRO_BLOCK = re.compile(r"OnLoadEmMacro\s*=\s*Begin", re.IGNORECASE)

# Synthetic form text used ONLY by ``--self-check`` to exercise the pure helpers. It
# mirrors the shape of the archived T4 ``export_form.txt`` (form properties, then a bare
# Begin block holding a section with one control) and is never used for a live build.
SYNTHETIC_BASE_FORM_TEXT = "\r\n".join(
    [
        "Version =21",
        "VersionRequired =20",
        "Checksum =272465623",
        "Begin Form",
        '    Width =6000',
        '    DatasheetFontName ="Aptos"',
        "    Begin",
        "        Begin Section",
        '            Name ="Detail"',
        "            Begin",
        "                Begin TextBox",
        '                    Name ="txtProbe"',
        "                End",
        "            End",
        "        End",
        "    End",
        "End",
        "",
    ]
)


def strip_checksum_lines(base_text: str) -> tuple[str, int]:
    """Drop the stale ``Checksum`` line from Access' own exported form text.

    Access writes a content checksum into the form text; modifying the text without
    removing it would leave a checksum that no longer describes the object, which is a
    plausible reason for ``LoadFromText`` to reject the import. The count of removed
    lines is recorded as evidence either way.
    """
    newline = "\r\n" if "\r\n" in base_text else "\n"
    lines = base_text.split(newline)
    kept = [line for line in lines if not line.strip().startswith("Checksum =")]
    return newline.join(kept), len(lines) - len(kept)


def form_property_insert_index(lines: list[str]) -> int:
    """Index of the first nested ``Begin`` inside ``Begin Form`` (the insertion point).

    Falls back to the final ``End`` line so an unusual (but still parsed) form text is
    handled deterministically rather than by guessing.
    """
    start = None
    for index, line in enumerate(lines):
        if line.strip() == "Begin Form":
            start = index + 1
            break
    if start is None:
        return 0
    for index in range(start, len(lines)):
        stripped = lines[index].strip()
        if not stripped:
            continue
        if len(lines[index]) - len(lines[index].lstrip(" ")) == 4 and stripped.startswith("Begin"):
            return index
    for index in range(len(lines) - 1, start - 1, -1):
        if lines[index].strip() == "End":
            return index
    return len(lines)


def insert_block(base_text: str, block_lines: tuple[str, ...]) -> tuple[str, int]:
    """Insert ``block_lines`` into the form-property region; return text and index."""
    newline = "\r\n" if "\r\n" in base_text else "\n"
    lines = base_text.split(newline)
    index = form_property_insert_index(lines)
    merged = lines[:index] + list(block_lines) + lines[index:]
    return newline.join(merged), index


# ---------------------------------------------------------------------------------------
# quote wrapping (the real dialect's continuation lines)
# ---------------------------------------------------------------------------------------
def escape_units(value: str) -> list[str]:
    """Split an escaped dialect value into atomic units (an escape is never split)."""
    units: list[str] = []
    index = 0
    while index < len(value):
        match = _ESCAPE_UNIT.match(value, index)
        if match is not None:
            units.append(match.group(0))
            index = match.end()
        else:
            units.append(value[index])
            index += 1
    return units


def wrap_quoted_value(value: str, width: int = QUOTE_WRAP_WIDTH) -> list[str]:
    """Wrap one escaped value into ``width``-character fragments (Access continuation form).

    The live captured named-macro text proves the convention: the first line carries
    ``Name ="<fragment>"`` and every continuation line carries only ``"<fragment>"``, one
    fragment per line, 80 characters wide. An escape sequence is never split across two
    fragments.
    """
    fragments: list[str] = []
    current = ""
    for unit in escape_units(value):
        if current and len(current) + len(unit) > width:
            fragments.append(current)
            current = ""
        current += unit
    fragments.append(current)
    return fragments


def quoted_property_lines(
    name: str, value: str, *, indent: int, wrap: bool
) -> tuple[str, ...]:
    """Render ``name ="value"`` with Access' quoted-continuation wrapping."""
    fragments = wrap_quoted_value(value) if wrap else [value]
    pad = " " * indent
    lines = [f'{pad}{name} ="{fragments[0]}"']
    for fragment in fragments[1:]:
        lines.append(f'{" " * (indent + 4)}"{fragment}"')
    return tuple(lines)


# ---------------------------------------------------------------------------------------
# candidates
# ---------------------------------------------------------------------------------------
def macro_block_lines(
    *, columns_shown: int, axl: str, wrap_axl: bool = True
) -> tuple[str, ...]:
    """Render the real ``OnLoadEmMacro = Begin`` property block.

    ``axl`` selects the 2010+ AXL comment: ``"wrapped"`` (default), ``"single"`` (one
    line) or ``"none"`` (legacy action rows only).
    """
    lines = [
        f"    {MACRO_PROPERTY} = Begin",
        f"        Version ={MACRO_VERSION}",
        f"        ColumnsShown ={columns_shown}",
        "        Begin",
        '            Action ="OpenQuery"',
        '            Argument ="qryAppendCanary"',
        '            Argument ="0"',
        '            Argument ="1"',
        "        End",
    ]
    if axl != "none":
        lines.append("        Begin")
        lines.extend(
            quoted_property_lines(
                "Comment", AXL_COMMENT_VALUE, indent=12, wrap=(axl == "wrapped" and wrap_axl)
            )
        )
        lines.append("        End")
    lines.append("    End")
    return tuple(lines)


def _candidate_block(*, columns_shown: int, axl: str, wrap_axl: bool = True) -> tuple[str, ...]:
    """Return the inserted region: macro block, one blank line, then the placeholder."""
    return macro_block_lines(
        columns_shown=columns_shown, axl=axl, wrap_axl=wrap_axl
    ) + ("", PLACEHOLDER_LINE)


def _candidate_f0(base_text: str) -> tuple[str, int]:
    """Insert the placeholder property only (no macro body block) -- the E0 diagnostic."""
    return insert_block(base_text, (PLACEHOLDER_LINE,))


def _candidate_f1(base_text: str) -> tuple[str, int]:
    """Real grammar, wrapped AXL comment, ``ColumnsShown =8``."""
    return insert_block(base_text, _candidate_block(columns_shown=8, axl="wrapped"))


def _candidate_f2(base_text: str) -> tuple[str, int]:
    """As F1 but the AXL comment on a single line."""
    return insert_block(base_text, _candidate_block(columns_shown=8, axl="single"))


def _candidate_f3(base_text: str) -> tuple[str, int]:
    """As F1 without the AXL comment block (legacy action rows only)."""
    return insert_block(base_text, _candidate_block(columns_shown=8, axl="none"))


def _candidate_f4(base_text: str) -> tuple[str, int]:
    """As F1 with ``ColumnsShown =0``."""
    return insert_block(base_text, _candidate_block(columns_shown=0, axl="wrapped"))


EMBEDDING_CANDIDATES: tuple[dict[str, Any], ...] = (
    {
        "id": "F0",
        "description": "placeholder property only (no macro body block) - diagnostic",
        "body": False,
        "axl": "none",
        "columns_shown": None,
        "build": _candidate_f0,
    },
    {
        "id": "F1",
        "description": "`OnLoadEmMacro = Begin` block, Version 196611, ColumnsShown 8, "
        "OpenQuery action rows, wrapped AXL comment block",
        "body": True,
        "axl": "wrapped",
        "columns_shown": 8,
        "build": _candidate_f1,
    },
    {
        "id": "F2",
        "description": "as F1 with the AXL comment on one line",
        "body": True,
        "axl": "single",
        "columns_shown": 8,
        "build": _candidate_f2,
    },
    {
        "id": "F3",
        "description": "as F1 without the AXL comment block (legacy action rows only)",
        "body": True,
        "axl": "none",
        "columns_shown": 8,
        "build": _candidate_f3,
    },
    {
        "id": "F4",
        "description": "as F1 with ColumnsShown =0",
        "body": True,
        "axl": "wrapped",
        "columns_shown": 0,
        "build": _candidate_f4,
    },
)

CANDIDATE_IDS: tuple[str, ...] = tuple(str(candidate["id"]) for candidate in EMBEDDING_CANDIDATES)


def candidate_by_id(candidate_id: str) -> dict[str, Any]:
    """Return the candidate descriptor for ``candidate_id``."""
    for candidate in EMBEDDING_CANDIDATES:
        if candidate["id"] == candidate_id:
            return candidate
    raise KeyError(f"unknown embedding candidate: {candidate_id}")


def build_candidate_text(candidate_id: str, base_text: str) -> tuple[str, int]:
    """Strip the stale checksum, then insert the candidate block; return text + index."""
    candidate = candidate_by_id(candidate_id)
    stripped, _removed = strip_checksum_lines(base_text)
    build: Callable[[str], tuple[str, int]] = candidate["build"]
    return build(stripped)


# ---------------------------------------------------------------------------------------
# structural expectations (offline proof, also used by --self-check)
# ---------------------------------------------------------------------------------------
def _comment_continuation_lines(lines: list[str]) -> list[str]:
    """Continuation lines that belong to the AXL ``Comment`` value (only quoted fragments)."""
    continuations: list[str] = []
    collecting = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("Comment =\""):
            collecting = True
            continue
        if collecting:
            if stripped.startswith('"') and stripped.endswith('"') and len(stripped) > 1:
                continuations.append(stripped)
                continue
            collecting = False
    return continuations


def candidate_markers(candidate_id: str, base_text: str) -> dict[str, Any]:
    """Structural expectations for one candidate against ``base_text``."""
    candidate = candidate_by_id(candidate_id)
    _stripped, removed = strip_checksum_lines(base_text)
    text, index = build_candidate_text(candidate_id, base_text)
    lines = text.splitlines()
    placeholder_count = sum(1 for line in lines if line == PLACEHOLDER_LINE)
    lowered = text.lower()
    body = bool(candidate["body"])
    continuations = _comment_continuation_lines(lines)
    axl_lines = [line for line in lines if "_AXL:" in line]
    return {
        "stale_checksum_removed": "Checksum =" not in text,
        "checksum_lines_removed": removed,
        "placeholder_present_once": placeholder_count == 1,
        "placeholder_last_property": INSERT_ORDER == "macro-block-then-placeholder",
        "macro_block_present": (not body) or f"    {MACRO_PROPERTY} = Begin" in lines,
        "action_present": (not body) or 'Action ="OpenQuery"' in text,
        "argument_present": (not body) or 'Argument ="qryAppendCanary"' in text,
        "body_markers_present": (not body)
        or all(marker in lowered for marker in ROUNDTRIP_BODY_MARKERS),
        "axl_mode": candidate["axl"],
        "axl_present": bool(axl_lines),
        "axl_single_line": bool(axl_lines) and not continuations and candidate["axl"] == "single",
        "axl_wrapped": bool(axl_lines) and bool(continuations),
        "axl_continuation_count": len(continuations),
        "axl_continuations_quoted_only": all(
            line.startswith('"') and line.endswith('"') for line in continuations
        ),
        "axl_fragments_within_width": all(
            len(line) - 2 <= QUOTE_WRAP_WIDTH for line in continuations
        ),
        "axl_has_for_and_event": (not axl_lines)
        or ('For=\\"frmCanary\\"' in text and 'Event=\\"OnLoad\\"' in text),
        "columns_shown": candidate["columns_shown"],
        "columns_shown_present": (not body)
        or f"        ColumnsShown ={candidate['columns_shown']}" in lines,
        "version_present": (not body) or f"        Version ={MACRO_VERSION}" in lines,
        "no_form_removal": "Begin Form" in text and newline_end_present(text),
        "insert_index_in_property_region": index > 0,
        "base_text_prefix_preserved": text.splitlines()[0] == base_text.splitlines()[0]
        if base_text.splitlines()
        else True,
    }


def newline_end_present(text: str) -> bool:
    """Report whether the modified text still ends with an ``End`` line (form intact)."""
    lines = [line for line in text.splitlines() if line.strip()]
    return bool(lines) and lines[-1].strip() == "End"


# ---------------------------------------------------------------------------------------
# Access re-export inspection (run on the round-tripped text, not on our own candidate)
# ---------------------------------------------------------------------------------------
def roundtrip_has_event_macro_block(roundtrip_text: str) -> bool:
    """Report whether Access' own re-export carries an ``OnLoadEmMacro`` block."""
    return ROUNDTRIP_MACRO_BLOCK.search(roundtrip_text) is not None


def roundtrip_body_markers_found(roundtrip_text: str) -> bool:
    """Report whether the action and the canary query name survived the re-export."""
    lowered = roundtrip_text.lower()
    return all(marker in lowered for marker in ROUNDTRIP_BODY_MARKERS)


def roundtrip_structure_intact(roundtrip_text: str) -> bool:
    """Report whether the form's own structure survived (form, section, control)."""
    return (
        "Begin Form" in roundtrip_text
        and "Begin Section" in roundtrip_text
        and "txtProbe" in roundtrip_text
        and newline_end_present(roundtrip_text)
    )


def extract_macro_block(roundtrip_text: str) -> str | None:
    """Return the ``OnLoadEmMacro`` block exactly as Access re-exported it (evidence)."""
    lines = roundtrip_text.splitlines()
    start = None
    for index, line in enumerate(lines):
        if ROUNDTRIP_MACRO_BLOCK.search(line):
            start = index
            break
    if start is None:
        return None
    depth = 0
    for index in range(start, len(lines)):
        stripped = lines[index].strip()
        if stripped.startswith("Begin") or " = Begin" in stripped:
            depth += 1
        elif stripped == "End":
            depth -= 1
            if depth == 0:
                return "\n".join(lines[start : index + 1])
    return "\n".join(lines[start:])


# ---------------------------------------------------------------------------------------
# selection (strict: the body must be visible in Access' own re-export)
# ---------------------------------------------------------------------------------------
ATTEMPT_BAR_KEYS = (
    "load_ok",
    "readback_matches_placeholder",
    "roundtrip_placeholder_found",
    "roundtrip_has_event_macro_block",
    "roundtrip_body_markers_found",
    "roundtrip_structure_intact",
)


def attempt_meets_bar(attempt: dict[str, Any]) -> bool:
    """Stricter bar: import, design-view readback, and a body-bearing re-export.

    Ground truth for the grammar now exists, so an invisible body is no longer an
    acceptable outcome: the candidate must import, keep the stored event value as
    ``"[Embedded Macro]"`` in design view, keep the form structure, and Access' own
    ``SaveAsText`` re-export must contain the ``OnLoadEmMacro`` block with ``OpenQuery``
    and ``qryAppendCanary``.
    """
    return all(attempt.get(key) for key in ATTEMPT_BAR_KEYS)


def select_body_attempt(attempts: list[dict[str, Any]]) -> dict[str, Any] | None:
    """First *body-bearing* candidate that meets the bar, or ``None`` (-> BUILD_BLOCKER).

    ``F0`` (placeholder only) is diagnostic evidence, never a result: an event property
    naming an embedded macro with no accepted body block cannot carry the canary action,
    so installing it would make the whole experiment vacuous. Selection is first-match in
    the fixed ladder order (no ranking, no fallback framing).
    """
    for attempt in attempts:
        if attempt.get("expects_body") and attempt_meets_bar(attempt):
            return attempt
    return None


__all__ = [
    "ATTEMPT_BAR_KEYS",
    "AXL_COMMENT_VALUE",
    "CANDIDATE_IDS",
    "EMBEDDING_CANDIDATES",
    "EVENT_PROPERTY",
    "INSERT_ORDER",
    "MACRO_PROPERTY",
    "MACRO_VERSION",
    "PLACEHOLDER_LINE",
    "PLACEHOLDER_VALUE",
    "QUOTE_WRAP_WIDTH",
    "ROUNDTRIP_BODY_MARKERS",
    "SYNTHETIC_BASE_FORM_TEXT",
    "attempt_meets_bar",
    "build_candidate_text",
    "candidate_by_id",
    "candidate_markers",
    "escape_units",
    "extract_macro_block",
    "form_property_insert_index",
    "insert_block",
    "macro_block_lines",
    "newline_end_present",
    "quoted_property_lines",
    "roundtrip_body_markers_found",
    "roundtrip_has_event_macro_block",
    "roundtrip_structure_intact",
    "select_body_attempt",
    "strip_checksum_lines",
    "wrap_quoted_value",
]
