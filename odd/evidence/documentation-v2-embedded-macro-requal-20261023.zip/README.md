# T5 embedded form-event-macro canary spike — scratch harness (re-qualification, throwaway)

Scope: **experiment only**, authorized as task **T3** (Spec S6) of
`odd/tasks/documentation-authored-diagnostics-embedded-macro.md`. No production code, no
canonical-fixture edit, no commit, no push, no Trust Center / registry / trusted-location /
Access-option change. The parent removes this whole scratch root
(`db/fixtures/embedded-macro-requal/`) after independent verification and archiving.

This is the **re-qualification** of the 2026-10-17 T5 spike
(`odd/evidence/documentation-v2-embedded-blocked-20261017.zip`). That run was
`BLOCKED-build` for one reason only: every form-text candidate used an **invented** block
keyword and Access rejected each at the keyword (`fixture/errors*.txt`: `Expected: 'Begin'.
Found: Embedded.`). The real SaveAsText grammar is now known (Microsoft Q&A: "each embedded
macro starts with text like ' EmMacro = Begin'"; the `accdt` crate's parser for Microsoft
`.accdt` templates), so the ladder below uses the real `<Event>EmMacro = Begin` property
block. Everything else — fixture, build order, matrix, selection discipline, safety
envelope — is the archived harness, re-pointed at this root.

## What this decides

The two accepted startup spikes proved that a `RunCode` (VBA) `AutoExec`, a startup-form
`OnLoad` **expression** calling VBA, and a **non-VBA `AutoExec` OpenQuery** all stay silent
when a copy is opened under `AutomationSecurity = 3` (force-disable; L7/L9). Both left the
same gap open explicitly: *a pure macro action carried by an **embedded event macro on a
form*** was never measured. A macro engine could execute embedded event macros while VBA
and `AutoExec` are blocked.

This spike answers exactly that. A fresh DAO-built copy carries:

| Element | Value |
| --- | --- |
| Canary table | `CanaryRows([ProbeID] LONG PK NOT NULL, [Label] TEXT(64))`, **zero rows** |
| Saved query | `qryAppendCanary` = `INSERT INTO CanaryRows ([ProbeID], [Label]) VALUES (1, 'EMBEDDED_MACRO')` |
| Form | `frmCanary` with one text-box control `txtProbe` |
| Event | `OnLoad` = `"[Embedded Macro]"`, whose embedded macro's sole action is `OpenQuery("qryAppendCanary")` |
| Startup trigger | database property `StartupForm = "frmCanary"`, set **last** |
| Deliberately absent | VBA module (asserted: `Modules` container empty **and** `CurrentProject.AllModules.Count == 0`), `AutoExec`, `AutoKeys`, `RunCode`, `SetWarnings`, expression/VBA event handlers |

The row is observed with an **independent DAO read** before the armed open and again after
Access is closed and reaped — never by a VBA callback and never by the child that hosted
Access.

- **Suppressed under force-disable on all three fresh copies** (canary row set stays `[]`)
  → embedded form-event macro actions do not execute under force-disable at fixture scope;
  the Tier 2 planning gate may continue.
- **Inserted in any force-disable copy** → the recipe is rejected; stop the Tier 2 planning
  gate rather than weakening the contract (L8 rule).
- **Positive control not firing** → every "no insertion" result is vacuous; the result is
  inconclusive, never a pass.

## Exact commands

Live matrix (launch via the parent's background runner — minutes, never foreground):

```powershell
.venv\Scripts\python.exe db\fixtures\e2e-v2-embedded-20261017-6278b311\run_spike.py --all
```

Bounded preflight — no Access, no COM, no DAO (~2 s):

```powershell
.venv\Scripts\python.exe db\fixtures\e2e-v2-embedded-20261017-6278b311\run_spike.py --self-check
```

Optional bounded build-only gate (still launches Access, but stops before the matrix) to see
a `BUILD_BLOCKER` without spending matrix time:

```powershell
.venv\Scripts\python.exe db\fixtures\e2e-v2-embedded-20261017-6278b311\run_spike.py --build-only
```

`--all` refuses to run if `fixture/` already exists (it never overwrites a fixture) and
never deletes evidence.

## How the embedded macro is built (the hard part)

Access exposes **no** documented object-model call that creates an embedded event macro, so
the builder uses the sanctioned route and records every outcome:

1. The form and its control are created with the proven T4 idiom
   (`CreateForm` → `CreateControl` → `Close(acSaveYes)` → `DoCmd.Rename`).
2. Access' **own** `SaveAsText` export becomes the base text
   (`fixture/form_base_access.txt`) — no hand-written form dialect is ever invented.
3. `form_text.py` strips the now-stale `Checksum` line and inserts one bounded candidate
   framing into the form-property region (before the first nested `Begin`). Five candidates
   are attempted, in order, each written as **UTF-16-LE with BOM** (the encoding
   `backends/access/vba.py` documents for form import) and each imported into a freshly
   deleted object:
   * `F0` — placeholder property only (diagnostic: does the literal round-trip at all?);
   * `F1` — real grammar: `OnLoadEmMacro = Begin` / `Version =196611` /
     `ColumnsShown =8` / one anonymous action block (`Action ="OpenQuery"`,
     `Argument ="qryAppendCanary"`, `Argument ="0"`, `Argument ="1"`) / a
     `Comment ="_AXL:…"` block whose AXL carries `For="frmCanary" Event="OnLoad"`,
     wrapped onto ~80-character quoted continuation lines / `End`;
   * `F2` — as F1 with the AXL comment on one line;
   * `F3` — as F1 without the AXL comment block (legacy action rows only);
   * `F4` — as F1 with `ColumnsShown =0`.
   The wrapped-AXL shape, the 80-character fragments and the `\"` / `\015\012` escapes are
   copied from the *live captured* named-macro text in
   `src/ms_access_mcp/backends/access/macros.py`; the block key, the anonymous action
   block and the AXL `Comment` block come from the real SaveAsText grammar.
   The inserted region is **macro block first, then the placeholder** (`insert_order:
   macro-block-then-placeholder`): the archived E0 evidence proves the placeholder alone
   imports, and the archived E2 evidence (`Expected: 'End'. Found: EmbeddedMacro.`) shows a
   property assignment placed immediately *after* the placeholder is rejected, while a block
   opener in that position is accepted. The placeholder therefore stays the last property
   line, directly above the controls container.
4. Every attempt records: exact COM error (`describe_com_error`, including `excepinfo` and
   `scode`), design-view readback of `Forms("frmCanary").OnLoad`, Access' re-export
   (`SaveAsText` → `roundtrip_<id>.txt`), its hash, whether the placeholder survived,
   whether the form structure survived (`Begin Section`, `txtProbe`), whether an
   `OnLoadEmMacro` block survived, and whether the body markers (`OpenQuery`,
   `qryAppendCanary`) are visible in the re-export. The surviving block text itself is
   stored as `roundtrip_macro_block` for quoting in the evidence.
5. Selection policy (stricter now that the ground truth exists): the **first**
   body-bearing candidate that (a) imports, (b) still reads back as `"[Embedded Macro]"` in
   design view, (c) keeps the form structure, and (d) whose Access re-export contains an
   `OnLoadEmMacro` block with `OpenQuery` and `qryAppendCanary` is installed. If no candidate
   meets that bar the build stops with **`BUILD_BLOCKER`** and keeps all ladder evidence.
   There is **no** fallback to VBA or an expression event, and no further framing beyond
   F1-F4 — that would make the suppression test vacuous.

### Build-order discipline (never executes startup code)

1. DAO-only creation of `armed.accdb`, the empty canary table, and the saved append query.
2. `Access.Application` (fresh `DispatchEx`, identity proven fail-closed, security
   set-and-read-back asserted) opens the database while it has **no** auto-run object:
   `AllMacros` empty, `AllForms`/`AllModules` zero, no `StartupForm` property.
3. Form + control are created, Access' own text is captured, the ladder runs, and the
   selected candidate is installed. `Modules` and `Scripts` containers must both still be
   empty and `StartupForm` must still be absent.
4. Database closed, Access quit and reaped, then **`StartupForm` is set through DAO** as the
   very last mutation. The armed fixture is **never** reopened through `Access.Application`
   during the build; the post-build proof is engine-level DAO only.

## Matrix (N = 3 each, positive control first)

| Cell | `AutomationSecurity` | Copy | Expected observation |
| --- | --- | --- | --- |
| `POS` | 1 (low) | fresh copy | after the run the DAO canary read must be exactly `[{ProbeID:1, Label:'EMBEDDED_MACRO'}]`, on every run |
| `FD` | 3 (force-disable) | fresh copy | after the run the DAO canary read must stay `[]` |
| `PRODUCT` | 3 (set and read back by the shipped reader) | fresh copy handed to the reader | the **shipped** Tier 2 reader's own disposable copy must stay `[]` |

Per run the runner performs, in order: (1) copy `armed.accdb` into
`scratch/<CELL>-run<n>/`; (2) **independent DAO read #1**, which must be `[]` and must show
the trigger (`StartupForm = frmCanary`, form document present, no VBA modules, no named
macros); (3) fail-closed lock check; (4) run the cell child (fresh `DispatchEx`, identity
proven and flushed before the armed open, security readback gate, read-only window observer,
`Access.Version` recorded); (5) parent-side grace-then-identity-verified kill if needed;
(6) **independent DAO read #2** after Access is reaped (asserting the trigger is still
present, so "the trigger vanished" can never masquerade as suppression). The row set is
never read by the child that hosted Access.

The `PRODUCT` cell is the only *product* cell. Its child (`product_cell.py`) runs the
repository's real Tier 2 reader — `AppLogicReader` in
`ms_access_mcp.application.documentation_app_logic`, the class behind `read_tier2_content`
and the documentation worker — with its real launcher, its own `AutomationSecurity = 3`
set-and-read-back gate, its own identity proof and its own kill-on-close Job Object. Two
public constructor seams are used: `scratch_root` (the reader's disposable workdir lives
under the run directory on `D:`, never `%TEMP%` on `C:`) and `launcher`/`emit_identity` (a
recording proxy so the evidence holds the product's own set/readback, the owned identity and
the observed windows). The harness subclass retains the reader's **own** armed copy after
the reader closed and reaped Access, because the reader deletes it; the parent then reads
that retained copy by DAO. The source copy is DAO-read again too, proving the product never
opened it in place. Production code is not edited or bypassed.

If the positive control does not insert the exact row, the matrix stops there and no `FD`
or `PRODUCT` cell runs — "no insertion" can never be reported without a non-vacuous
control. If a `PRODUCT` copy gains a row, the matrix stops immediately with
`STOP-recipe-not-clean` (a security finding: the shipped reader's ForceDisable open
executed the embedded event macro).

## Verdict gates (non-vacuous)

`PASS` (exit `0`) requires **all** of:

1. build ok, `StartupForm` armed through DAO, engine-level post-build proof clean;
2. `POS` inserts exactly `[(1, 'EMBEDDED_MACRO')]` **3/3**, every run valid;
3. `FD` rows stay `[]` **3/3**, trigger still present after each run;
4. `PRODUCT` (the shipped Tier 2 reader) rows stay `[]` **3/3** on the copy the reader
   itself opened, with the trigger still present on that retained copy;
5. canonical hashes (`db/fixtures/documentation/**`, `db/northwind.accdb`) unchanged;
6. zero owned Access survivors / zero new `MSACCESS.EXE` PIDs;
7. no lock residue after a graceful close (graceful close is the expectation);
8. no kill issued without a positive identity proof, and no cell timeout.

## Exit codes

| Exit | Status | Meaning |
| --- | --- | --- |
| 0 | `PASS` | force-disable suppressed the embedded event macro, gates above all true |
| 10 | `STOP-inconclusive-positive-control` | control did not insert (or a modal dialog blocked it, or the embedding body was unproven) — never a pass |
| 11 | `STOP-recipe-not-clean` | an `FD` or `PRODUCT` run inserted the row (security finding), or a recipe run was invalid/residual → recipe rejected, Tier 2 planning gate |
| 12 | `STOP-execution-timeout` | a cell timed out with no dialog evidence; matrix stopped, no retry |
| 13 | `STOP-integrity` | hash changed, foreign `MSACCESS.EXE`, lock residue, unverified kill, missing trigger, unreadable DAO readback, pre-existing canary rows |
| 20 | `BLOCKED-build` | fixture or embedded-macro build failed (`BUILD_BLOCKER` in `evidence/build_stderr.txt`) |
| 21 | `BLOCKED-overall-timeout` | overall matrix budget hit; stopped without retry |
| 30 | `INFRA-error` | unexpected harness error (summary still written) |

Child exit codes (recorded per run): `0` ok; `3` security readback mismatch (no open);
`4` open failed; `5` fatal; `6` Access identity could not be verified (no open).
Product child (`product_cell.py`): `0` ok; `5` fatal; `7` the reader raised
(containment/defect — the parent then records the cell as invalid, never as a pass).
DAO observer: `0` ran (`ok` field is the truth), `3` DAO raised, `5` fatal.
Build: `0` ok; `2` `BUILD_BLOCKER`.

## Safety envelope (unchanged boundaries, T2/T3/T4 discipline)

- Fresh **`DispatchEx`** Access instances only. Existing `MSACCESS.EXE` PIDs are baselined,
  recorded, protected, and never killed.
- Ownership is **fail-closed**: an armed open requires a PID absent from the baseline, a
  non-null captured creation time, a live matching creation time, and the `MSACCESS.EXE`
  image. Access reaping uses the **production** verifier
  `ms_access_mcp.application.process_identity.terminate_verified_access` (the same fail-closed
  path T2 delivered and T4 used); harness-owned Python children are reaped through a
  creation-verified PID-scoped helper that additionally refuses to kill the harness' own
  process. No process-name-wide kill and no baseline-diff kill anywhere (proved by a static
  scan in `--self-check`).
- If the pre-open DAO read fails, the trigger is missing, or a lock file remains on the
  copy, the armed copy is **not** opened.
- The child starts a read-only window observer (`tests/helpers/dialog_watcher.py`) before
  the armed open and flushes observed windows every ~2 s, so a hard kill still leaves the
  dialog evidence on disk; the parent samples owned windows before any hard kill. **No
  synthetic keyboard/UI input, no dialog acceptance, no mode/setting change.**
- Per-cell child hard timeout 120 s; the parent owns the kill and the orphan sweep. A
  timeout stops the matrix (no retry).
- Canonical files are sha256-hashed before and after; all copies, form texts and evidence
  live under this scratch root on `D:` (never `%TEMP%` on `C:`) and are never deleted by the
  harness.
- `Application.Version` is recorded as a string; no bitness/provider claim is made that was
  not read back.

## Evidence

```
evidence/
  hashes_before.json, baseline_msaccess_pids.json
  build_result.json, build_stdout.txt, build_stderr.txt
  form_dialect/                     <- T7 parsing reference (unarmed captures)
      form_base_access.txt          <- Access' own SaveAsText of the form before embedding
      form_final_installed.txt      <- the installed candidate text
      embedding_attempts/candidate_<F0..F4>.txt, roundtrip_<F0..F4>.txt
      build_report.json
  product_cell.py                   <- the PRODUCT child (real Tier 2 reader + retained copy)
  summary.json                      <- verdicts, per-cell row sets, orphan sweep, hash diff
scratch/POS-run1..3/, scratch/FD-run1..3/   <- one disposable copy per run
      armed.accdb, identity.json, result.json, run_record.json,
      rows_before.json, rows_after.json, dao_before_*.txt, dao_after_*.txt,
      stdout.txt, stderr.txt
fixture/
      armed.accdb, form_base_access.txt, form_final_installed.txt,
      embedding_attempts/…, build_identity.json, build_report.json
```

Every `run_record.json` preserves the candidate set at every stage: identity capture and
verification, security readback, `Access.Version`, open result, all observed windows,
pre/post lock state, the full DAO row set and row count before/after, rows inserted by the
candidate, rows that are not the expected tuple, the startup-trigger evidence before and
after, the parent's reap record (`graceful` / `forced-after-grace` / `hard-timeout` /
`not-dispatched`), and the exact child return code. The evidence archives no databases.

## Known limitations before the live run

- `--self-check` is deliberately COM-free: the DAO reader, the form build and both Access
  phases are unexercised until the parent launches `--all`. The verdict arithmetic (28
  synthetic cases, including the `PRODUCT` cell), fail-closed kill semantics, watcher
  surface, form-text ladder markers, exit codes and the forbidden-token scan are all covered
  offline.
- The ladder is bounded to F1-F4 and the real grammar is still **host-verified**, not
  guaranteed: the block key, the anonymous action block and the AXL shape are grounded, but
  Access 16 may still reject (or silently ignore) the hand-written AXL `Comment`. If no
  candidate imports *and* re-exports the body, the build exits `20` with the complete ladder
  evidence in `fixture/embedding_attempts/` and `fixture/build_report.json` — a legitimate
  outcome, and the honest one, rather than inventing a fifth framing or substituting a
  different vector.
- The `PRODUCT` cell observes the reader's **own** disposable copy (retained after the
  reader closed and reaped Access). It does not prove anything about a copy the reader left
  behind, because the reader deletes its copy on success; a deletion residue would be a
  separate warning in the reader's own output.
- A **named-macro event reference** (`OnLoad = "mcrX"`) is expressible programmatically and
  would answer a related but *different* question. It is deliberately **not** implemented
  here: the question is the embedded event macro, and swapping vectors silently would make
  the result look like coverage it is not. If the parent wants that vector, it is a
  separate, separately-labelled experiment.
- "No dialogs observed" means the observer sampled no dialog-class windows, not that every
  possible dialog is observable. Absence of action-query dialogs is a host observation, not
  a portable contract.
- This is fixture-scope behaviour on the measured runtime. It is **not** universal macro
  suppression, `AutoKeys` (keyboard-triggered) coverage, table data-macro coverage, or a
  claim about other Access versions/settings, and it does not qualify the production reader.
