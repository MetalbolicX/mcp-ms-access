"""Build the T5 embedded form-event-macro canary fixture without running startup code.

What the fixture is
-------------------
One disposable ``armed.accdb`` that carries:

* a dedicated local canary table ``CanaryRows`` (``[ProbeID] LONG`` PK, ``[Label]
  TEXT(64)``) with **zero rows**;
* a saved append ``QueryDef`` named ``qryAppendCanary`` whose SQL inserts exactly
  ``(1, 'EMBEDDED_MACRO')``;
* exactly one form ``frmCanary`` with one text-box control, whose ``OnLoad`` event is an
  **embedded macro** whose sole action is ``OpenQuery("qryAppendCanary")``;
* the ``StartupForm`` database property pointing at that form, set as the very last
  mutation, so opening a copy opens the form and fires the embedded event macro.

There is **no VBA module anywhere** (asserted through the DAO ``Modules`` container and
``CurrentProject.AllModules``), no ``AutoExec``, no ``AutoKeys``, no ``RunCode``, no
``SetWarnings``, and no expression/VBA event handler. Those are the vectors the two prior
spikes already covered; this fixture exists for the one startup-coverage gap they left
open: a **pure macro action attached as an embedded form-event macro**.

Build-order discipline (mirrors ``scripts/generate_documentation_fixtures.py`` and both
prior spike builds):

1. DAO-only creation of ``armed.accdb`` + canary table + saved append query.
2. ``Access.Application`` opens the database while it has **no** auto-run object (no
   macros, no forms, no ``StartupForm`` property) under a set-and-read-back
   ``AutomationSecurity = 3``.
3. The form is created with the proven ``CreateForm``/``CreateControl`` idiom, and
   Access' **own** ``SaveAsText`` export becomes the base text. The embedded-macro
   dialect ladder (``form_text.py``) modifies that text and re-imports it; every attempt
   records its exact COM error, design-view readback, and re-exported text.
4. Only then, with the database closed and Access quit, DAO sets ``StartupForm``. The
   armed fixture is **never** reopened through ``Access.Application`` during the build;
   the post-build proof is engine-level DAO only.

Embedding policy (bounded, no fallback): if no body-bearing framing imports cleanly and
keeps the event placeholder across a ``SaveAsText`` round-trip, the builder stops with
``BUILD_BLOCKER`` and keeps all ladder evidence. It never falls back to VBA or an
expression event, because that would make the suppression test vacuous.

Usage: ``build_fixture.py --out-dir <fixture dir>``. Exit codes: 0 ok; 2 build failure.
"""

from __future__ import annotations

import argparse
import gc
import json
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from form_text import (  # noqa: E402
    EMBEDDING_CANDIDATES,
    INSERT_ORDER,
    MACRO_PROPERTY,
    PLACEHOLDER_VALUE,
    attempt_meets_bar,
    build_candidate_text,
    extract_macro_block,
    roundtrip_body_markers_found,
    roundtrip_has_event_macro_block,
    roundtrip_structure_intact,
    select_body_attempt,
    strip_checksum_lines,
)
from harness_common import (  # noqa: E402
    AC_DESIGN,
    AC_FORM,
    AC_SAVE_YES,
    AC_TEXTBOX,
    CANARY_INSERT_SQL,
    CANARY_LABEL,
    CANARY_PROBE_ID,
    CANARY_QUERY,
    CANARY_TABLE,
    DB_VERSION,
    FIXTURE_DB_NAME,
    FORM_CONTROL_NAME,
    FORM_NAME,
    LOCALE,
    MSO_FORCE_DISABLE,
    STARTUP_FORM_PROPERTY,
    WindowObserver,
    arm_startup_form,
    baseline_pids,
    decode_save_as_text,
    describe_com_error,
    lock_files,
    process_is_alive,
    read_canary_snapshot,
    reap_access,
    safe_call,
    sha256_bytes,
    sha256_text,
    snapshot_trigger_evidence,
    verify_access_identity,
    wait_until,
    write_json_flushed,
)

EXIT_OK = 0
EXIT_BUILD_BLOCKER = 2

BASE_TEXT_FILE = "form_base_access.txt"
FINAL_TEXT_FILE = "form_final_installed.txt"
EMBED_DIR_NAME = "embedding_attempts"


class EmbeddingBlockedError(RuntimeError):
    """No accepted body-bearing form-text framing: BUILD_BLOCKER, never a fallback."""


def write_form_text_file(path: Path, text: str) -> None:
    """Write form text the way Access reads it: UTF-16-LE with BOM (see vba.py)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"\xff\xfe" + text.encode("utf-16-le"))


# ---------------------------------------------------------------------------------------
# phase 1: DAO-only database, canary table, saved append query
# ---------------------------------------------------------------------------------------
def _create_dao_database(db_path: Path) -> dict[str, Any]:
    import pythoncom
    import win32com.client

    record: dict[str, Any] = {"path": str(db_path)}
    pythoncom.CoInitialize()
    engine = None
    db = None
    try:
        engine = win32com.client.Dispatch("DAO.DBEngine.120")
        db = engine.CreateDatabase(str(db_path), LOCALE, DB_VERSION)
        db.Execute(
            f"CREATE TABLE {CANARY_TABLE} ([ProbeID] LONG NOT NULL, [Label] TEXT(64), "
            f"CONSTRAINT PK_{CANARY_TABLE} PRIMARY KEY ([ProbeID]))",
            128,
        )
        db.TableDefs.Refresh()
        db.CreateQueryDef(CANARY_QUERY, CANARY_INSERT_SQL)
        db.QueryDefs.Refresh()
        record["table_created"] = CANARY_TABLE
        record["query_created"] = CANARY_QUERY
        record["query_sql_readback"] = str(db.QueryDefs(CANARY_QUERY).SQL)
    finally:
        if db is not None:
            try:
                db.Close()
            except Exception:  # noqa: BLE001
                pass
        db = None
        engine = None
        gc.collect()
        pythoncom.CoUninitialize()
    return record


def _sql_matches(sql: str) -> bool:
    normalized = " ".join(str(sql).split()).lower()
    return (
        normalized.startswith("insert into canaryrows")
        and f"({CANARY_PROBE_ID}," in normalized.replace(" ", "")
        and CANARY_LABEL.lower() in normalized
    )


# ---------------------------------------------------------------------------------------
# phase 2: Access build (create form, embedding ladder, no auto-run object exists yet)
# ---------------------------------------------------------------------------------------
def _create_form_with_control(app: Any, report: dict[str, Any]) -> str:
    """Create the form and its one control with the proven T4 idiom; return its name."""
    form = app.CreateForm()
    default_name = str(form.Name)
    report["form_default_name"] = default_name
    control = None
    try:
        control = app.CreateControl(default_name, AC_TEXTBOX, 0)
        control.Name = FORM_CONTROL_NAME
        report["control_created"] = FORM_CONTROL_NAME
    except Exception as exc:  # noqa: BLE001 - recorded; the form itself is the trigger
        report["control_error"] = describe_com_error(exc)
    control = None
    close_result = safe_call(lambda: app.DoCmd.Close(AC_FORM, default_name, AC_SAVE_YES))
    report["close_design_default"] = close_result
    if not close_result["ok"]:
        raise RuntimeError(f"closing the new form in design view failed: {close_result['error']}")
    rename_result = safe_call(lambda: app.DoCmd.Rename(FORM_NAME, AC_FORM, default_name))
    report["rename"] = rename_result
    if not rename_result["ok"]:
        raise RuntimeError(f"renaming the new form to {FORM_NAME} failed: {rename_result['error']}")
    return default_name


def _event_readback(app: Any) -> dict[str, Any]:
    return safe_call(lambda: str(app.Forms(FORM_NAME).OnLoad))


def _ladder(app: Any, base_text: str, embed_dir: Path) -> list[dict[str, Any]]:
    """Run the bounded, ordered embedding-candidate ladder; record every outcome."""
    attempts: list[dict[str, Any]] = []
    for candidate in EMBEDDING_CANDIDATES:
        candidate_id = str(candidate["id"])
        text, index = build_candidate_text(candidate_id, base_text)
        candidate_path = embed_dir / f"candidate_{candidate_id}.txt"
        write_form_text_file(candidate_path, text)
        attempt: dict[str, Any] = {
            "candidate": candidate_id,
            "description": candidate["description"],
            "expects_body": bool(candidate["body"]),
            "candidate_file": candidate_path.name,
            "candidate_text_sha256": sha256_text(text),
            "candidate_text_lines": len(text.splitlines()),
            "insert_index": index,
            "load_ok": False,
        }
        # Import into a *fresh* object so an earlier attempt cannot linger.
        attempt["delete_object"] = safe_call(lambda: app.DoCmd.DeleteObject(AC_FORM, FORM_NAME))
        try:
            app.LoadFromText(AC_FORM, FORM_NAME, str(candidate_path))
            attempt["load_ok"] = True
        except Exception as exc:  # noqa: BLE001 - a rejected dialect is evidence
            attempt["load_error"] = describe_com_error(exc)
            attempts.append(attempt)
            continue

        attempt["open_design"] = safe_call(lambda: app.DoCmd.OpenForm(FORM_NAME, AC_DESIGN))
        attempt["readback"] = _event_readback(app)
        attempt["readback_matches_placeholder"] = (
            attempt["readback"].get("ok") is True
            and attempt["readback"].get("value") == PLACEHOLDER_VALUE
        )
        roundtrip_path = embed_dir / f"roundtrip_{candidate_id}.txt"
        attempt["save_as_text"] = safe_call(
            lambda: app.SaveAsText(AC_FORM, FORM_NAME, str(roundtrip_path))
        )
        attempt["roundtrip_placeholder_found"] = False
        attempt["roundtrip_body_markers_found"] = False
        if roundtrip_path.exists():
            raw = roundtrip_path.read_bytes()
            roundtrip = decode_save_as_text(raw)
            lowered = roundtrip.lower()
            attempt["roundtrip_file"] = roundtrip_path.name
            attempt["roundtrip_bytes"] = len(raw)
            attempt["roundtrip_sha256"] = sha256_bytes(raw)
            attempt["roundtrip_placeholder_found"] = PLACEHOLDER_VALUE.lower() in lowered
            attempt["roundtrip_body_markers_found"] = roundtrip_body_markers_found(roundtrip)
            attempt["roundtrip_has_event_macro_block"] = roundtrip_has_event_macro_block(roundtrip)
            attempt["roundtrip_structure_intact"] = roundtrip_structure_intact(roundtrip)
            attempt["roundtrip_has_event_property"] = "OnLoad =" in roundtrip
            attempt["roundtrip_macro_block"] = extract_macro_block(roundtrip)
        attempt["close"] = safe_call(lambda: app.DoCmd.Close(AC_FORM, FORM_NAME, AC_SAVE_YES))
        attempt["meets_bar"] = attempt_meets_bar(attempt)
        attempts.append(attempt)
    return attempts


def _install_selected(app: Any, attempt: dict[str, Any], embed_dir: Path) -> dict[str, Any]:
    """Re-import the selected candidate as the live form and re-prove it round-trips."""
    candidate_id = str(attempt["candidate"])
    candidate_path = embed_dir / str(attempt["candidate_file"])
    text = decode_save_as_text(candidate_path.read_bytes())
    installed: dict[str, Any] = {"candidate": candidate_id, "candidate_file": candidate_path.name}
    installed["delete_object"] = safe_call(lambda: app.DoCmd.DeleteObject(AC_FORM, FORM_NAME))
    app.LoadFromText(AC_FORM, FORM_NAME, str(candidate_path))
    installed["load_ok"] = True
    installed["open_design"] = safe_call(lambda: app.DoCmd.OpenForm(FORM_NAME, AC_DESIGN))
    readback = _event_readback(app)
    installed["readback"] = readback
    installed["readback_matches_placeholder"] = readback.get("value") == PLACEHOLDER_VALUE
    installed["event_property_empty"] = readback.get("value") in (None, "")
    installed["close"] = safe_call(lambda: app.DoCmd.Close(AC_FORM, FORM_NAME, AC_SAVE_YES))
    installed["installed_text_sha256"] = sha256_text(text)
    return installed


def _access_phase(db_path: Path, out_dir: Path) -> dict[str, Any]:
    import pythoncom
    import win32com.client

    report: dict[str, Any] = {"phase": "access"}
    baseline = baseline_pids()
    report["baseline_msaccess_pids"] = sorted(baseline)
    access_pid: int | None = None
    access_creation: int | None = None
    access_image: str | None = None
    observer: WindowObserver | None = None
    app: Any = None
    pythoncom.CoInitialize()
    try:
        app = win32com.client.DispatchEx("Access.Application")
        capture_method = "hWndAccessApp"
        try:
            import win32process

            hwnd = int(app.hWndAccessApp())
            _thread, pid = win32process.GetWindowThreadProcessId(hwnd)
            access_pid = int(pid)
        except Exception as exc:  # noqa: BLE001 - baseline-diff fallback, recorded
            capture_method = "baseline-diff"
            report["hwnd_error"] = describe_com_error(exc)
            candidates = sorted(baseline_pids() - baseline)
            access_pid = candidates[0] if len(candidates) == 1 else None
            report["baseline_diff_candidates"] = candidates
        from harness_common import read_process_identity

        live = read_process_identity(access_pid) if access_pid else None
        if live is not None:
            access_creation = live.creation
            access_image = live.image
        report["access_identity"] = {
            "capture_method": capture_method,
            "access_pid": access_pid,
            "access_creation": access_creation,
            "access_image": access_image,
        }
        verification = verify_access_identity(access_pid, access_creation, baseline)
        report["identity_verification"] = verification
        write_json_flushed(
            out_dir / "build_identity.json",
            {**report["access_identity"], "verification": verification},
        )
        if not verification["owned"]:
            raise RuntimeError(
                f"Access identity not positively verified; build refused: {verification}"
            )

        for attribute, value in (("Visible", False), ("UserControl", False)):
            if not safe_call(lambda attribute=attribute, value=value: setattr(app, attribute, value))["ok"]:
                report[f"{attribute.lower()}_set_ok"] = False
        app.AutomationSecurity = MSO_FORCE_DISABLE
        security_readback = int(app.AutomationSecurity)
        report["security_readback"] = security_readback
        if security_readback != MSO_FORCE_DISABLE:
            raise RuntimeError(
                f"AutomationSecurity readback {security_readback} != force-disable "
                f"{MSO_FORCE_DISABLE}; build refused"
            )
        app.OpenCurrentDatabase(str(db_path))
        report["opened"] = True
        observer = WindowObserver({access_pid} if access_pid else set())
        observer.start()

        # Proof there is no auto-run object before anything is created.
        macro_names = [
            str(app.CurrentProject.AllMacros(i).Name)
            for i in range(app.CurrentProject.AllMacros.Count)
        ]
        report["macros_before_load"] = sorted(macro_names)
        report["modules_before_load"] = int(app.CurrentProject.AllModules.Count)
        report["forms_before_load"] = int(app.CurrentProject.AllForms.Count)
        if macro_names:
            raise RuntimeError(f"auto-run objects exist before the build: {macro_names}")
        if report["modules_before_load"] or report["forms_before_load"]:
            raise RuntimeError(
                f"objects exist before the build: modules={report['modules_before_load']} "
                f"forms={report['forms_before_load']}"
            )
        database = app.CurrentDb()
        startup_form_before = safe_call(lambda: str(database.Properties(STARTUP_FORM_PROPERTY).Value))
        report["startup_form_before_load"] = startup_form_before.get("value")
        if startup_form_before.get("ok"):
            raise RuntimeError(
                f"StartupForm already present before the build: {startup_form_before['value']}"
            )

        # 1. Create the form + control (proven T4 idiom) and capture Access' own text.
        default_name = _create_form_with_control(app, report)
        base_path = out_dir / BASE_TEXT_FILE
        app.SaveAsText(AC_FORM, FORM_NAME, str(base_path))
        raw = base_path.read_bytes()
        base_text = decode_save_as_text(raw)
        report["base_text"] = {
            "file": base_path.name,
            "bytes": len(raw),
            "sha256": sha256_bytes(raw),
            "lines": len(base_text.splitlines()),
            "had_checksum_line": "Checksum =" in base_text,
        }
        stripped, removed = strip_checksum_lines(base_text)
        report["base_text"]["checksum_lines_removed_for_candidates"] = removed
        report["base_text"]["stripped_sha256"] = sha256_text(stripped)
        report["default_form_closed"] = default_name

        # 2. Bounded embedding ladder over Access' own text.
        embed_dir = out_dir / EMBED_DIR_NAME
        attempts = _ladder(app, base_text, embed_dir)
        report["embedding_attempts"] = attempts
        selected = select_body_attempt(attempts)
        if selected is None:
            attempted = [
                {
                    "candidate": item["candidate"],
                    "load_ok": item["load_ok"],
                    "readback": item.get("readback"),
                    "roundtrip_placeholder_found": item.get("roundtrip_placeholder_found"),
                    "error": item.get("load_error"),
                }
                for item in attempts
            ]
            write_json_flushed(out_dir / "embedding_report.json", {"attempts": attempts, "selected": None})
            raise EmbeddingBlockedError(
                "no body-bearing embedded-macro form-text framing was accepted: every "
                f"candidate failed the import/readback/SaveAsText bar ({attempted}). "
                "A placeholder-only event would be vacuous, so the build stops here "
                "(no VBA or expression fallback)."
            )
        report["selected_candidate"] = selected["candidate"]
        report["selection_reason"] = (
            "first body-bearing candidate that imports, reads back the placeholder in "
            "design view, keeps the form structure, and whose Access SaveAsText re-export "
            f"contains the {MACRO_PROPERTY} block with OpenQuery and qryAppendCanary"
        )
        report["selected_body_markers_in_roundtrip"] = bool(
            selected.get("roundtrip_body_markers_found")
        )
        report["installed"] = _install_selected(app, selected, embed_dir)

        # 3. Prove the installed fixture still has no VBA and no named macro objects.
        modules_after = int(app.CurrentProject.AllModules.Count)
        macros_after = [
            str(app.CurrentProject.AllMacros(i).Name)
            for i in range(app.CurrentProject.AllMacros.Count)
        ]
        forms_after = int(app.CurrentProject.AllForms.Count)
        database = app.CurrentDb()
        containers: dict[str, Any] = {}
        for container_name in ("Modules", "Forms", "Reports", "Scripts"):
            containers[container_name] = safe_call(
                lambda container_name=container_name: sorted(
                    str(database.Containers(container_name).Documents(i).Name)
                    for i in range(database.Containers(container_name).Documents.Count)
                )
            ).get("value")
        startup_form_after = safe_call(
            lambda: str(database.Properties(STARTUP_FORM_PROPERTY).Value)
        )
        report["proof_before_arm"] = {
            "all_modules_count": modules_after,
            "all_macros": sorted(macros_after),
            "all_forms_count": forms_after,
            "containers": containers,
            "startup_form_property": startup_form_after.get("value"),
        }
        if modules_after or macros_after:
            raise RuntimeError(
                f"installed fixture carries VBA or macros: modules={modules_after} "
                f"macros={macros_after}"
            )
        if forms_after != 1:
            raise RuntimeError(f"expected exactly one form, observed {forms_after}")
        if containers.get("Modules"):
            raise RuntimeError(f"Modules container not empty: {containers['Modules']}")
        if containers.get("Scripts"):
            raise RuntimeError(f"Scripts container not empty: {containers['Scripts']}")
        if containers.get("Forms") != [FORM_NAME]:
            raise RuntimeError(f"Forms container is not [{FORM_NAME}]: {containers['Forms']}")
        if startup_form_after.get("ok"):
            raise RuntimeError(
                f"StartupForm appeared before the arm step: {startup_form_after['value']}"
            )

        app.CloseCurrentDatabase()
        report["closed"] = True
    finally:
        if observer is not None:
            observer.stop()
            report["build_windows"] = observer.windows
            report["build_observer_error"] = observer.error
        if app is not None:
            try:
                app.Quit()
            except Exception:  # noqa: BLE001
                pass
        app = None
        if access_pid is not None:
            graceful = wait_until(lambda: not process_is_alive(access_pid), 20.0)
            report["reap"] = (
                {"pid": access_pid, "verified": False, "terminated": False, "exited": True,
                 "detail": "exited within the 20-second Quit grace; no kill attempted"}
                if graceful
                else reap_access(access_pid, access_creation, access_image, baseline)
            )
        pythoncom.CoUninitialize()
    return report


# ---------------------------------------------------------------------------------------
# build orchestration
# ---------------------------------------------------------------------------------------
def build(out_dir: Path) -> dict[str, Any]:
    """Build the disposable armed fixture; every failure is a BUILD_BLOCKER."""
    out_dir.mkdir(parents=True, exist_ok=True)
    db_path = out_dir / FIXTURE_DB_NAME
    if db_path.exists():
        raise RuntimeError(f"refusing to overwrite existing fixture: {db_path}")

    dao_create = _create_dao_database(db_path)

    import pythoncom

    pythoncom.CoInitialize()
    try:
        access_report = _access_phase(db_path, out_dir)
    finally:
        pythoncom.CoUninitialize()

    # Keep the installed form text next to the fixture for the T7 dialect archive.
    selected_id = access_report.get("selected_candidate")
    if selected_id:
        selected_source = out_dir / EMBED_DIR_NAME / f"candidate_{selected_id}.txt"
        if selected_source.exists():
            (out_dir / FINAL_TEXT_FILE).write_bytes(selected_source.read_bytes())
            access_report["installed_text_file"] = FINAL_TEXT_FILE

    # LAST mutation, engine-level only: arm the startup trigger. Access is never reopened.
    arm = arm_startup_form(db_path, FORM_NAME)
    if not arm.get("appended") or arm.get("readback") != FORM_NAME:
        raise RuntimeError(f"arming the StartupForm property failed: {arm}")

    snapshot = read_canary_snapshot(db_path)
    locks = lock_files(out_dir)
    trigger = snapshot_trigger_evidence(snapshot)
    problems: list[str] = []
    if locks:
        problems.append(f"build left lock files: {locks}")
    if not snapshot["ok"]:
        problems.append(f"post-build DAO readback failed: {snapshot['dao_error']}")
    if not trigger["canary_table_present"]:
        problems.append(f"canary table missing: {snapshot['tables']}")
    if not trigger["querydef_present"]:
        problems.append(f"saved query missing: {sorted(snapshot['querydefs'])}")
    elif not _sql_matches(snapshot["querydefs"][CANARY_QUERY]):
        problems.append(f"saved query SQL not the exact append: {snapshot['querydefs'][CANARY_QUERY]!r}")
    if not trigger["form_document_present"]:
        problems.append(f"form missing from DAO Forms container: {trigger['forms_container']}")
    if not trigger["no_vba_modules"]:
        problems.append(f"Modules container not empty: {trigger['modules_container']}")
    if not trigger["no_named_macros"]:
        problems.append(f"Scripts container not empty (named macros present): {trigger['scripts_container']}")
    if not trigger["startup_form_is_trigger"]:
        problems.append(f"StartupForm is not {FORM_NAME}: {trigger['startup_form_property']}")
    if snapshot["rows"] != []:
        problems.append(f"build executed the canary action: rows={snapshot['rows']}")
    if problems:
        raise RuntimeError("; ".join(problems))

    report: dict[str, Any] = {
        "schema": "v2-spike-embedded.build/1",
        "fixture": str(db_path),
        "dao_create": dao_create,
        "access_phase": access_report,
        "arm_startup_form": arm,
        "post_build_dao_snapshot": snapshot,
        "post_build_trigger_evidence": trigger,
        "locks_after_build": locks,
        "canary_rows_after_build": snapshot["rows"],
        "expected_row": {"ProbeID": CANARY_PROBE_ID, "Label": CANARY_LABEL},
        "no_vba_anywhere": trigger["no_vba_modules"],
        "embedded_event_macro": {
            "candidate": access_report.get("selected_candidate"),
            "selection_reason": access_report.get("selection_reason"),
            "insert_order": INSERT_ORDER,
            "body_markers_visible_in_roundtrip": access_report.get(
                "selected_body_markers_in_roundtrip"
            ),
            "event": FORM_NAME,
            "event_property": "OnLoad",
            "placeholder": PLACEHOLDER_VALUE,
        },
    }
    write_json_flushed(out_dir / "build_report.json", report)
    return report


def main() -> int:
    """Build the fixture, print one JSON summary, and map failures to exit 2."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out-dir", type=Path, required=True)
    args = parser.parse_args()
    out_dir = args.out_dir
    try:
        report = build(out_dir)
    except Exception as exc:  # noqa: BLE001 - report the blocker, exit nonzero
        import traceback

        traceback.print_exc()
        print(f"BUILD_BLOCKER: {exc}", file=sys.stderr)
        previous = None
        try:
            previous = json.loads((out_dir / "build_report.json").read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            previous = None
        write_json_flushed(
            out_dir / "build_report.json",
            {"schema": "v2-spike-embedded.build/1", "error": str(exc), "previous": previous},
        )
        return EXIT_BUILD_BLOCKER
    access_phase = report["access_phase"]
    print(
        json.dumps(
            {
                "fixture": report["fixture"],
                "canary_rows_after_build": report["canary_rows_after_build"],
                "form_present": report["post_build_trigger_evidence"]["form_document_present"],
                "startup_form_property": report["post_build_trigger_evidence"]["startup_form_property"],
                "no_vba_anywhere": report["no_vba_anywhere"],
                "embedded_candidate": report["embedded_event_macro"]["candidate"],
                "body_markers_visible_in_roundtrip": report["embedded_event_macro"][
                    "body_markers_visible_in_roundtrip"
                ],
                "installed_readback": access_phase["installed"]["readback"],
                "base_text_sha256": access_phase["base_text"]["sha256"],
            },
            ensure_ascii=True,
            indent=2,
        )
    )
    return EXIT_OK


if __name__ == "__main__":
    raise SystemExit(main())
