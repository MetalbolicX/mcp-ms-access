"""Run one PRODUCT cell: the repository's real Tier 2 reader on a disposable armed copy.

This is the harness' only *product* cell. It answers the question the FD cells cannot:
does the shipped documentation Tier 2 reader, on a fresh copy of the armed fixture, cause
the startup form's embedded ``OnLoad`` macro to append the canary row?

What runs
---------
The production reader ``ms_access_mcp.application.documentation_app_logic.AppLogicReader``
-- the same class behind ``read_tier2_content`` and the documentation worker -- with its
real collaborators: ``ComAccessLauncher`` (fresh ``DispatchEx``, invisible), the
production ``AutomationSecurity = 3`` set-and-read-back gate, the production identity
proof, the production kill-on-close Job Object, the offline disposable copy, and the
catalogue read. Nothing in production is edited or bypassed.

Two harness-only seams are injected, both public constructor parameters of the reader:

* ``scratch_root`` -- the reader's disposable workdir lives under this run's directory on
  ``D:`` instead of ``%TEMP%`` on ``C:`` (the same discipline every other cell follows);
* ``launcher`` / ``emit_identity`` -- a thin recording proxy so the evidence holds the
  *product's own* ``AutomationSecurity`` set/readback, the owned Access identity (announced
  before the armed open), and the observed windows.

The one thing the harness adds on top of the public surface is *retaining* the reader's
own armed copy after the reader has closed and reaped Access (``_RetainingReader``
overrides the private ``_read_armed`` hook). Without that, the reader deletes its copy and
the canary observation would be vacuous. The parent runner then performs the independent
DAO canary read on the retained copy -- never from this child, which hosted Access.

Exit codes: 0 ok; 5 unexpected fatal; 7 the reader raised (containment/defect).
"""

from __future__ import annotations

import argparse
import shutil
import sys
import time
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))

from harness_common import (  # noqa: E402
    WindowObserver,
    baseline_pids,
    describe_com_error,
    read_process_identity,
    sha256_file,
    verify_access_identity,
    write_json_flushed,
)

EXIT_OK = 0
EXIT_FATAL = 5
EXIT_READER_RAISED = 7

RETAINED_COPY_NAME = "armed_product_copy.accdb"


def _recording_session(inner: Any, sink: dict[str, Any]) -> Any:
    """Wrap the production session and record its security/identity/open calls."""
    return _RecordingSession(inner, sink)


class _RecordingSession:
    """Transparent proxy over the production ``ComAccessSession`` (records, never alters)."""

    def __init__(self, inner: Any, sink: dict[str, Any]) -> None:
        """Store the wrapped session and the evidence sink."""
        self._inner = inner
        self._sink = sink

    def set_automation_security(self, level: int) -> None:
        """Delegate the product's own set, then record what it asked for."""
        self._sink["security_set_requested"] = int(level)
        self._inner.set_automation_security(level)

    def read_automation_security(self) -> int:
        """Delegate the product's own readback, then record the value it observed."""
        value = int(self._inner.read_automation_security())
        self._sink["security_readback"] = value
        return value

    def open_current_database(self, path: str) -> None:
        """Delegate the armed open and record the exact path the product opened."""
        self._sink["product_opened_path"] = str(path)
        self._inner.open_current_database(path)

    def __getattr__(self, name: str) -> Any:
        """Delegate every other session member unchanged."""
        return getattr(self._inner, name)


def _retaining_reader_class() -> Any:
    """Build the reader subclass that keeps the product's armed copy for observation."""
    from ms_access_mcp.application.documentation_app_logic import AppLogicReader

    class _RetainingReader(AppLogicReader):
        """Production reader + one retained copy of the file it opened (evidence only)."""

        def __init__(self, *, retain_to: Path, **kwargs: Any) -> None:
            """Remember where the retained copy goes, then defer to the production init."""
            super().__init__(**kwargs)
            self._retain_to = retain_to
            self.retained: dict[str, Any] = {}

        def _read_armed(self, copy_path: str, workdir: Path, include_source: bool) -> Any:
            """Run the real armed read, then retain the copy after Access is closed."""
            try:
                return super()._read_armed(copy_path, workdir, include_source)
            finally:
                # ``super()._read_armed`` closes the database, quits Access and releases
                # the kill-on-close Job handle in its own ``finally`` before returning.
                self._retain(copy_path)

        def _retain(self, copy_path: str) -> None:
            """Copy the product's armed copy out; a failure is recorded, never raised."""
            source = Path(copy_path)
            deadline = time.monotonic() + 25.0
            last_error: str | None = None
            while time.monotonic() < deadline:
                try:
                    shutil.copy2(source, self._retain_to)
                    self.retained = {
                        "path": str(self._retain_to),
                        "bytes": self._retain_to.stat().st_size,
                        "sha256": sha256_file(self._retain_to),
                    }
                    return
                except OSError as exc:  # noqa: BLE001 - a lock may still be releasing
                    last_error = describe_com_error(exc)
                    time.sleep(0.5)
            self.retained = {"error": last_error or "unknown copy failure"}

    return _RetainingReader


def _content_summary(content: Any) -> dict[str, Any]:
    """Summarize the product's Tier 2 content without dumping fact payloads."""
    facts = list(getattr(content, "content", []) or [])
    references = list(getattr(content, "references", []) or [])
    return {
        "content_count": len(facts),
        "categories": [str(getattr(fact, "category", "")) for fact in facts],
        "reference_count": len(references),
        "warnings": [str(item) for item in (getattr(content, "warnings", []) or [])],
    }


def run_product_cell(args: argparse.Namespace) -> int:
    """Read the armed copy with the production Tier 2 reader and record the evidence."""
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    source = Path(args.db)
    retained = out_dir / RETAINED_COPY_NAME
    result_path = out_dir / "result.json"
    scratch_root = out_dir / "product-scratch"
    scratch_root.mkdir(parents=True, exist_ok=True)

    baseline = baseline_pids()
    record: dict[str, Any] = {
        "schema": "v2-spike-embedded.product/1",
        "cell": args.cell,
        "run": args.run,
        "source_copy": str(source),
        "source_sha256": sha256_file(source),
        "reader": "ms_access_mcp.application.documentation_app_logic.AppLogicReader",
        "baseline_msaccess_pids": sorted(baseline),
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "observer_started": False,
        "dialogs": [],
    }
    sink: dict[str, Any] = {}
    observer: WindowObserver | None = None

    def _on_identity(pid: int, creation: int, image: str) -> None:
        """Record the product-announced identity and start the read-only window observer."""
        nonlocal observer
        identity = read_process_identity(int(pid))
        record["access_identity"] = {
            "pid": int(pid),
            "creation": int(creation),
            "image": str(image),
            "live_creation": identity.creation if identity else None,
            "live_image": identity.image if identity else None,
        }
        record["identity_verification"] = verify_access_identity(int(pid), int(creation), baseline)
        write_json_flushed(
            out_dir / "identity.json",
            {
                "access_pid": int(pid),
                "access_creation": int(creation),
                "access_image": str(image),
                "live_creation": record["access_identity"]["live_creation"],
                "live_image": record["access_identity"]["live_image"],
                "verification": record["identity_verification"],
            },
        )
        observer = WindowObserver({int(pid)})
        observer.start()
        record["observer_started"] = True

    reader_class = _retaining_reader_class()
    from ms_access_mcp.backends.access.app_logic_session import ComAccessLauncher

    def _launch() -> Any:
        """Launch through production, wrapped in the recording proxy."""
        return _recording_session(ComAccessLauncher().launch(), sink)

    reader = reader_class(
        launcher=_launch,
        emit_identity=_on_identity,
        scratch_root=scratch_root,
        retain_to=retained,
    )
    raised: str | None = None
    content = None
    try:
        content = reader.read(str(source))
    except BaseException as exc:  # noqa: BLE001 - recorded; the parent decides the verdict
        raised = describe_com_error(exc)
    finally:
        if observer is not None:
            observer.stop()
            record["dialogs"] = observer.windows
            record["observer_error"] = observer.error

    record["product_security"] = {
        "security_set_requested": sink.get("security_set_requested"),
        "security_readback": sink.get("security_readback"),
        "expected_force_disable": 3,
    }
    record["product_opened_path"] = sink.get("product_opened_path")
    record["reader_raised"] = raised
    record["content"] = _content_summary(content) if content is not None else None
    record["retained_copy"] = dict(reader.retained)
    record["retained_copy"]["is_the_product_opened_file"] = bool(
        sink.get("product_opened_path") and reader.retained.get("path")
    )
    record["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    write_json_flushed(result_path, record)

    if raised is not None:
        print(f"PRODUCT_READER_RAISED: {raised}", file=sys.stderr)
        return EXIT_READER_RAISED
    return EXIT_OK


def main() -> int:
    """Parse argv, run the product cell, and map crashes to exit 5."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cell", default="PRODUCT")
    parser.add_argument("--run", type=int, required=True)
    parser.add_argument("--db", required=True)
    parser.add_argument("--out-dir", required=True)
    args = parser.parse_args()
    try:
        return run_product_cell(args)
    except Exception as exc:  # noqa: BLE001 - a crash is evidence, not silence
        try:
            write_json_flushed(
                Path(args.out_dir) / "result.json",
                {"schema": "v2-spike-embedded.product/1", "fatal": describe_com_error(exc)},
            )
        except Exception:  # noqa: BLE001
            pass
        print(f"PRODUCT_FATAL: {exc!r}", file=sys.stderr)
        return EXIT_FATAL


if __name__ == "__main__":
    raise SystemExit(main())
