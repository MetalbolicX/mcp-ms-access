"""Independent DAO-only observer for one disposable T5 spike copy.

Runs as its own short-lived process (its own COM apartment) so the canary row set and the
trigger facts are read *outside* the Access instance: once BEFORE the armed copy is opened
and once AFTER Access has been closed and its PID reaped. It executes nothing and writes
nothing to the copy; it only reads and records.

Exit codes: 0 the read ran (success is recorded inside the JSON ``ok`` field),
3 DAO raised (recorded as ``dao_error``), 5 unexpected fatal.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from harness_common import (  # noqa: E402
    CANARY_QUERY,
    FORM_NAME,
    read_canary_snapshot,
    snapshot_trigger_evidence,
    write_json_flushed,
)

EXIT_OK = 0
EXIT_DAO_ERROR = 3
EXIT_FATAL = 5


def main() -> int:
    """Read one disposable copy engine-level and print the JSON observation."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", required=True)
    parser.add_argument("--phase", required=True, choices=("before", "after"))
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    out_path = Path(args.out)
    try:
        snapshot = read_canary_snapshot(Path(args.db))
    except Exception as exc:  # noqa: BLE001 - a crash is evidence, not silence
        write_json_flushed(
            out_path,
            {
                "schema": "v2-spike-embedded.dao-read/1",
                "phase": args.phase,
                "db": args.db,
                "ok": False,
                "dao_error": repr(exc),
            },
        )
        print(f"DAO_READ_FATAL: {exc!r}", file=sys.stderr)
        return EXIT_FATAL

    snapshot["phase"] = args.phase
    trigger = snapshot_trigger_evidence(snapshot)
    snapshot["trigger_evidence"] = trigger
    write_json_flushed(out_path, snapshot)
    print(
        json.dumps(
            {
                "phase": args.phase,
                "db": args.db,
                "ok": snapshot["ok"],
                "row_count": snapshot["row_count"],
                "rows": snapshot["rows"],
                "dao_error": snapshot["dao_error"],
                "forms_container": trigger["forms_container"],
                "modules_container": trigger["modules_container"],
                "scripts_container": trigger["scripts_container"],
                "startup_form_property": trigger["startup_form_property"],
                "form_document_present": trigger["form_document_present"],
                "startup_form_is_trigger": trigger["startup_form_is_trigger"],
                "querydef_present": CANARY_QUERY in (snapshot.get("querydefs") or {}),
                "expected_form": FORM_NAME,
                "db_bytes": snapshot["db_bytes"],
            },
            indent=2,
            default=str,
        )
    )
    return EXIT_OK if snapshot["ok"] else EXIT_DAO_ERROR


if __name__ == "__main__":
    raise SystemExit(main())
