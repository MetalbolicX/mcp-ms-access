"""Bounded ground-truth probe: find real embedded event macros in a COPY of Northwind.

Read-only w.r.t. originals: copies db/northwind.accdb to scratch, opens the copy
under Access.Application with ForceDisable, SaveAsText-exports every form, and
greps the exports for embedded-macro dialect markers. Never executes anything
(the forms are never opened; only SaveAsText). Scratch removed by the parent.
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
SCRATCH = Path(__file__).resolve().parent
COPY = SCRATCH / "nwind_copy.accdb"
OUT = SCRATCH / "forms"
OUT.mkdir(exist_ok=True)
MARKERS = ("Embedded Macro", "[Embedded Macro]", "Parameter", "Begin Macro", "Macro")


def main() -> int:
    import pythoncom
    import win32com.client

    shutil.copy2(REPO / "db" / "northwind.accdb", COPY)
    results: dict[str, dict] = {}
    pythoncom.CoInitialize()
    app = None
    try:
        app = win32com.client.DispatchEx("Access.Application")
        app.Visible = False
        app.UserControl = False
        app.AutomationSecurity = 3
        assert int(app.AutomationSecurity) == 3
        app.OpenCurrentDatabase(str(COPY))
        forms = app.CurrentProject.AllForms
        names = [str(forms(i).Name) for i in range(forms.Count)]
        hits = 0
        for name in names:
            try:
                target = OUT / f"{name}.txt"
                app.SaveAsText(2, name, str(target))  # 2 = acForm
                text = target.read_bytes()
                decoded = text.decode("utf-16") if text[:2] in (b"\xff\xfe", b"\xfe\xff") else text.decode("utf-8", "replace")
                found = [m for m in MARKERS if m in decoded]
                if found:
                    hits += 1
                    results[name] = {"markers": found, "bytes": len(text)}
            except Exception as exc:  # noqa: BLE001 - record, continue
                results[name] = {"error": str(exc)}
        app.CloseCurrentDatabase()
        summary = {"forms_total": len(names), "forms_with_markers": hits, "details": results}
        (SCRATCH / "probe_result.json").write_text(json.dumps(summary, indent=1))
        print(json.dumps({"forms_total": len(names), "hits": hits, "hit_names": [k for k, v in results.items() if v.get("markers")]}))
        return 0
    finally:
        if app is not None:
            try:
                app.Quit()
            except Exception:
                pass
        app = None
        pythoncom.CoUninitialize()


if __name__ == "__main__":
    sys.exit(main())
