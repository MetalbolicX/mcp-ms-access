"""Run one T5 matrix cell (one Access instance, one disposable copy) in a child process.

The parent runner owns the hard timeout, the fail-closed PID-scoped hard kill, the two
independent DAO observations per run (before the armed open / after Access is reaped), the
canonical-hash protection and the orphan sweep. This child only drives one Access instance
and records what it sees (identity, security readback, version, observed windows, open
result, exit); it never reads the canary rows itself, never sends keyboard/UI input, and
never kills anything except -- best effort, identity-verified -- its own captured Access
PID during graceful shutdown.

The child writes its evidence incrementally so a blocked COM call still leaves readable
data for the parent.

Exit codes (documented): 0 ok; 3 security readback mismatch; 4 open failed;
5 unexpected fatal; 6 Access identity could not be positively verified (aborted before the
armed open).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from harness_common import (  # noqa: E402
    WindowObserver,
    baseline_pids,
    describe_com_error,
    lock_files,
    process_is_alive,
    read_process_identity,
    reap_access,
    safe_call,
    verify_access_identity,
    wait_until,
    write_json_flushed,
)

EXIT_OK = 0
EXIT_SECURITY_MISMATCH = 3
EXIT_OPEN_FAILED = 4
EXIT_FATAL = 5
EXIT_UNVERIFIED_IDENTITY = 6


class State:
    """Incrementally flushed cell record."""

    def __init__(self, path: Path) -> None:
        """Remember the flushed record path."""
        self.path = path
        self.payload: dict = {"schema": "v2-spike-embedded.cell/1", "dialogs": []}

    def record(self, **kwargs) -> None:
        """Merge fields into the record and flush it for the parent."""
        self.payload.update(kwargs)
        write_json_flushed(self.path, self.payload)

    def snapshot(self) -> dict:
        """Return a JSON-safe copy of the current record."""
        return json.loads(json.dumps(self.payload, default=str))


def _capture_identity(app, baseline: set[int]) -> tuple[dict, int | None, int | None, str | None]:
    """Capture the owned Access identity (pid, creation, image) before any armed open."""
    access_pid: int | None = None
    method = "hWndAccessApp"
    hwnd_error = None
    try:
        import win32process

        hwnd = int(app.hWndAccessApp())
        _thread, pid = win32process.GetWindowThreadProcessId(hwnd)
        access_pid = int(pid)
    except Exception as exc:  # noqa: BLE001 - baseline-diff fallback, recorded
        method = "baseline-diff"
        hwnd_error = describe_com_error(exc)
        candidates = sorted(baseline_pids() - baseline)
        access_pid = candidates[0] if len(candidates) == 1 else None
    live = read_process_identity(access_pid) if access_pid else None
    identity = {
        "method": method,
        "hwnd_error": hwnd_error,
        "access_pid": access_pid,
        "access_creation": live.creation if live else None,
        "access_image": live.image if live else None,
        "captured_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "baseline_msaccess_pids": sorted(baseline),
    }
    return identity, access_pid, identity["access_creation"], identity["access_image"]


def run_cell(args: argparse.Namespace) -> int:
    """Drive one Access instance through one armed copy and record what it observes."""
    import pythoncom
    import win32com.client

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    state = State(out_dir / "result.json")
    baseline = baseline_pids()
    state.record(
        cell=args.cell,
        run=args.run,
        security_requested=args.security,
        db=args.db,
        started_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
        child_pid=os.getpid(),
        baseline_msaccess_pids=sorted(baseline),
    )

    observer: WindowObserver | None = None
    access_pid: int | None = None
    access_creation: int | None = None
    access_image: str | None = None

    pythoncom.CoInitialize()
    app = None
    try:
        app = win32com.client.DispatchEx("Access.Application")
        identity, access_pid, access_creation, access_image = _capture_identity(app, baseline)
        verification = verify_access_identity(access_pid, access_creation, baseline)
        state.record(access_identity=identity, identity_verification=verification)
        # Flush the parent-readable identity file before any armed open.
        write_json_flushed(out_dir / "identity.json", {**identity, "verification": verification})
        if not verification["owned"]:
            state.record(aborted="Access identity not positively verified; armed open refused")
            return EXIT_UNVERIFIED_IDENTITY

        observer = WindowObserver({access_pid} if access_pid else set())
        observer.start()
        state.record(observer_started=True)

        for attribute, value in (("Visible", False), ("UserControl", False)):
            result = safe_call(lambda attribute=attribute, value=value: setattr(app, attribute, value))
            if not result["ok"]:
                state.record(**{f"{attribute.lower()}_error": result["error"]})

        app.AutomationSecurity = args.security
        readback = int(app.AutomationSecurity)
        state.record(
            security_readback=readback, security_readback_matches=(readback == args.security)
        )
        if readback != args.security:
            state.record(aborted="AutomationSecurity readback mismatch; armed file not opened")
            return EXIT_SECURITY_MISMATCH

        open_started = time.monotonic()
        try:
            app.OpenCurrentDatabase(str(args.db))
            state.record(open_ok=True, open_seconds=round(time.monotonic() - open_started, 3))
        except Exception as exc:  # noqa: BLE001
            state.record(
                open_ok=False,
                open_seconds=round(time.monotonic() - open_started, 3),
                open_error=describe_com_error(exc),
            )
            return EXIT_OPEN_FAILED

        # Access version string only; never claim an unmeasured bitness or provider.
        state.record(access_version=safe_call(lambda: str(app.Version)).get("value"))

        # Bounded settle: give the startup form's embedded event macro (and any warning
        # dialog it raises) time to appear. No keyboard input and no dismissal is sent.
        settle_deadline = time.monotonic() + args.settle_seconds
        next_window_sample = time.monotonic()
        while time.monotonic() < settle_deadline:
            time.sleep(0.25)
            if time.monotonic() >= next_window_sample:
                # Flush observed windows periodically so a hard kill still leaves the
                # dialog evidence on disk for the parent.
                state.record(dialogs=observer.windows)
                next_window_sample = time.monotonic() + 2.0
        state.record(settled_seconds=round(time.monotonic() - open_started, 3))

        # Graceful shutdown (the parent still owns the hard kill).
        close_result = safe_call(lambda: app.CloseCurrentDatabase())
        state.record(close_current_ok=close_result["ok"], close_error=close_result.get("error"))
        quit_result = safe_call(lambda: app.Quit())
        state.record(quit_ok=quit_result["ok"], quit_error=quit_result.get("error"))
        app = None

        if access_pid is not None:
            exited = wait_until(lambda: not process_is_alive(access_pid), 15.0)
            state.record(access_exited_after_quit=exited)
            if not exited:
                state.record(
                    self_reap=reap_access(access_pid, access_creation, access_image, baseline)
                )
        else:
            state.record(access_exited_after_quit=None)
    finally:
        if observer is not None:
            observer.stop()
            state.record(dialogs=observer.windows, observer_error=observer.error)
        if app is not None:
            # Best-effort graceful quit of our OWN instance on every abort path; this is
            # not a kill and is never applied to a foreign process.
            safe_call(lambda: app.Quit())
        state.record(
            locks_after=lock_files(out_dir),
            finished_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
        )
        app = None
        pythoncom.CoUninitialize()
    return EXIT_OK


def main() -> int:
    """Parse argv, run one cell, and map fatal crashes to exit 5."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cell", required=True)
    parser.add_argument("--run", type=int, required=True)
    parser.add_argument("--db", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--security", type=int, required=True)
    parser.add_argument("--settle-seconds", type=float, default=12.0)
    args = parser.parse_args()
    try:
        return run_cell(args)
    except Exception as exc:  # noqa: BLE001 - a crash is evidence, not silence
        try:
            write_json_flushed(
                Path(args.out_dir) / "result.json",
                {
                    "schema": "v2-spike-embedded.cell/1",
                    "fatal": describe_com_error(exc),
                },
            )
        except Exception:  # noqa: BLE001
            pass
        print(f"CELL_FATAL: {exc!r}", file=sys.stderr)
        return EXIT_FATAL


if __name__ == "__main__":
    raise SystemExit(main())
